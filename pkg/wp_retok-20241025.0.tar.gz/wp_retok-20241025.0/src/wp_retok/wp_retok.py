#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

import wp_retok
t = wp_retok.ReTokenizer('bert-base-uncased')
e, ind, l = t.retokenize_and_encode_indexed('hellooooo brave new world !!!!'.split())
e, ind, l = t.retokenize_and_encode_indexed([str(i) for i in range(600)])


from wp_retok import ReTokenizer
from transformers import AutoModel
import torch

tokenizer = ReTokenizer('bert-base-uncased')
model = AutoModel.from_pretrained('bert-base-uncased')

tokens = 'Germany Germany Germany'.split(' ')
encoded_tokens, token_indexes, _ = tokenizer.retokenize_and_encode_indexed(tokens)

with torch.no_grad():
  out_dict = model(**encoded_tokens, output_attentions=True, output_hidden_states=True, return_dict=True)
embeddings = out_dict['last_hidden_state']

for k, v in token_indexes[0].items():
  print(f'Embedding for "{v[0]}" at position {k}: {embeddings[0,v[1],:5]}...')


@author: remstef
"""

import torch
from transformers import AutoTokenizer
import multiprocessing as mp

'''
'''
class ReTokenizerModel(object):

  def __init__(self, transformer_modeltokenizer):
      super(ReTokenizerModel,self).__init__()
      self.modeltokenizer = transformer_modeltokenizer

  def retokenize_and_encode(self, tokens, tokenize_kwargs={}, encode_kwargs={}):
    # retokenize sentence to match transformers model
    sentence_tok_model = [ ]
    token2modeltoken = [ ]
    modeltoken2token = [ ]
    for ti, token in enumerate(tokens):
      token2modeltoken.append([ ])
      for modeltoken in self.modeltokenizer.tokenize(text=token.strip(), **tokenize_kwargs):
        token2modeltoken[ti].append(len(sentence_tok_model))
        sentence_tok_model.append(modeltoken.strip())
        modeltoken2token.append(ti)
    # encode tokens
    default_encode_kwargs = {
      'padding' : 'max_length',
      'truncation' : True,
      'max_length' : min(self.modeltokenizer.max_len_single_sentence, len(sentence_tok_model)+2),
      'return_tensors' : 'pt',
    }
    encoded_input = self.modeltokenizer.encode_plus(text=sentence_tok_model, **default_encode_kwargs | encode_kwargs)
    sentence_tok_model_decoded = self.modeltokenizer.convert_ids_to_tokens(encoded_input['input_ids'][0])
    # realign
    modeltoken2realignedmodeltoken = [ ]
    shift = 0
    for i, modeltoken in enumerate(sentence_tok_model):
      while (i+shift < len(sentence_tok_model_decoded)) and modeltoken != sentence_tok_model_decoded[i+shift]:
        shift += 1
      if i+shift >= len(sentence_tok_model_decoded):
        break
      modeltoken2realignedmodeltoken.append(i+shift)
    # ===
    return encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken

  def retokenize_and_encode_indexed(self, tokens):
    # retokenize
    encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = self.retokenize_and_encode(tokens)
    # prepare forward and reverse indices
    # i --> (token, [encoded_indices], [decoded_tokens])
    tok_fw_index = { i: ( ti, [ modeltoken2realignedmodeltoken[j] if j < len(modeltoken2realignedmodeltoken) else -1 for j in token2modeltoken[i] ], [ sentence_tok_model_decoded[modeltoken2realignedmodeltoken[j]] if j < len(modeltoken2realignedmodeltoken) else None for j in token2modeltoken[i] ] )for i, ti in enumerate(tokens) }
    # i --> (modeltoken, tokenindex, modeltoken)
    tok_rev_index = { i: (modeltoken2token[modeltoken2realignedmodeltoken.index(i)] if i in modeltoken2realignedmodeltoken else -1, mt) for i, mt in enumerate(sentence_tok_model_decoded) }
    # ===
    return encoded_input, (tok_fw_index, tok_rev_index), (sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken)

'''
'''
class ReTokenizer(ReTokenizerModel):

  def __init__(self, transformer_modelname, **tokenizer_kwargs):
      modeltokenizer = AutoTokenizer.from_pretrained(transformer_modelname, **{'use_fast' : False} | tokenizer_kwargs) # fast tokenizers don't have the required encode_plus method or their output is inconistent with the 'slow' tokenizers
      super(ReTokenizer,self).__init__(modeltokenizer)


class BatchReTokenizer(ReTokenizer):
    
  '''
  encoder_length = {max_length_model, max_len_single_sentence_in_batch, [number <= max_length_model]}
  '''
  def __init__(self, transformer_modelname, encoder_length='max_length_model'):
    super(BatchReTokenizer,self).__init__(transformer_modelname)
    self.encoder_length = encoder_length
    self.modeltokenizer = AutoTokenizer.from_pretrained(transformer_modelname, use_fast=False) # fast tokenizers don't have the required encode_plus method
  
  def __retokenize_single__(self, tokens):
    # retokenize sentence to match transformers model
    sentence_tok_model = [ ]
    token2modeltoken = [ ]
    modeltoken2token = [ ]
    for ti, token in enumerate(tokens):
      token2modeltoken.append([ ])
      for modeltoken in self.modeltokenizer.tokenize(token.strip()):
        token2modeltoken[ti].append(len(sentence_tok_model))
        sentence_tok_model.append(modeltoken.strip())
        modeltoken2token.append(ti)
    return len(sentence_tok_model), len(sentence_tok_model), sentence_tok_model, token2modeltoken, modeltoken2token

  def __encode_single__(self, retokenize_output):
    # unpack input
    max_length, sentence_len_tok_model, sentence_tok_model, token2modeltoken, modeltoken2token = retokenize_output
    if isinstance(max_length, str) and max_length == 'max_length_model':
      max_length = self.modeltokenizer.max_len_single_sentence
    else:
      max_length = min(self.modeltokenizer.max_len_single_sentence, max_length)
    # encode tokens
    encoded_input = self.modeltokenizer.encode_plus(sentence_tok_model, padding='max_length', truncation=True, max_length=max_length, return_tensors='pt')
    sentence_tok_model_decoded = self.modeltokenizer.convert_ids_to_tokens(encoded_input['input_ids'][0])
    # realign
    modeltoken2realignedmodeltoken = [ ]
    shift = 0
    for i, modeltoken in enumerate(sentence_tok_model):
      while (i+shift < len(sentence_tok_model_decoded)) and modeltoken != sentence_tok_model_decoded[i+shift]:
        shift += 1
      if i+shift >= len(sentence_tok_model_decoded):
        break
      modeltoken2realignedmodeltoken.append(i+shift)
    # ===
    return encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken

  def batch_retokenize_and_encode(self, batch_of_tokens):
    # retokenize
    retokenize_output = [ self.__retokenize_single__(tokens) for tokens in batch_of_tokens ]
    # find the maximum length    
    max_length = self.encoder_length    
    if isinstance(self.encoder_length, str):
      if self.encoder_length == 'max_len_single_sentence_in_batch':
        max_length = max(map(lambda x: x[0], retokenize_output))+2
    #
    encode_output = [self.__encode_single__(x) for x in map(lambda x: (max_length, *x[1:]), retokenize_output)]
    # unzip the elements to make individual lists
    encoded_inputs, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = list(zip(*encode_output))
    # stack tensors of each dict entry in encoded_inputs and save as dict
    encoded_input = { }
    for k in encoded_inputs[0].keys():
      encoded_input[k] = torch.stack(list(map(lambda x: x[k][0], encoded_inputs)), dim=0)    
    #
    return encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken

  def __prepare_index_single__(self, retokenized_and_encoded):
    # unpack arguments
    tokens, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = retokenized_and_encoded
    # prepare forward and reverse indices
    # i --> (token, [encoded_indices], [decoded_tokens])
    tok_fw_index = { i: ( ti, [ modeltoken2realignedmodeltoken[j] if j < len(modeltoken2realignedmodeltoken) else -1 for j in token2modeltoken[i] ], [ sentence_tok_model_decoded[modeltoken2realignedmodeltoken[j]] if j < len(modeltoken2realignedmodeltoken) else None for j in token2modeltoken[i] ] )for i, ti in enumerate(tokens) }
    # i --> (modeltoken, tokenindex, modeltoken)
    tok_rev_index = { i: (modeltoken2token[modeltoken2realignedmodeltoken.index(i)] if i in modeltoken2realignedmodeltoken else -1, mt) for i, mt in enumerate(sentence_tok_model_decoded) }
    # ===
    return tok_fw_index, tok_rev_index

  def batch_retokenize_and_encode_indexed(self, batch_of_tokens):
    # retokenize
    encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = self.batch_retokenize_and_encode(batch_of_tokens)
    indexes = [self.__prepare_index_single__(x) for x in zip(batch_of_tokens, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken) ]
    # unpack
    tok_fw_index, tok_rev_index = zip(*indexes)
    return encoded_input, tok_fw_index, tok_rev_index


class ParallelBatchReTokenizer(object):
    
  '''
  encoder_length = {max_length_model, max_len_single_sentence_in_batch, [number <= max_length_model]}
  '''
  def __init__(self, transformer_modelname, encoder_length='max_length_model', nprocesses=-1):
    super(ParallelBatchReTokenizer,self).__init__()
    self.transformer_modelname = transformer_modelname
    if nprocesses <= 0:
      nprocesses = mp.cpu_count()
    self.pool = mp.Pool(
      initializer=ParallelBatchReTokenizer._worker__init, 
      initargs=(transformer_modelname,),
      processes=nprocesses)
    self.encoder_length = encoder_length

  @staticmethod
  def _worker__init(transformer_modelname):
    global _workervar__modeltokenizer
    _workervar__modeltokenizer = AutoTokenizer.from_pretrained(transformer_modelname, use_fast=False) # fast tokenizers don't have the required encode_plus method
  
  @staticmethod
  def _worker__retokenize(tokens):
    # retokenize sentence to match transformers model
    sentence_tok_model = [ ]
    token2modeltoken = [ ]
    modeltoken2token = [ ]
    for ti, token in enumerate(tokens):
      token2modeltoken.append([ ])
      for modeltoken in _workervar__modeltokenizer.tokenize(token.strip()):
        token2modeltoken[ti].append(len(sentence_tok_model))
        sentence_tok_model.append(modeltoken.strip())
        modeltoken2token.append(ti)
    return len(sentence_tok_model), len(sentence_tok_model), sentence_tok_model, token2modeltoken, modeltoken2token
  
  @staticmethod
  def _worker__encode(retokenize_output):
    # unpack input
    max_length, sentence_len_tok_model, sentence_tok_model, token2modeltoken, modeltoken2token = retokenize_output
    if isinstance(max_length, str) and max_length == 'max_length_model':
      max_length = _workervar__modeltokenizer.max_len_single_sentence
    else:
      max_length = min(_workervar__modeltokenizer.max_len_single_sentence, max_length)
    
    # encode tokens
    encoded_input = _workervar__modeltokenizer.encode_plus(sentence_tok_model, padding='max_length', truncation=True, max_length=max_length, return_tensors='pt')
    sentence_tok_model_decoded = _workervar__modeltokenizer.convert_ids_to_tokens(encoded_input['input_ids'][0])
    # realign
    modeltoken2realignedmodeltoken = [ ]
    shift = 0
    for i, modeltoken in enumerate(sentence_tok_model):
      while (i+shift < len(sentence_tok_model_decoded)) and modeltoken != sentence_tok_model_decoded[i+shift]:
        shift += 1
      if i+shift >= len(sentence_tok_model_decoded):
        break
      modeltoken2realignedmodeltoken.append(i+shift)
    # ===
    return encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken
    
  def retokenize_and_encode(self, batch_of_tokens):
    # retokenize
    retokenize_output = self.pool.map(ParallelBatchReTokenizer._worker__retokenize, batch_of_tokens)

    max_length = self.encoder_length    
    if isinstance(self.encoder_length, str):
      if self.encoder_length == 'max_len_single_sentence_in_batch':
        max_length = max(map(lambda x: x[0], retokenize_output))+2
    
    encode_output = self.pool.map(ParallelBatchReTokenizer._worker__encode, map(lambda x: (max_length, *x[1:]), retokenize_output))
    # unzip the elements to make individual lists
    encoded_inputs, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = list(zip(*encode_output))
    
    # stack tensors of each dict entry in encoded_inputs and save as dict
    encoded_input = { }
    for k in encoded_inputs[0].keys():
      encoded_input[k] = torch.stack(list(map(lambda x: x[k][0], encoded_inputs)), dim=0)    

    return encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken

  @staticmethod
  def _worker__prepare_index(retokenized_and_encoded):
    # unpack arguments
    tokens, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = retokenized_and_encoded
    # prepare forward and reverse indices
    # i --> (token, [encoded_indices], [decoded_tokens])
    tok_fw_index = { i: ( ti, [ modeltoken2realignedmodeltoken[j] if j < len(modeltoken2realignedmodeltoken) else -1 for j in token2modeltoken[i] ], [ sentence_tok_model_decoded[modeltoken2realignedmodeltoken[j]] if j < len(modeltoken2realignedmodeltoken) else None for j in token2modeltoken[i] ] )for i, ti in enumerate(tokens) }
    # i --> (modeltoken, tokenindex, modeltoken)
    tok_rev_index = { i: (modeltoken2token[modeltoken2realignedmodeltoken.index(i)] if i in modeltoken2realignedmodeltoken else -1, mt) for i, mt in enumerate(sentence_tok_model_decoded) }
    # ===
    return tok_fw_index, tok_rev_index

  def retokenize_and_encode_indexed(self, batch_of_tokens):
    # retokenize
    encoded_input, sentence_tok_model, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken = self.retokenize_and_encode(batch_of_tokens)
    indexes = self.pool.map(ParallelBatchReTokenizer._worker__prepare_index, zip(batch_of_tokens, sentence_tok_model_decoded, token2modeltoken, modeltoken2token, modeltoken2realignedmodeltoken))    
    # unpack
    tok_fw_index, tok_rev_index = zip(*indexes)
    return encoded_input, tok_fw_index, tok_rev_index
