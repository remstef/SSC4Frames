# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
# """
#  test retokenizing
# """

import sys, os

# add module to python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)).replace('tests', 'src'))

def test1():
    import wp_retok
    t = wp_retok.ReTokenizer('bert-base-uncased')
    e, ind, l = t.retokenize_and_encode_indexed('hellooooo brave new world !!!!'.split())
    print(e, ind, l)
    e, ind, l = t.retokenize_and_encode_indexed([str(i) for i in range(600)])

def test2():
    import wp_retok
    from transformers import AutoTokenizer
    modeltokenizer = AutoTokenizer.from_pretrained('bert-base-uncased', use_fast=False) # fast tokenizers don't have the required encode_plus method or their output is inconistent with the 'slow' tokenizers
    t = wp_retok.ReTokenizerModel(modeltokenizer)
    e, ind, l = t.retokenize_and_encode_indexed('hellooooo brave new world !!!!'.split())
    print(e, ind, l)
    e, ind, l = t.retokenize_and_encode_indexed([str(i) for i in range(600)])
    
# test1()
# test2()