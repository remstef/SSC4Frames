#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import os
import numpy as np
import torch

# run some tests
import pt_graph_cluster_lib as ptgcl # pip install --editable .


def calculate_scores(labels_true, labels_pred):
  scores = ptgcl.cl.evaluate_cluster_labels(
    labels_true = labels_true,
    labels_pred = labels_pred,
    omit_contingency=False,
  )
  for k,v in scores.items():
    print(f'{k} : {v}')


def test_evaluate_cluster_labels(*args, random_state=None, **kwargs):
  random_generator = np.random.default_rng(seed=random_state)
  
  labels_true = ptgcl.cl.G_twentynodes_true_labels().numpy()
  labels_pred = labels_true.copy() * -1
  labels_pred[random_generator.choice(range(1,20), 6, replace=False)] = random_generator.integers(100,105,(6,),dtype=np.uint8)*-1
  calculate_scores(labels_true, labels_pred)


def test_pairwise_metrics(*args, **kwargs):
  labels_true = np.array([1,1,1,1,1,1,1,1, 2,2,2,2,2, 3,3,3,3], dtype=np.uint8)
  labels_pred = np.array([10,10,10,10,10,20,30,30, 20,20,20,20,10, 30,30,30,20], dtype=np.uint8)
  scores = ptgcl.cl.parwise_metric_scores(y_true=labels_true, y_pred=labels_pred)
  print(scores)
  calculate_scores(labels_true, labels_pred)


def test_read_graph_from_file():
  g1, names1, ids1 = ptgcl.cl.read_graph_from_file(os.path.join(os.path.dirname(__file__), 'graphs/3-clover.graph'))
  print(g1)
  print(names1)
  print(ids1)
  g2, names2, ids2 = ptgcl.cl.read_graph_from_file(os.path.join(os.path.dirname(__file__), 'graphs/3D-triangle-draft.uugraph'))
  print(g2)
  print(names2)
  print(ids2)


def test_shortest_paths():
  A = lambda: ptgcl.cl.G_maxmax()
  D, H = ptgcl.cl.shortest_path_distances(A(), num_hops=False)
  print()
  print('Input Graph:')
  ptgcl.cl.pretty_print_matrix(A())
  print('Distances:')
  ptgcl.cl.pretty_print_matrix(D)
  print('Number of hops:')
  ptgcl.cl.pretty_print_matrix(H)



def test_umap_style_graph():
  print()
  k = 8
  G = lambda: ptgcl.cl.G_twentynodes_equidist()
  # G = lambda: ptgcl.cl.G_twentynodes_equidist2()
  k = k if k <= G().size(0) else G().size(0)-1
  print('k:', k)
  log2_k = torch.log2(torch.tensor(k))
  print('log2(k):', log2_k)
  print('Input graph:')
  ptgcl.cl.pretty_print_matrix(G(),value_format='.2f',width=5)
  G_ = ptgcl.cl.umap_style_graph(G(), topk=k, symmetrize='none')
  print('Non-symmetrical UMAP graph:')
  ptgcl.cl.pretty_print_matrix(G_,value_format='.3f',width=5)
  assert torch.allclose(G_.sum(dim=1), log2_k), f'Sigma_i does not seem to be correctly estimated. Should be {torch.log2(torch.tensor(k)).item()}, but is {G_.sum(dim=1).tolist()}'
  #
  G__ = ptgcl.cl.umap_style_graph(G(), topk=k, symmetrize='union')
  print('Symmetrical UMAP graph:')
  ptgcl.cl.pretty_print_matrix(G__,value_format='.3f',width=5)
  assert G__.sum(dim=1).sum() - G__.sum(dim=0).sum() < 1e-5, f"Graph does not seem to be symmetric"


def test_umap_style_graph_edge_cases():
  print()
  G1 = lambda: torch.tensor([[.00]])
  G2 = lambda: torch.rand((2,2)) * 10
  G10_unconnected = lambda: torch.zeros((10,10))
  k = 8
  # test G1
  G1_ = ptgcl.cl.umap_style_graph(G1(), topk=k)
  assert G1_.size(0) == 1 and G1_.size(1) == 1
  assert G1_[0,0] == 0
  # test G2
  G2_ = ptgcl.cl.umap_style_graph(G2(), topk=k)
  assert G2_.size(0) == 2 and G2_.size(1) == 2
  assert G2_[0,1] == G2_[1,0] == 1
  assert G2_[0,0] == G2_[1,1] == 0
  # test unconnected graph
  G10_unconnected_ = ptgcl.cl.umap_style_graph(G10_unconnected(), topk=k)
  # ptgcl.cl.pretty_print_matrix(G10_unconnected_)
  assert G10_unconnected_[range(10), range(10)].sum() == 0
  

def test_umap_style_graph_two_clusters():
  print()
  k = 4
  G = lambda: torch.tensor([
    [.00, .10, .20, .99, 1.0],
    [.10, .00, .01, .99, 1.0],
    [.20, .01, .00, .99, 1.0],
    [.99, .99, .99, .00, .01],
    [1.0, 1.0, 1.0, .01, .00],
  ])[:4,:4] # expect 2 clusters
  k = k if k <= G().size(0) else G().size(0)-1
  print('k:', k)
  print('Input graph:')
  ptgcl.cl.pretty_print_matrix(G(),value_format='.2f',width=5)
  G_ = ptgcl.cl.umap_style_graph(G(), topk=k, symmetrize='none')
  print('Non-symmetrical UMAP graph:')
  ptgcl.cl.pretty_print_matrix(G_,value_format='.3f',width=5)
  
  #
  G__ = ptgcl.cl.umap_style_graph(G(), topk=k, apply_optimal_k_heuristic='values', symmetrize='intersection')
  print('Symmetrical UMAP graph:')
  ptgcl.cl.pretty_print_matrix(G__,value_format='.3f',width=5)
  assert torch.allclose(G__, G__.T), f"Graph does not seem to be symmetric"

  cl = ptgcl.cw._cw_no_preprocessing_(G__, out=['labels','labelvector'])
  print(cl)
    

def test_sigma_i_binary_search():
  distances, rho_i, k = torch.tensor([[1,6,7],[1,4,5],[1,2,3]]), torch.tensor([1,1,1]), 3
  # test scipy
  sigma_i, res_ = ptgcl.cl.__umap_find_sigma_i_single_scipy__(
    distances=distances[0,:].numpy(),
    rho_i=rho_i[0].numpy(), 
    k=k,
    max_iter=1000,
  )
  sum_weights = torch.sum(torch.exp(-(distances[0,:] - rho_i[0])/torch.tensor(sigma_i)))
  print('sigma_i (scipy): ', sigma_i)
  print('iterations: ', res_.iterations)
  assert torch.allclose(sum_weights, torch.log2(torch.tensor(k))), f'Sum of weights should be {torch.log2(torch.tensor(k)).item()}, but is {sum_weights.tolist()}.'

  # test single value binary search
  sigma_i, (weights, iter) = ptgcl.cl.__umap_find_sigma_i_single__(
    distances=distances[0,:],
    rho_i=rho_i[0], 
    k=k,
    max_iter=1000
  )
  sum_weights = torch.sum(torch.exp(-(distances[0,:] - rho_i[0])/sigma_i))
  print('sigma_i (binary search single value): ', sigma_i)
  print('iterations: ', iter)
  print('weights: ', weights.tolist())
  assert torch.allclose(sum_weights, torch.log2(torch.tensor(k))), f'Sum of weights should be {torch.log2(torch.tensor(k)).item()}, but is {sum_weights.tolist()}.'

  # test batched binary search
  sigma_i, (weights, iter) = ptgcl.cl.__umap_find_sigma_i__(
    distances=distances, # [0,:].unsqueeze(0)
    rho_i=rho_i, # [0].unsqueeze(0),
    k=k,
    max_iter=1000,
    add_rand_noise=False
  )
  print('sigma_i (batched binary search): ', sigma_i.tolist())
  print('iter: ', iter)
  print('weights:')
  ptgcl.cl.pretty_print_matrix(weights,value_format='.3f',width=5)
  # print('===')
  # ptgcl.cl.pretty_print_matrix_concise(weights,value_format='.3f',width=5)
  weights_should = torch.exp(-(distances - rho_i.unsqueeze(1).expand_as(distances))/sigma_i.unsqueeze(1).expand_as(distances))
  sum_weights_should = torch.sum(weights_should,dim=1)
  sum_weights_actual = torch.sum(weights, dim=1)
  assert torch.allclose(sum_weights_should, torch.log2(torch.tensor(k))), f'Computed sum of weights should be {torch.log2(torch.tensor(k)).item()}, but is {sum_weights_should.tolist()}.'
  assert torch.allclose(sum_weights_actual, torch.log2(torch.tensor(k))), f'Sum of weights should be {torch.log2(torch.tensor(k)).item()}, but is {sum_weights_actual.tolist()}.'
  assert torch.allclose(weights_should, weights), f'Weights should be {weights_should}, but are {weights}.'


def test_sigma_i_binary_search_edge_cases():
  distances, rho_i, k = torch.tensor([[1,2,2],[1,1,1]]), torch.tensor([1,1]), 3
  sigma_i, (weights, iter) = ptgcl.cl.__umap_find_sigma_i__(
    distances=distances,
    rho_i=rho_i,
    k=k,
    max_iter=100,
    max_rand_noise_amount=1e-4
  )
  print('sigma_i (batched binary search): ', sigma_i.tolist())
  print('iter: ', iter)
  print('weights:')
  ptgcl.cl.pretty_print_matrix(weights,value_format='.3f',width=5)
  sum_weights_actual = torch.sum(weights, dim=1)
  assert torch.allclose(sum_weights_actual, torch.log2(torch.tensor(k))), f'Each sum of weights should be {torch.log2(torch.tensor(k)).item()}, but is {sum_weights_actual.tolist()}.'


def test_optimal_k_diff_method():
  #
  vals = torch.tensor([
    [1,2,3,5,10,20],
    [1,2,3,5,15,20],
    [1,2,3,5,6,7],
    [1,2,3,4,5,6],
  ], dtype=torch.float32)
  #
  break_indices = ptgcl.cl.__natural_break_by_diff__(vals)
  print()
  ptgcl.cl.pretty_print_matrix(vals, value_format='.3f',width=5)
  ptgcl.cl.pretty_print_matrix(break_indices.unsqueeze(1), value_format='d',width=5)
  assert torch.allclose(torch.tensor([5,4,3,1]), break_indices), "expected breaks don't match"

  # rand_vals = torch.rand((3,8))
  # sorted_by_topk = torch.topk(rand_vals, dim=1, k=rand_vals.size(1), largest=False, sorted=True).values
  # break_indices_2 = ptgcl.cl.__natural_break_by_diff__(sorted_by_topk)
  # ptgcl.cl.pretty_print_matrix(rand_vals, value_format='.3f',width=5)
  # ptgcl.cl.pretty_print_matrix(sorted_by_topk, value_format='.3f',width=5)
  # ptgcl.cl.pretty_print_matrix(break_indices_2.unsqueeze(1), value_format='d',width=5)




def test_optimal_k_diff_method_with_reset():
  #
  vals = torch.tensor([
    [1,2,3,5,10,20],
    [1,2,3,5,15,20],
    [1,2,3,5,6,7],
    [1,2,3,4,5,6],
  ], dtype=torch.float32)
  #
  break_indices = ptgcl.cl.__natural_break_by_diff__(vals)
  print()
  ptgcl.cl.pretty_print_matrix(vals, value_format='.3f',width=5)
  ptgcl.cl.pretty_print_matrix(break_indices.unsqueeze(1), value_format='d',width=5)
  # compute the reset indices
  reset_indices = tuple(zip(*(tupl for i, break_index in enumerate(break_indices) for tupl in zip([i]*(vals.size(1)-break_index), range(break_index, vals.size(1))))))
  vals[reset_indices] = -1 # make it -1 for testing
  ptgcl.cl.pretty_print_matrix(vals, value_format='.3f',width=5)
  

