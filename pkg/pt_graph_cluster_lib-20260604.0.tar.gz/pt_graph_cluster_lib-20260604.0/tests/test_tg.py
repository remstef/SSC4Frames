#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import os
import sys
import networkx as nx
import torch
import numpy as np
import typing

# run some tests
import pt_graph_cluster_lib as ptgcl # pip install --editable .

def tg_test(A, *args, **kwargs) -> typing.Any:
  if not 'verbose' in kwargs:
    kwargs['verbose'] = True
  if not 'quiet' in kwargs:
    kwargs['quiet'] = False
  clusterer = ptgcl.tg.TG(*args, **kwargs).fit(A)
  return { 
    'labels' : ptgcl.cl.labelvector_as_clusterlist(clusterer.labels_),
    'labelvector' : clusterer.labels_,
    'previouslabelvector' : clusterer.previous_labels_,
    'A' : clusterer.A_,
    'log' : clusterer.logs_
  }

def tg_test_quiet(A, *args, **kwargs) -> typing.Any:
  if not 'verbose' in kwargs:
    kwargs['verbose'] = False
  if not 'quiet' in kwargs:
    kwargs['quiet'] = True
  return ptgcl.tg.TG(*args, **kwargs).fit(A)

  # return { 
  #   'labels' : ptgcl.cl.labelvector_as_clusterlist(clusterer.labels_),
  #   'labelvector' : clusterer.labels_,
  #   'previouslabelvector' : clusterer.previous_labels_,
  #   'A' : clusterer.A_,
  #   'log' : clusterer.logs_
  # }


def to_nx(A:torch.Tensor, pos: dict[int, np.array]=None, node_labels: torch.Tensor = None, node_active: torch.Tensor = None, node_history: list[str] = None) -> nx.Graph:
  G = nx.from_numpy_array(A.numpy(), create_using=nx.DiGraph())
  for i in range(node_labels.size(0)):
    # title -> assigned class as string (will be shown on hover)
    # group -> assigned class as integer
    # label -> node id as string (will be shown below node)
    G.nodes[i]['id'] = i
    G.nodes[i]['group'] = node_labels[i].item() if node_labels is not None else -1
    G.nodes[i]['label'] = f"v{i}|c{G.nodes[i]['group']}"
    G.nodes[i]['title'] = f'v{i}'
    if node_active is not None:
      G.nodes[i]['title'] += f"-{'active' if node_active[i] else 'inactive'}"
    if node_history is not None:
      G.nodes[i]['title'] += f'\n{node_history[i]}'   
  if pos is None:
    pos = nx.kamada_kawai_layout(G)
  # inspect the data
  # G.nodes(data=True)
  # G.edges(data=True)
  return G, pos


def draw_static(A: torch.Tensor, *args, **kwargs) -> None:
  import matplotlib.pyplot as plt
  G, pos = to_nx(A, *args, **kwargs)
  options = {
      # 'font_size': 36,
      # 'node_size': 3000,
      # 'node_color': 'white',
      # 'edgecolors': 'black',
      # 'linewidths': 5,
      # 'width': 5,
      'node_size': 1200,
      'font_color': 'lightgray',
      # 'alpha': 0.9
  }
  label_dict = { i : f'$v{i}|c{v.item()}$' for i,v in enumerate(kwargs['node_labels']) }
  nx.draw(G, pos, with_labels=True, labels=label_dict, node_color=kwargs['node_labels'], **options)
  # pos_labels = { k: coords-np.array([0, .4]) for k, coords in pos.items() }
  # nx.draw_networkx_labels(G, pos, labels=label_dict, horizontalalignment='center', verticalalignment='center')

  # # Set margins for the axes so that nodes aren't clipped
  # ax = plt.gca()
  # ax.margins(.2)
  # plt.axis('off')
  # plt.show()
  # nx.draw(G=G, pos=pos, labels=kwargs['node_labels'], with_labels=True)
  plt.savefig('g.pdf', format='PDF')


def write_file(A, *args, **kwargs):
  G, pos = to_nx(A, *args, **kwargs)
  # nx.nx_pydot.write_dot(G, 'g.dot')
  # nx.write_gexf( G , 'g.gexf')
  nx.write_graphml(G, 'g.graphml')


def generate_pyvis_network(A: torch.Tensor, *args, show_selections=False, show_options=False, **kwargs) -> any:
  from pyvis.network import Network
  # Create directed graph with networkx
  G, pos = to_nx(A, *args, **kwargs) # pos contains pre-calculated initial positions to be given to pyvis
  # Plot with pyvis
  net = Network(
      # height='500px',
      # width='500px',
      height='640px', 
      width='100%', 
      bgcolor='#222222', 
      font_color='white',
      neighborhood_highlight=True,
      directed=True,
      select_menu=show_selections, # Show part 1 in the plot (optional)
      filter_menu=show_selections, # Show part 2 in the plot (optional),
  )
  net.from_nx(G) # Create from nx graph
  # update initial position attributes
  for n in net.nodes:
    # n.update({'physics': False, 'fixed': { 'x' : True, 'y': True}})
    n.update({'x': pos[n['id']][0], 'y': -pos[n['id']][0]})
  # Investigative attributes:
  #   title -> assigned class as string (will be shown on hover)
  #   group -> assigned class as integer
  #   label -> node id as string (will be shown below node)
  if show_options:
    # net.show_buttons() # Show part 3 in the plot (optional)
    net.show_buttons(filter_=['physics']) # Show part 3 in the plot (optional)
  return net

def draw_interactive(A: torch.Tensor, *args, show_selections=False, show_options=False, **kwargs) -> None:
  net = generate_pyvis_network(A, *args, show_selections=show_selections, show_options=show_options, **kwargs)
  # generate html page
  net.show('g.html', notebook=False)

if __name__ == '__main__':
  graph_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'graphs')
  graph_files = os.listdir(graph_dir)
  graph_files_defective = [ ]
  for graph_file in graph_files:
    print(graph_file, end=': ', flush=True)
    graph_file_abs = os.path.join(graph_dir, graph_file)
    try:
      A, name2id, id2name = ptgcl.cl.read_graph_from_file(graph_file_abs)
      print(f'Graph has {len(name2id)} nodes', end='; ', flush=True)
      if len(name2id) > 1000:
        print(f'skipping TG.', flush=True)
        continue
    except:
      print(f'Could not load file.')
      graph_files_defective.append(graph_file)
      continue
    r = tg_test_quiet(
      A,
      maxiter=1e3, theta=3
    )
    print(f'TG found {r.labels_.unique().size(0)} clusters, took {r.iter_} iterations.', flush=True)
  print(f'Defective graphs: {graph_files_defective}.')
