#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import os
import sys
import pprint

# run some tests
import pt_graph_cluster_lib as ptgcl # pip install --editable .

def test_cw(*args, **kwargs):
  if not 'random_seed' in kwargs:
    kwargs['random_seed'] = 42
  if not 'verbose' in kwargs:
    kwargs['verbose'] = True
  if not 'quiet' in kwargs:
    kwargs['quiet'] = False
  if not 'minweight' in kwargs:
    kwargs['minweight'] = .5
  A = ptgcl.cl.G_twentynodes(random_seed=kwargs['random_seed'])
  clustered = ptgcl.cw.cw(A, *args, **kwargs)
  show_test_results(clustered)
  assert len(clustered['labels'].keys()) == 2
  return

def test_cw_ssc(*args, **kwargs):
  if not 'random_seed' in kwargs:
    kwargs['random_seed'] = 1
  if not 'verbose' in kwargs:
    kwargs['verbose'] = True
  if not 'quiet' in kwargs:
    kwargs['quiet'] = False
  if not 'minweight' in kwargs:
    kwargs['minweight'] = .5
  if not 'binarize' in kwargs:
    kwargs['binarize'] = True
  A = ptgcl.cl.G_twentynodes()
  if not 'fixed_labels' in kwargs:
    fixed_labels = [ None ] * A.shape[0]
    fixed_labels[0] = 'class1'
    fixed_labels[-1] = 'class2'
    fixed_labels[2] = 'class3'
    kwargs['fixed_labels'] = fixed_labels
    clustered = ptgcl.cw.cw(A, *args, **kwargs)
    show_test_results(clustered)
    assert len(clustered['labels'].keys()) == 3
  return

# def test_cw_sparse():
#   A = ptgcl.cl.G_twentynodes(random_seed=42).to_sparse_coo()
#   clustered = ptgcl.cw.cw(A,)
#   show_test_results(clustered)
#   assert len(clustered['labels'].keys()) == 2
#   return  

def show_test_results(r):
  print(pprint.pformat(r))