## PyTorch-Graph-Cluster-Library

This package provides graph clustering algorithms based on pytorch.

https://packaging.python.org
https://setuptools.pypa.io/en/latest/userguide/development_mode.html



---
### Manage environment for development
   * create and activate environment:

    mamba env create -f ./environment.yml
    mamba activate ptgcl-dev
    
   * deactivate and delete environment:

    mamba deactivate
    mamba env remove -n ptgcl-dev

    * install package in development mode

    pip install --editable .

---
### Build and deploy

docker buildx build -t remstef/pytorchgraphclusterlib:latest --platform linux/arm64,linux/amd64 --push .

https://packaging.python.org/en/latest/guides/

Use PyPA’s build; make sure it is installed and run the build command in the same directory where the `pyproject.toml` file is located:

    python3 -m pip install --upgrade build

    python3 -m build

Direct install from source:
    
    python3 -m pip install --no-deps --force-reinstall .

Install from private github repository (certificate and access required):

    python3 -m pip install -U git+ssh://git@github.com/remstef/pytorch-graph-cluster-lib.git@main
    
Install from public github repository:
    
    python3 -m pip install git+https://github.com/remstef/pytorch-graph-cluster-lib.git@main

Prepare deployment on [pypi.org](http://pypi.org) or [test.pypi.org](http://test.pypi.org):
   * Create an API token on the website.
   * You can use Twine to upload the distribution packages; install Twine:

    python3 -m pip install --upgrade twine

Deploy package with Twine to upload all of the archives under `./dist`:
   * You will be prompted for a username and password. 
   * For the username, use _\_\_token\_\__. For the password, use the API token value, including the pypi-prefix.
        
    python3 -m twine upload --repository testpypi dist/*

Install from pypi:

    python3 -m pip install --no-deps --force-reinstall pt_graph_cluster_lib
    
Or from test.pypi:
    
    python3 -m pip install --no-deps --force-reinstall --index-url https://test.pypi.org/simple pt_graph_cluster_lib


run app with:

    python -m src.pt_graph_cluster_lib.app


### Cloud Deployment
Services are running in:
* Azure Container Instances (offline): https://ptgcl-tg-demo.gentlepebble-18b1d684.germanywestcentral.azurecontainerapps.io
* Google Cloud Kubernetes (offline): http://34.116.225.214/
* Google Cloud Run: https://ptgcl-tg-demoapp-798830512535.europe-west3.run.app/
