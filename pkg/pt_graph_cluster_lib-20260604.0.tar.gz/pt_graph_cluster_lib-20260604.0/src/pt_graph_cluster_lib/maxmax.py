#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 20:03:54 2020

https://link.springer.com/chapter/10.1007%2F978-3-642-37247-6_30

procedure MaxMax(G = (V, E))
  construct a directed graph G′ = (V,E′) where:
  (v,u)∈ E′ iff (u,v)∈ E and v is one of the maximal vertices for u
  mark all vertices of G′ initially as root
  for each vertex v of G′ do
    if v is marked root then
      mark any descendant u of v (u ̸= v) as ¬root
    end if
  end for
end procedure

@author: rem
"""

import torch
from . import cl

def maxmax_test():
  return maxmax(cl.G_maxmax())

def __direct_descendants__(M, i):
  return M[i,:].nonzero(as_tuple=False)[:,0]

def __all_descendants__(M, i):
  return __traverse__(M, i, i, torch.zeros(M.size(0), dtype=bool).to(M.device)).nonzero(as_tuple=True)[0]

def __traverse__(M, i_start, i_current, visited):
  for j_current in __direct_descendants__(M, i_current):
    if j_current != i_start and not visited[j_current]:
      visited[j_current] = True
      __traverse__(M, i_start, j_current, visited)
  return visited

# complete
def __transform_sort__(M):
  N = M.size(0)
  # convert to directed graph
  # get most valuable edge and use it as the only! incoming edge, remove diagonals (self-loops)
  M[(range(N), range(N))] = 0
  s = M.sort(dim=1, descending=True)
  # set the top entries
  M.fill_(0)
  M[s.indices[:,0], range(N)] = 1
  # in case of ties, i.e. multiple top edges also set the values of those
  for i in range(1,N):
    more = (s.values[:,0] == s.values[:,i])
    if not more.any():
      break
    M[s.indices[:,i][more], more.nonzero(as_tuple=False)[:,0]] = 1
    del more
  del s
  return M

# approx
def __transform_top__(M,k=100):
  N = M.size(0)
  k = min(k, N)
  # convert to directed graph
  # get most valuable edge and use it as the only! incoming edge, remove diagonals (self-loops)
  M[(range(N), range(N))] = 0
  t = M.topk(dim=1, k=k)
  # set the top entries
  M.fill_(0)
  M[t.indices[:,0], range(N)] = 1
  # in case of ties, i.e. multiple top edges, set the values of those too
  for i in range(1,k):
    more = (t.values[:,0] == t.values[:,i])
    if not more.any():
      break
    M[t.indices[:,i][more], more.nonzero(as_tuple=False)[:,0]] = 1
    del more
  del t
  return M

def maxmax(A, out=['rootnodes'], random_seed=0):
  rand_generator = torch.Generator()
  rand_generator.manual_seed(random_seed)
  # number of nodes
  N = A.size(0)
  # stage 1:
  __transform_top__(A)
  # stage 2:
  isroot = torch.ones(N, dtype=torch.bool).to(A.device)
  
  for v in torch.randperm(N, generator=rand_generator): #random_generator.sample(range(N), N):
    if isroot[v]:
      desc = __all_descendants__(A, v)
      isroot[desc] = False
  # stage 3: interpret clusters by traversing each root node
  labels = { }
  for i in isroot.nonzero(as_tuple=False)[:,0].tolist():
    labels[i] = [ i ] + __all_descendants__(A, i).tolist()
  res = {'labels': labels }
  if 'rootnodes' in out:
    res['rootnodes'] = isroot
  else:
    del isroot
  return res



