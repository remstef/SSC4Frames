#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import logging

def set_log_verbosity(logger: logging.Logger, verbose: bool = False, quiet: bool = False) -> None:
  """
  """
  if verbose:
    logger.setLevel(logging.DEBUG)
  else:
    if quiet:
      logger.setLevel(logging.ERROR)
    else:
      logger.setLevel(logging.INFO)


