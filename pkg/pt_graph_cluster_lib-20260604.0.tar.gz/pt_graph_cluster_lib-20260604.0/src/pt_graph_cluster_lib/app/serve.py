#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

run with:

    ...

@author: remstef
"""

import os, time
import pathlib
import toml
from tempfile import NamedTemporaryFile
from typing import Any
import numpy as np
import threading
import json
from .TGObserver import TGObserver
import threading
import subprocess
import importlib.metadata

# set up logging
import logging

logger = logging.getLogger(__name__.split('.')[-1])
if not logger.handlers:
  # logger.propagate = False
  logger.setLevel(logging.INFO)
  consolehandler = logging.StreamHandler()
  consolehandler.setLevel(logging.DEBUG)
  consolehandler.setFormatter(logging.Formatter('T%(thread)d %(asctime)s:%(name)s:%(levelname)s: %(message)s'))
  logger.addHandler(consolehandler)

from tornado.web import Application
from tornado.httputil import HTTPServerRequest
import tornado.web
import tornado.httpserver
import tornado.ioloop
import tornado.websocket
import tornado.options
import uuid
import asyncio

# Try to use uvloop if available
try:
  import uvloop # type: ignore
  asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
  logger.info('✅ Using uvloop for faster event loop')
except ImportError:
  logger.warning('⚠️ uvloop not installed, using default asyncio loop')

simplegraph = {
  'nodes': [  
    { 'id': 1, 'group': 1, 'label': 'A', 'degree': 1, 'title': 'A|c1' },
    { 'id': 2, 'group': 2, 'label': 'B', 'degree': 1, 'title': 'B|c2' },
    { 'id': 3, 'group': 3, 'label': 'C', 'degree': 1, 'title': 'C|c3' },
    { 'id': 4, 'group': 4, 'label': 'D', 'degree': 1, 'title': 'D|c4' }
  ],
  'links': [
    { 'source': 1, 'target': 1, 'value':.1 },
    { 'source': 3, 'target': 3, 'value':.1 },
    { 'source': 1, 'target': 2, 'value':.1 },
    { 'source': 2, 'target': 1, 'value':.1 },
    { 'source': 2, 'target': 3, 'value':.1 },
    { 'source': 3, 'target': 2, 'value':.1 }
  ]
}

def _get_pyproject_name_and_version():
  # Try to read from pyproject.toml (development mode)
  try:
    root = pathlib.Path(__file__).parent.parent.parent.parent
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
      data = toml.load(pyproject)
      name = data["project"]["name"]
      version = data["project"]["version"]
      return f"{name} v{version}"
  except Exception:
    pass
  # Fallback: use importlib.metadata (installed package)
  try:
    name = __package__ or "pt-graph-cluster-lib"
    version = importlib.metadata.version(name)
    return f"{name} v{version}"
  except Exception:
    return "pt-graph-cluster-lib vUNKNOWN"

class VersionHandler(tornado.web.RequestHandler):
  # _git_revision_short_hash = subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD'], cwd=os.path.dirname(os.path.abspath(__file__))).decode('ascii').strip()
  _pyproject_name_and_version = _get_pyproject_name_and_version()
  # _pyproject_name_and_version = f'{__package__ or "pt-graph-cluster-lib"} version {importlib.metadata.version(__package__ or "pt-graph-cluster-lib")}'
  def get(self):
    self.write(f'{self._pyproject_name_and_version}')


class RedirectHandler(tornado.web.RequestHandler):
  def __init__(self, application: Application, request: HTTPServerRequest, dest: str, **kwargs: Any) -> None:
    super().__init__(application, request, **kwargs)
    self.get = lambda: self.redirect(dest)
    
class Base64FaviconHandler(tornado.web.RequestHandler):
  def get(self): # https://base64.guru/converter/encode/image/ico
    self.write('data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACqElEQVQ4T4VTTUhUURQ+9737fo35iSQLpLSEaCEEs3ARSZsowlUwC6V24ahUIFpjjPkqcyowMDB/EILIVW0CQWojZJugqCxiikyExIQxZ5hG37x3732dFykzlnThwLvnvvud7zvnuwSKlmVZak4rP6VTekKmcq0QvFJ4POAJkCkhOUr1FCXS47cZY+CRFXX8q2T9fqc1WCHr3pSm6QcUXYef2RUghACRJBBCwGo+D5wxqNxTBQJg5HJzY6wEoOWiFaOqOUQVCctRkIgEnueB4AxcxwWXuRAIhiAY3gHL6cUv/Yn2mhKA5MDY8Txnk06hgJWwBnggIwghMqi6ChRZubYN2UwaFKrN3unp2F8CYFlTVN+1+AlVVXsoOpfLAnMdYIwD4y74vA1TB7MsAKqqPe+KNdWXAPibKzeHG2RTf6KqlLguxwYJlEIBZA/BGBiaAQJlMc7uJtrOXPgLwE+cvdR9XZG0hIS9AEEQAEOmEAyFQEcZ2UwGMtmVhuFk98Q/AfzkteHxfol77UQm4KytQgH74jgYzEEW5kJ2Xq8aHW1GXUVj3OQHyayoeSmIFHGcNeBcAKUKUFVGVlJbV6zx3vr/Gz4oBvC/W+JXOzXdvK0oChAPYFsgCIqmfahr/nzoKFjsvwC9o+OnRcF5gANBnh56wREe4/U34m0viottyaBv6GHcdZ3kj3QancgxnFuDfT3xzUy3BDiXSD4NhrcfMwwDZEl+Zn9vOmlZsEG9RAJalrz6OD8GhDcS4JMzb5Y6FlZmU7ZtK7qmTx85XDdiarSWsMz9SG0kVSJhemImbFSX9aJ1W9G4vuEgb9tLy8uZnZqmQnkovCCpZDce4MuCb1/fv94bjUb5BoN3qbnzrhADvxO+IOx4yfJHwPEAffVnDUUO7mtd3/wCfn0SINO23OcAAAAASUVORK5CYII=')

class SimpleFileHandler(tornado.web.RequestHandler):
  def __init__(self, application: Application, request: HTTPServerRequest, filename: str, **kwargs: Any) -> None:
    super().__init__(application, request, **kwargs)
    self.get = lambda: self.render(filename)

class StaticJSONFileHandler(tornado.web.StaticFileHandler):
  def get_content_type(self):
    return 'application/json'

class UploadHandler(tornado.web.RequestHandler):
  def post(self):
    file = self.request.files['file'][0]
    original_filename = file['filename']
    index_name = f'UPLOADED: {original_filename}'
    i = 0
    while index_name in TGObserver.get_available_networks():
      i += 1
      index_name = f'{index_name} ({i})'
    tempfile = NamedTemporaryFile()
    with open(tempfile.name, 'wb') as output_file:
      output_file.write(file['body'])
    TGObserver.add_to_available_networks(index_name, tempfile.name)
    try:
      TGObserver.load_net(index_name)
    except Exception as e:
      msg = str(e)
      cause = e.__cause__
      while cause:
        msg += f'\ncaused by: {str(cause)}'
        cause = cause.__cause__
      TGObserver.remove_from_available_networks(index_name)
      return self.write({'error': msg})
    return self.write({'name': index_name, 'filename': original_filename})

class SocketHandler(tornado.websocket.WebSocketHandler):
  '''
  Handler that handles a websocket channel
  '''
  def __init__(self, application: Any, request: HTTPServerRequest, allow_cross_origin:bool=False, **kwargs: Any) -> None:
    super().__init__(application, request, **kwargs)
    self._allow_cross_origin = allow_cross_origin
    self._id = None # not yet set
    self._client_id = None # not yet set
    self._observer = None # not yet set
    self._lock = threading.Lock()  # Initialize a thread lock
    if self._allow_cross_origin:
      # override check_origin method
      self.check_origin = lambda *args, **kwargs: True
    return

  def open(self):
    '''
    Client opens a websocket
    '''
    if self._id is None:
      self._id = str(uuid.uuid4())
      networks_available = TGObserver.get_available_networks()
      default_networks_available = list(filter(lambda item: not item.startswith('UPLOAD:'), networks_available))
      uploaded_networks_available = list(filter(lambda item: item.startswith('UPLOAD:'), networks_available))
      networks_available = sorted(default_networks_available, key=str.lower) + sorted(uploaded_networks_available, key=str.lower)
      self.notify(cmd='register', data={ 'uuid': self._id, 'networks_available': networks_available })
      logger.info(f'Connnection opened for socket `{self._id}`.')
    else:
      logger.info(f'Connnection for for socket `{self._id}` opened already.')
      self.notify(cmd='error', data={ 'message': 'already registered', 'uuid': self._id})
    return
  
  def on_message(self, message):
    '''
    Message received
    '''
    data = json.loads(message)
    logger.info(f'''Received `{data['cmd']}` command at socket `{self._id}`.''')
    # parse command and do whater needs to be done
    return self.parse_client_message(data)
  
  def parse_client_message(self, evt):
    cmd = evt.get('cmd', 'no-cmd')
    data = evt.get('data', {})
    metadata = evt.get('meta', {})
    not_implemented = lambda: logger.warning(f'Command `{cmd}` not yet implemented!.')
    switch = {
      'foo': lambda: self.foo(**data),
      'initnetwork': lambda: self.setup_observer(**data),
      'disconnect': not_implemented,
      'getstate': lambda: self._observer.get_current_state(listener=self, **data),
      'continue': lambda: self._observer.continue_execution(**data),
      'restart': lambda: self._observer.restart(**data),
      'getnodeinfo': lambda: self._observer.get_info(listener=self, **data),
    }
    if cmd in switch:
      # reply with an acknowledgement that we received the message and can do something with it
      self.notify(cmd='acknowledge', data= { 'message': cmd, 'uuid': self._id })
    else:
      self.notify(cmd='refuse', data={ 'message': f'Invalid command `{cmd}`', 'uuid': self._id })
    try:
      switch.get(cmd, lambda: print(f'Invalid command `{cmd}`.'))()
    except Exception as e:
      msg = str(e)
      cause = e.__cause__
      while cause:
        msg += f'\ncaused by: {str(cause)}'
        cause = cause.__cause__      
      return self.notify(cmd='error', data={ 'request_cmd': cmd, 'uuid': self._id, 'request_metadata': metadata, 'message': msg })
    return self.notify(cmd='success', data={ 'request_cmd': cmd, 'uuid': self._id, 'request_metadata': metadata })
  
  def foo(self, sleep=0):
    if np.random.random() > 0.5:
      raise Exception('Random foo exception.')
    time.sleep(sleep)
    return self.notify(cmd='bar', data={ 'uuid': self._id })

  def on_close(self):
    '''
    Close the websocket
    '''
    logger.info(f'Connection closed `{self._id}`.')
    if self._observer is not None:
      self._observer.detach(self)
      self._observer.stop_and_join_thread()
      self._observer = None
    self._id = None
    return

  def log_message(self, msg):
    logger.info(msg)
    return self.notify(cmd='serverlog',  data={'message': str(msg)})

  def notify(self, cmd, data={}):
    with self._lock:
      # async def wrapper() -> None:
      #   await self.write_message({ 'cmd': cmd, 'data': data })
      result = asyncio.shield(self.write_message({ 'cmd': cmd, 'data': data }))
      time.sleep(.01) # this seems like a hack, but it seems we need to give the client some time to process the messages
      return result    
  
  def setup_observer(self, filename='7-bisnake.graph', resizenodes=False, **kwargs):
    # create the observer instance for observing the clustering process
    self.log_message(f'''Loading network '{filename}' for uuid '{self._id}'.''')
    if self._observer is not None:
      self._observer.detach(self)
      self._observer.stop_and_join_thread()
      self._observer = None
    try:
      self._observer = TGObserver(resize_nodes=resizenodes)
      # TODO: use threading to load the network
      self._observer.load_net_and_clusterer(filename=filename, **kwargs)
      self._observer.run()
    except Exception as e:
      self.notify(cmd='error', data={ 'message': str(e), 'uuid': self._id })
      cause = e.__cause__
      while cause:
        self.notify(cmd='error', data={ 'message': f'caused by: {str(cause)}', 'uuid': self._id })
        cause = cause.__cause__
      return None
    self.log_message(f'''Network '{filename}' successfully loaded for uuid '{self._id}'.''')
    self._observer.attach(self)
    self.notify(cmd='activate', data={ 'uuid': self._id, 'networkname': filename })
    self._observer.get_current_state(self)
    return None
    

def main(port=8888, host='0.0.0.0', allow_cross_origin=True, filepath='tests/graphs'): # , filename=None, theta=10, resizenodes=False):  
  for fname in os.listdir(filepath):
    TGObserver.add_to_available_networks(fname, os.path.join(filepath, fname))
  # Create tornado application and supply URL routes
  app = tornado.web.Application([
    # ( Route, Handler, kwargs )
    (r"/favicon.ico", Base64FaviconHandler, { }),
    (r"/", RedirectHandler, { "dest": "v2" }),
    (r"/v1", SimpleFileHandler, { "filename": "serve.html" }),
    (r"/v2", SimpleFileHandler, { "filename": "serve_dash_twreact.html" }),
    (r"/websocket", SocketHandler, { 'allow_cross_origin' : allow_cross_origin }),  
    (r"/upload", UploadHandler, { }),
    (r"/version", VersionHandler, { }),
  ])
  # Setup HTTP Server
  http_server = tornado.httpserver.HTTPServer(app)
  http_server.listen(port=port, address=host)
  print(f'Server running at http://{host}:{port}. Press <CTRL-C> to stop server.', flush=True)

  # Spawn as many processes as CPU cores
  # tornado.process.fork_processes(0)
  
  try:
    # Start IO/Event loop
    tornado.ioloop.IOLoop.current().start()
    # tornado.ioloop.IOLoop.instance().start()
  except KeyboardInterrupt:
    print(f'Manually initiated server shutdown.', flush=True)
  return 