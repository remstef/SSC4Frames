from .app import serve
import fire

fire.Fire(serve.main, name='serve')