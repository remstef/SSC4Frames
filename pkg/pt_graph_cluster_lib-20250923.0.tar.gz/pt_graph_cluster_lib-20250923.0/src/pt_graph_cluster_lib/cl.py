#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  6 13:30:00 2020

@author: rem
"""

import warnings
import os, sys
import gzip
import numpy as np
import io
import math
import torch
import bcubed
from sklearn.cluster import DBSCAN, OPTICS, SpectralClustering, AffinityPropagation
from sklearn import metrics
from scipy.optimize import root_scalar
import re

# set up logging
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
consolehandler = logging.StreamHandler()
consolehandler.setLevel(logging.DEBUG)
consolehandler.setFormatter(logging.Formatter('T%(thread)d %(asctime)s:%(name)s:%(levelname)s: %(message)s'))
logger.addHandler(consolehandler)

def read_graph_from_file(filename: str, regex: str = r'^\s*(?P<src>\S+)\s+(?P<dst>\S+)(\s+(?P<w>\b\d+([\.,]\d+)?\b))?\s*$', dtype: torch.dtype = torch.float) -> tuple[torch.Tensor, dict[str,int], dict[int,str]] :
  pattern = re.compile(regex)
  openfun = open
  if not os.path.exists(filename) and os.path.isfile(filename):
    raise FileNotFoundError(f"file '{filename}' not found.")
  if filename.endswith('.gz'):
    openfun = gzip.open  
  nodes = { }
  edges = [ ]
  with openfun(filename, 'rt') as fh:
    for i, line in enumerate(fh, start=1):
      line_ = line
      try:
        line_ = line.strip()
        if not len(line_):
          continue
      except Exception as e:
        logger.error(f"Error in line {i}: '{line_}': {e}")
        raise ValueError(f"Error in line {i}: '{line_}'") from e
      try:
        m = pattern.search( line_ )
        if not m:
          raise ValueError(f"Pattern '{regex}' not found.")
        src = m.group('src')
        dst = m.group('dst')
        w = m.group('w')
        if not dst:
          raise ValueError('No destination found.')
        if not src:
          raise ValueError('No source found.')
      except Exception as e:
        logger.error(f"Error in line {i}: '{line_}': {e}")
        raise ValueError(f"Error in line {i}: '{line_}'") from e
      nodes[src] = nodes.get(src, len(nodes))
      nodes[dst] = nodes.get(dst, len(nodes))
      edges.append((nodes[src], nodes[dst], float(w) if w else float(1.)))
  logger.debug(f"nodes: {len(nodes)}; edges: {len(edges)}; from file: '{filename}'")
  A = torch.zeros((len(nodes), len(nodes)), dtype=dtype)
  logger.debug(f"G: {A.size()}")
  edgesrcs, edgedsts, edgews = list(zip(*edges))
  A[(edgesrcs, edgedsts)] = torch.tensor(edgews, dtype=dtype)
  ids = { v:k for k,v in nodes.items() }
  return A, nodes, ids

def rescale_edge_weights(A: torch.Tensor, new_min: float = 1.0, new_max: float = 10.0) -> torch.Tensor:
    """
    Rescale all nonzero edge weights in A to the interval [new_min, new_max].
    """
    mask = A > 0
    if not mask.any():
      return A
    old_min = A[mask].min()
    old_max = A[mask].max()
    # Avoid division by zero if all values are the same
    if old_max == old_min:
      A[mask] = new_min
    else:
      old_diff = old_max - old_min
      new_diff = new_max - new_min
      A[mask] = (((A[mask] - old_min) / old_diff) * new_diff) + new_min
    return A

  
def get_net_as_dict(A:torch.Tensor, node_id_to_name:dict[int, str] = {}) -> dict:
  nodes = [ ]
  edges = [ ]
  # check if upper triangular is similar to lower triangular matrix 
  graph_is_undirected = torch.allclose(torch.tril(A), torch.triu(A).T)
  max_edge_weight = torch.max(A).item()
  min_edge_weight = torch.min(A[torch.nonzero(A, as_tuple=True)]).item()
  valrange_edge_weight = max_edge_weight - min_edge_weight
  valrange_newedge_weight = 3.-1.
  metainfo = { 
    'type': 'undirected' if graph_is_undirected else 'directed' ,
    'min_edge_weight': min_edge_weight,
    'max_edge_weight': max_edge_weight,
    'min_edge_weight_scaled': 1,
    'max_edge_weight_scaled': 3 if valrange_edge_weight > 0 else 1
  }
  for vi in range(A.size(0)):
    vi_name = node_id_to_name.get(vi, f'v{vi}')
    nodes.append({
      'id': vi,
      'name': vi_name,
      'label': f'{vi_name}|v{vi}|c{-1}',
      'group': -1,
      'title': f'{vi_name}|v{vi}|c{-1}',
      'size': 10
    })
    for vj in range(vi, A.size(1)) if graph_is_undirected else range(A.size(1)):
      if A[vi, vj] > 0:
        key = f'{vi}->{vj}'
        keyid = len(edges)
        edges.append({
          'id': keyid,
          'key': key,
          'srcid': vi,
          'dstid': vj,
          'weight' : A[vi, vj].item(),
          'weight_scaled' :  1. if valrange_edge_weight == 0 else (((A[vi, vj].item() - min_edge_weight) / valrange_edge_weight) * valrange_newedge_weight) + 1.
        })
  return { 'nodes': nodes, 'edges': edges, 'meta': metainfo }


def G_twentynodes(random_seed=0):
  generator = torch.Generator()
  generator.manual_seed(random_seed)
  twentynodes = torch.rand((20,20), generator=generator) * .5
  twentynodes[:10,:10] += .5
  twentynodes[10:,10:] += .5
  return twentynodes


def G_twentynodes_true_labels():
  labels = torch.zeros(20, dtype=torch.uint8)
  labels[:10] = 1
  labels[10:] = 2
  return labels


def G_twentynodes_bin(random_seed=0):
  twentynodes = torch.ones((20,20), dtype=torch.uint8)
  twentynodes[:10,10:] = 0
  twentynodes[10:,:10] = 0
  return twentynodes


def G_twentynodes_equidist(n=20):
  '''
  Produce equidistant graph of twenty (n) nodes having the first n/2 
  nodes direct connections to the first nodes and the last n/2 
  nodes direct connections to the last nodes
  
  Example:
  [
   [0,1,2,3,...]
   [1,0,2,3,...]
   [1,2,0,3,...]
   ...
   [...,3,0,2,1]
   [...,3,2,0,1]
   [...,3,2,1,0]
  ]
  '''
  G = torch.zeros((n,n),dtype=torch.uint8)
  G[0,:] = torch.arange(n,dtype=torch.uint8)
  for i in range(1,n):
    if i < n // 2:
      G[i,:] = torch.cat((
        torch.arange(1,i+1,dtype=torch.uint8), 
        torch.zeros((1,),dtype=torch.uint8), 
        torch.arange(i+1,n,dtype=torch.uint8)
      ))
    else:
      G[i,:] = torch.flip(G[n-i-1,:], dims=(0,))
  return G


def G_twentynodes_equidist2(n=20):
  '''
  Produce equidistant graph of twenty (n) nodes such that the k nearest neighbors 
  of a node i are left (i-k) and right (i+k) to the node i, and distances to the 
  first n/2 nodes to the last n/2 nodes are maximized
  
  Example:
  [
   [0,1,2,3,...,n,n,n,n]
   [1,0,1,2,...,n,n,n,n]
   [2,1,0,1,...,n,n,n,n]
   ...
   [n,n,n,n,...,1,0,1,2]
   [n,n,n,n,...,2,1,0,1]
   [n,n,n,n,...,3,2,1,0]
  ]
  '''
  G = torch.zeros((n,n),dtype=torch.uint8)
  # G[:,0] = torch.range(0,n-1)
  for i in range(n):
    if i < n // 2:
      G[i,:] = torch.cat((
        torch.flip(torch.arange(1,i+1,dtype=torch.uint8),dims=(0,)), 
        torch.arange(0,n//2-i,dtype=torch.uint8),
        torch.ones(n//2,dtype=torch.uint8)*n
        ))
    else:
      G[i,:] = torch.flip(G[n-i-1,:], dims=(0,))
  return G


def G_maxmax():
  '''
  Sample graph from the MaxMax paper
  '''
  (r,s,t,u,v,w,x) = (0,1,2,3,4,5,6)
  G = torch.zeros((7,7), dtype=torch.long)
  G[r, s] = 3
  G[r, t] = 2
  G[r, u] = 1
  G[r, v] = 1
  G[r, w] = 2
  G[r, x] = 2
  G[s, t] = 1
  G[s, u] = 2
  G[s, v] = 2
  G[s, w] = 2
  G[t, v] = 1
  G[t, w] = 2
  G[t, x] = 1
  G[u, v] = 1
  G[v, w] = 1
  G[w, x] = 4
  G.add_(G.T.clone())
  return G


def vecindex2matindex(vecindex, rowlength):
  (ri,ci) = vecindex//rowlength, vecindex%rowlength
  return ri, ci


def matindex2vecindex(matindex, rowlength):
  (ri,ci) = matindex
  vi = (ri*rowlength)+ci
  return vi


def connectivity(A, N=None):
  if not N:
    N = A.size(0)
  maxconnections = N * N
  connections = A.nonzero(as_tuple=False).size(0)
  connectivity = connections / maxconnections
  return connectivity


def interconnectivity(A):
  N = A.size(0)
  if N < 2:
    return 1
  maxconnections = (N * N) - N # fully connected w/o self connections 
  d = A[range(N), range(N)] # remember diagonal values
  A[range(N), range(N)] = 0 # make sure diagonals are zero
  connections = A.nonzero(as_tuple=False).size(0) # count the number of connections
  interconnectivity = connections / maxconnections # get the ratio
  A[range(N), range(N)] = d # reset diagonal entries
  return interconnectivity


def interconnectivity_val(A, normalize=False):
  N = A.size(0)
  if N < 2:
    return 1
  maxval = (N * N) - N # fully connected w/o self connections and every connection value is 1
  d = A[range(N), range(N)] # remember diagonal values
  A[range(N), range(N)] = 0 # make sure diagonals are zero
  connections_val = A.sum() # sum the connection values of all connections
  interconnectivity_val = connections_val / maxval # get the ratio  
  if normalize:
    connections = A.nonzero(as_tuple=False).size(0)
    interconnectivity = connections / maxval # maxconnections == max_val
    interconnectivity_val /= interconnectivity  
  A[range(N), range(N)] = d # reset diagonal entries  
  return interconnectivity_val.item()


def mean_local_clustering_coefficient(A, sample=None, random_seed=0):
  if sample:
    generator = torch.Generator()
    generator.manual_seed(random_seed)
    random_sample = torch.randperm(A.size(0), generator=generator)[:min(sample, A.size(0))] # random.sample(range(A.size(0)), min(sample, A.size(0)))
  else:
    random_sample = range(A.size(0))
  coef = torch.tensor([local_clustering_coefficient(A, int(i)) for i in random_sample], dtype=torch.float).mean()
  return coef.item()


def local_clustering_coefficient(A, i=0):
  Ni_ = A[i,:].nonzero(as_tuple=False)[:,0] # neighbors
  Ni = Ni_[Ni_ != i] # neighbors w/o self
  ki = Ni.size(0) # number of neighbors
  if ki <= 1:
    return 0
  # Mi = A[Ni,:][:,Ni] # sub-matrix of neighbor connections
  Mi = A[Ni.repeat_interleave(Ni.size(0)), Ni.repeat(Ni.size(0))]
  coef = Mi.nonzero(as_tuple = False).size(0) /  (ki * (ki-1)) # number of neighbor connections divided by the theoretical number of maximum conncections
  return coef


def mean_local_neighbors(A, normalize=False):
  coef = torch.tensor([local_neighbors(A, i, normalize) for i in range(A.size(0))], dtype=torch.float).mean()
  return coef.item()


def local_neighbors(A, i, normalize=False):
  Ni_ = A[i,:].nonzero(as_tuple=False)[:,0] # neighbors
  Ni = Ni_[Ni_ != i] # neighbors w/o self
  ki = Ni.size(0) # number of neighbors
  if normalize:
    return ki / (A.size(0)-1) # normalize by max number of neighbors
  return ki


def shortest_path_distances(A, num_hops=True, dists=True):
  N = A.size(0)
  assert A.size(1) == N
  # initialize distances D and number of hops H
  D, H = torch.tensor([[dists]], dtype=torch.bool), torch.tensor([[num_hops]], dtype=torch.bool)
  if dists:
    D = torch.full((N,N), float('inf'), dtype=torch.float, device=A.device)
    D = torch.where(A > 0, A, D)
  if num_hops:
    H = torch.full((N,N), float('inf'), dtype=torch.float16, device=A.device)
    H = torch.where(A > 0, 1, H)

  # floyd-warshal algorithm to compute all distances
  for k in range(N):
    if dists:
      D = torch.minimum(D, D[:,k].unsqueeze(1) + D[k,:].unsqueeze(0))
    if num_hops:
      H = torch.minimum(H, H[:,k].unsqueeze(1) + H[k,:].unsqueeze(0))
  
  return D, H



def diameter(A):
# https://www.youtube.com/watch?v=SumKq0Jx1L0
# epsilon(u) = eccentricity of a vertex u = longest shortest path between vertex u and any other vertex v == maximum distance between u and any other vertex of G
# radius = rad(G) = minimum eccentricity of a graph = minimum eccentricity between any two vertices u and v
# diameter = diam(G) = maximum eccentricity of a graph = maximum eccentricity between any two vertices u and v
#
# https://www.youtube.com/watch?v=CwMCWQtNhtY
# diam(G) = diameter is the longest shortest path between any two nodes == maximum distance between any two vertices of G
#
#   The eccentricity ϵ ( v ) {\displaystyle \epsilon (v)} \epsilon (v) of a vertex v {\displaystyle v} v is the greatest distance between v {\displaystyle v} v and any other vertex; in symbols that is ϵ ( v ) = max u ∈ V d ( v , u ) {\displaystyle \epsilon (v)=\max _{u\in V}d(v,u)} {\displaystyle \epsilon (v)=\max _{u\in V}d(v,u)}. It can be thought of as how far a node is from the node most distant from it in the graph.
#   The diameter d {\displaystyle d} d of a graph is the maximum eccentricity of any vertex in the graph. That is, d {\displaystyle d} d is the greatest distance between any pair of vertices or, alternatively, d = max v ∈ V ϵ ( v ) {\displaystyle d=\max _{v\in V}\epsilon (v)} d=\max _{v\in V}\epsilon (v). To find the diameter of a graph, first find the shortest path between each pair of vertices. The greatest length of any of these paths is the diameter of the graph.
  pass


def keep_topk_edges_by_criterium(A, removediagonals = True, stepsize=100, remove_symmetrically=True, criterium=lambda M: M.nonzero(as_tuple=False) <= M.size(0), add_edges=True, sort_on_device=torch.device('cpu')):
  N = A.size(0)
  assert N == A.size(1)
  if removediagonals:
    A[(range(N), range(N))] = 0
  a = A.view(-1)
  if stepsize < 0:
    raise Exception('negative number for stepsize not allowed')
  if stepsize < 1: # interpret as percentage
    maxedges = (N*N) if removediagonals else (N*(N-1))
    maxedges = maxedges / 2 if remove_symmetrically else maxedges
    step = max(2 if remove_symmetrically else 1, int(stepsize * maxedges))
  else:
    step = max(1, stepsize)
    if remove_symmetrically:
      step=step*2
  half_step = step//2
  # nz = a.nonzero(as_tuple=False)[:,0]
  if add_edges:
    # s = a[nz].sort(descending=True)
    s = a.to(sort_on_device).sort(descending=True)
    a.fill_(0)
    for i in range(0, s.indices.size(0) - step, step):
      if s.values[i+half_step] <= 0 or not criterium(A):
        break
      # a[nz[s.indices[i:i+step]]] = s.values[i:i+step]
      a[s.indices[i:i+step]] = s.values[i:i+step].to(a.device)
  else: # remove
    # s = a[nz].sort(descending=False)
    s = a.to(sort_on_device).sort(descending=False)
    for i in range(0, s.indices.size(0) - step, step):
      if s.values[i+half_step] > 0 or not criterium(A):
        break
      # a[nz[s.indices[i:i+step]]] = 0
      a[s.indices[i:i+step]] = 0
  return A # all changes in a are reflected in A, no need to change the view


def keep_topk_edges(A, topk, removediagonals = True, graph_is_symmetric=True):
  N = A.size(0)
  assert N == A.size(1)
  max_edges = N*N-N if removediagonals else N*N
  if graph_is_symmetric:
    max_edges /= 2
  if topk < 1: # topk is a percentage, make explicit
    topk = int(max_edges * topk)
  if topk > max_edges:
    topk = max_edges
  if removediagonals:
    A[(range(N), range(N))] = 0
  a = A.view(-1)
  if graph_is_symmetric:
    topk=min(topk*2, N*N)
  t = a.topk(topk)
  a.fill_(0)
  a[t.indices] = t.values
  return A # all changes in a are reflected in A, no need to change the view


def keep_topk_neighbors(A, topk, removediagonals = True, dim=1, force_symmetry_by_addition=True):
  '''
  Parameters
  ----------
  A : adjacency matrix A[i,j] -> edge from (i to j)
  topk : top k
  removediagonals : include diagonals (self-loops) in top k?
  dim : prune by dim (0 = incoming edges, 1 = outgoing edges)
  force_symmetry_by_addition : restore symmetry by adding edges to respective other dimension

  Returns
  -------
  B : pruned adjacency matrix

  '''
  N = A.size(0)
  assert N == A.size(1)
  max_edges = N-1 if removediagonals else N
  if topk < 1: # topk is a percentage
    topk = int(max_edges * topk)
  if topk > max_edges:
    topk = max_edges
  if removediagonals:
    A[(range(N), range(N))] = 0
  t = A.topk(dim=dim, k=topk, largest=True, sorted=True)
  A.fill_(0)
  # update A
  # t.indices: shape (N, topk), t.values: shape (N, topk)
  rows = torch.arange(N).unsqueeze(1).expand(-1, topk)  # shape (N, topk)
  if dim == 0:
    for k in range(topk):
      A[t.indices,rows] = t.values
      if force_symmetry_by_addition:
        A[rows, t.indices] = t.values
  elif dim == 1:
    A[rows, t.indices] = t.values
    if force_symmetry_by_addition:
      A[t.indices,rows] = t.values
  else:
    raise Exception('dim > 1 not defined.')
  return A


def get_dtype_max(dtype):
  if dtype.is_floating_point:
    return torch.finfo(dtype).max
  # else
  return torch.iinfo(dtype).max


def __natural_break_by_diff__(values:torch.Tensor) -> torch.Tensor:
  '''
    Find a natural break point in a sequence of values (only the first break point).
    The values have to be sorted.
    This method comes with many names.
      * find a rupture
      * find a knee/elbow point
      * find natural breaks
    This method finds a break by finding the arg max in the differences of the previous element.
    The result is an index at location k, The index at location found is the break, the value at the index is included.
    Example:
      In a sequence [1,2,3,5,10,20], the returned index k is 5, the break is between index k and k-1, 
      i.e. the value at k is excluded.
  '''
  diffs = torch.diff(values, dim=1)
  break_indices = torch.argmax(diffs, dim=1)+1
  # fix zero indices
  break_indices = torch.where(break_indices == 0, diffs.size(1), break_indices)
  return break_indices



def __umap_find_sigma_i_single_scipy__(distances, rho_i, k, max_iter=100, sigma_min=1e-5, sigma_max=1e5, atol=1e-8, rtol=1e-5):
  """
  Solves for sigma_i given distances d_{i,j} and number of neighbors k.

  Parameters:
      distances (array-like): d_{i,j} for j=1 to k
      k (int): Number of neighbors
      sigma_min, sigma_max (float): Bounds for root finding

  Returns:
      sigma_i (float): The value of sigma_i that satisfies the equation
  """
  d_ij = distances - rho_i
  log_k = np.log2(k)

  def objective(sigma):
    return np.sum(np.exp(-d_ij / sigma)) - log_k

  result = root_scalar(objective, method='bisect', bracket=[sigma_min, sigma_max], xtol=atol, rtol=rtol, maxiter=max_iter)

  if result.converged:
    return result.root, result
  else:
    raise RuntimeError("Failed to converge to a solution for sigma_i.")
  

def __umap_find_sigma_i_single__(distances, rho_i, k, bandwidth=1., atol=1e-5, rtol=1e-3, max_iter=100, sigma_min=1e-5, sigma_max=1e5):
  """
  DEPRECATED, only for testing purposes, use batched version '__umap_find_sigma_i__' instead!

  Solves for sigma_i using binary search.

  Parameters:
    distances (torch.Tensor): shape (k,)
    rho_i (float): rho_i
    k (int): number of neighbors
    bandwidth (float): 
    tol (float): convergence tolerance
    max_iter (int): maximum number of binary search iterations

  Returns:
    sigma_i (float): the value of sigma_i
  """
  warnings.warn('DEPRECATED, only for testing purposes, use batched version __umap_find_sigma_i__ instead!', DeprecationWarning)
  log_k = torch.log2(torch.tensor(float(k))) * torch.tensor(bandwidth)
  # Ensure tensor is float32 or float64
  distances = distances.to(dtype=torch.float32)
  # precompute d_ij
  d_ij = distances-rho_i
  #
  low = torch.tensor(sigma_min)
  high = torch.tensor(sigma_max)
  mid = torch.tensor(1.)
  weights = d_ij
  zero = torch.zeros((1,))
  #
  iter = 0
  ln2 = torch.log(torch.tensor(2))
  for iter in range(max_iter):
    # mid = (low + high) / 2.0
    mid = torch.exp(torch.log(low + high) - ln2)
    weights = torch.exp(-d_ij / mid)
    # weights = torch.exp(torch.exp(torch.log(-d_ij) - torch.log(mid)))
    s = torch.sum(weights)
    diff = s - log_k
    if torch.allclose(diff, zero, atol=atol, rtol=rtol): # torch.abs(diff) < tol:
      break
    if diff > 0:
      high = mid
    else:
      low = mid
  # Return approximate solution if tolerance not met
  return mid.item(), (weights, iter)


def __umap_find_sigma_i__(distances, rho_i, k, bandwidth=1., atol=1e-5, rtol=1e-3, max_iter=100, sigma_min=1e-5, sigma_max=1e5, dtype=torch.float32, device=None, add_rand_noise=False, add_rand_noise_if_necessary=True, max_rand_noise_amount=1e-4, rand_generator=None):
  """
  Solves for sigma_i for a batch of distance vectors using binary search.

  Parameters:
      distances (torch.Tensor): shape (batch_size, k), distances d_{i,j} for each i
      rho_is (torch.Tensor): shape (batch_size,), rho_i for each i
      tol (float): convergence tolerance
      max_iter (int): max iterations
      sigma_min, sigma_max (float): bounds for binary search

  Returns:
      sigma: torch.Tensor of shape (batch_size,) containing sigma_i for each row
  """

  batch_size, k_ = distances.size()
  log_k = torch.log2(torch.tensor(float(k), dtype=dtype, device=device)) * torch.tensor(bandwidth, dtype=dtype, device=device)
  d_ij =  distances - rho_i.unsqueeze(1).expand_as(distances)
  d_ij = torch.where(d_ij >= 0, d_ij, 0.)
  if add_rand_noise:
    d_ij[:,1:] += torch.rand((batch_size, k_-1), generator=rand_generator)*torch.tensor(max_rand_noise_amount, dtype=dtype, device=device) # add some random noise to avoid ties
  weights = d_ij
  zeros = torch.zeros((batch_size,1), dtype=dtype, device=device)

  # Initialize bounds
  low = torch.full((batch_size,), sigma_min, dtype=dtype, device=device)
  high = torch.full((batch_size,), sigma_max, dtype=dtype, device=device)
  mid = torch.ones((batch_size,), dtype=dtype, device=device)
  ln2 = torch.log(torch.tensor(2, dtype=dtype, device=device))

  iter = 0
  for iter in range(max_iter):
    # mid = (low + high) / 2.0
    mid = torch.exp(torch.log(low + high) - ln2)
    mid_expanded = mid.unsqueeze(1).expand_as(d_ij)  # (batch_size, k)
    weights = torch.exp(-d_ij / mid_expanded) # (batch_size, k)
    sum_weights = torch.sum(weights, dim=1)  # (batch_size,)
    # Check for convergence
    diff = sum_weights - log_k
    if torch.allclose(diff, zeros, atol=atol, rtol=rtol):
      break
    # Binary update
    high = torch.where(diff > 0, mid, high)
    low = torch.where(diff <= 0, mid, low)    
  # END for
  if iter == max_iter-1:
    msg = (
      f"Binary search ran for maximum iterations ({iter+1})." 
      f" Sigma_i may not be exact (each sum of weights should: {log_k.item():.3f}, actual: [{', '.join([f"{s:.3f}" for s in sum_weights.tolist()])}])."
      " Re-running search with additive random noise." if not add_rand_noise and add_rand_noise_if_necessary else ""
    )
    logger.warning(msg)
    warnings.warn(msg, UserWarning)
    if not add_rand_noise and add_rand_noise_if_necessary:
      return __umap_find_sigma_i__(
        distances=distances,
        rho_i=rho_i,
        k=k,
        bandwidth=bandwidth,
        atol=atol,
        rtol=rtol,
        max_iter=max_iter,
        sigma_min=sigma_min,
        sigma_max=sigma_max,
        dtype=dtype,
        device=device,
        add_rand_noise=True,
        add_rand_noise_if_necessary=False,
        max_rand_noise_amount=max_rand_noise_amount,
        rand_generator=rand_generator
      )
  return mid, (weights, iter)


def umap_style_graph(A, topk, apply_optimal_k_heuristic=None, quick_estimate_sigma_as_radius=False, symmetrize:str='none', add_rand_noise=False, rand_generator=None):
  '''
  https://arxiv.org/abs/1802.03426 ("UMAP: Uniform Manifold Approximation and Projection for Dimension Reduction")
  https://umap-learn.readthedocs.io/en/latest/how_umap_works.html
  https://www.jakobhansen.org/2018/05/04/UMAP/
  https://arxiv.org/pdf/2108.05525 ("Clustering with UMAP: Why and How Connectivity Matters", other connectitiy strategies)
  
  ATTENTION: edge weights are interpreted as (unbounded) distance values!!
  
  umap style topology preserving knn graph

  .. math::
    \sum_{j=1}^{k} \mathrm{exp} \left( - \frac{ \mathrm{max}(0, d(x_i,x_j)-\rho_i) }{ \sigma_i } \right) &= \mathrm{log_2}(k) \\
    %
    %
    \sum_{j=1}^{k} \mathrm{exp} \left( - \frac{ w'_{i,j} }{ \sigma_i } \right) &= \mathrm{log_2}(k) \\
    %
    %
    \sum_{j=1}^{k} w_{i,j} &= \mathrm{log_2}(k) \\

  # https://github.com/lmcinnes/umap/issues/164: w_i(x_i, x_j) = exp(-(d(x_i, x_j) - r_i) / sigma_i),
  # r_i is the distance to the closest neighbor and sigma_i is the diameter of the neighborhood
  # min of that formula and 1 
  # there is some finessing in how to compute suitable sigma_i values in the actual code, but neighborhood radius is good enough
    
  Parameters
  ----------
  A : adjacency matrix A[i,j] -> edge weight from (i to j) (note, weight is a distance)
  topk : top k neighbors, can be a percentage value where 1 means no pruning (all nodes are potential neighbors) and 0 means full pruning (no nodes are neighbors)
  apply_optimal_k_heuristic = None, 'weights', 'values'
  symmetrize: 'union' P(A ∪ B) = P(A) + P(B) - P(A ∩ B),
              'intersection' P(A ∩ B)
              'min', 'max',
              'none' / None / default -> no symmetrization strategy
  Returns
  -------
  B : UMAP style graph with topolgy preserving local connectivity edges

  '''
  N = A.size(0)
  assert N == A.size(1)
  max_edges = N-1
  if topk < 1: # topk is a percentage
    topk = int(max_edges * topk)
  if topk > max_edges:
    topk = max_edges
  # copy graph... A_ will be the new graph
  A_ = A.to(dtype=torch.float)
  # catch edge cases
  if max_edges == 0: # graph consists of only one node
    A_[0,0] = 0
    return A_
  if max_edges == 1: # graph consists of only two nodes.
    A_[0,0] = A_[1,1] = 0
    A_[0,1] = 1 if A_[0,1] > 0 else 0
    A_[1,0] = 1 if A_[1,0] > 0 else 0
    return A_
  # remove diagonals, i.e. self-loops TODO: is that the responsibility of the client?
  max_ = get_dtype_max(A_.dtype)
  A_[(range(N), range(N))] = max_
  t = A_.topk(dim=1, k=topk, largest=False, sorted=True)
  # compute new weights
  rho_i = t.values[:,0]
  if quick_estimate_sigma_as_radius:
    sigma_i = t.values[:,-1]
    d_ij =  t.values - rho_i.unsqueeze(1).expand_as(t.values)
    d_ij = torch.where(d_ij >= 0, d_ij, 0.)
    if add_rand_noise:
      d_ij[:,1:] += torch.rand((N, topk-1), generator=rand_generator)*1e-4 # add some random noise to avoid ties
    sigma_i_expanded = sigma_i.unsqueeze(1).expand_as(d_ij)
    w_ij = torch.exp(-d_ij / sigma_i_expanded) 
  else:
    # properly estimate sigma_i by solving w_i(x_i, x_j) = exp(-(d(x_i, x_j) - r_i) / sigma_i) 
    # where sigma_i is set, such that sum(exp(-(d(x_i, x_j) - r_i) / sigma_i)) = log2(k) is satisfied
    sigma_i, (w_ij, num_iters) = __umap_find_sigma_i__(
      distances=t.values,
      rho_i=rho_i,
      k=topk,
      device=A_.device
    )
  # update A_
  if apply_optimal_k_heuristic is not None:
    # find a natural break in the top k values (another option might be to find a natural break in the resulting weights w_ij, but that's up to the client)
    break_indices = __natural_break_by_diff__(w_ij if apply_optimal_k_heuristic == 'weights' else t.values)
    # compute the reset indices (row_indices, col_indices), example ([0,0,0,1,3,3],[3,4,5,5,4,5]) where the max index is 5
    reset_indices = tuple(zip(*(tupl for i, break_index in enumerate(break_indices) for tupl in zip([i]*(topk-break_index), range(break_index, topk)))))
    w_ij[reset_indices] = 0
  A_.fill_(.0) # reset A_
  # t.indices: shape (N, topk), t.values: shape (N, topk)
  rows = torch.arange(N).unsqueeze(1).expand(-1, topk)  # shape (N, topk)
  A_[rows, t.indices] = w_ij
  # reset diagonal, just in case i=j was in the topk
  A_[(range(N), range(N))] = 0
  # symmetrize: 
  A_ = {
    'union': \
      # P(A ∪ B) = P(A) + P(B) - P(A ∩ B), where A and B are assumed to be independent such that P(A ∩ B) = P(A) * P(B). Note, this assumption is a simplification and is certainly not true.
      A_+A_.T - A_*A_.T,
    'intersection': \
      # P(A ∩ B) assuming that A and B are independent events
      A_*A_.T,
    'min': \
      torch.where(A_ < A_.T, A_, A_.T),
    'max': \
      torch.where(A_ > A_.T, A_, A_.T),
    'none': \
      # default
      A_
  }.get(symmetrize, A_)
  
  return A_


def filter_clusters_by_size(clusters, minsize = 2):
  return {k: v for k,v in clusters.items() if len(v) >= minsize}


def get_cluster_sizes(clusters):
  return {k: len(v) for k,v in clusters.items()}


def get_cluster_size_distribution(clusters):
  s = torch.tensor(list(get_cluster_sizes(clusters).values()))
  c = s.unique(return_counts=True)
  d = {c[0][i].item(): c[1][i].item() for i in range(c[0].size(0))}
  return d


def named_clusters(clusters, names, names_for_keys = False):
  if names_for_keys:
    return { names[k]: named_labels(v, names) for k, v in clusters.items()}
  return { k: named_labels(v, names) for k, v in clusters.items()}


def named_labels(labels, names):
  return [ names[i] for i in labels]


def labelvector_as_clusterlist(labels):
  return { i.item(): [j[0].item() for j in (labels == i).nonzero(as_tuple = False)] for i in labels.unique() }


def set_newval_where(M, condition=lambda v: v < .5, newval=0, step=None, sort_on_device=torch.device('cpu'), appendnewval = True):
  '''
  set newval where condition for value is true

  Parameters
  ----------
  M : TYPE
    DESCRIPTION.
  condition : TYPE, optional
    DESCRIPTION. The default is lambda v: v < .5.
  newval : TYPE, optional
    DESCRIPTION. The default is 0.
  step : TYPE, optional
    DESCRIPTION. The default is None. Increase the step size to increase performance but get approximate results. Set to None get a good estimate on stepsize.
  sort_on_device : TYPE, optional
    DESCRIPTION. The default is torch.device('cpu').
  appendnewval : TYPE, optional
    DESCRIPTION. The default is True. Set to True if you expect most values to fail the condition and to False if most values hit the condition. 

  Returns
  -------
  M : TYPE
    DESCRIPTION.

  '''
  if not step:
    step = max(int(M.numel() * 1e-5), 1)
  half_step = max(step//2, 1)
  m = M.view(-1)
  s = m.to(sort_on_device).sort(descending=False) # sort ascending
  
  if condition(s.values[0]):
    values = s.values
    indices = s.indices
  else:
    values = s.values.flip(0)
    indices = s.indices.flip(0)
    
  if appendnewval:    
    for i in range(0, indices.size(0), step):
      if not condition(values[min(i+half_step, values.size(0)-1)]):
        break
      m[indices[i:i+step]] = newval
  else:
    reversed_values = values.flip(0)
    reversed_indices = indices.flip(0)
    m[:] = newval
    for i in range(0, reversed_indices.size(0), step):
      if condition(reversed_values[min(i+half_step, reversed_values.size(0)-1)]):
        break
      m[reversed_indices[i:i+step]] = reversed_values[i:i+step].to(m.device)
  return M


def select_where_gt(M, val=0, step=None, sort_on_device=torch.device('cpu')):
  '''
  select indices and values where value is greater than val
  '''
  if not step:
    step = max(int(M.numel() * 1e-5), 1)
  half_step = step//2
  m = M.view(-1)
  s = m.to(sort_on_device).sort(descending=True) # sort descending

  condition_ = lambda v: v > val
        
  for i in range(0, s.indices.size(0), step):
    if not condition_(s.values[min(i+half_step, s.values.size(0)-1)]):
      return \
        vecindex2matindex(s.indices[:min(i+half_step, s.values.size(0))], M.size(0)), \
        s.values[:min(i+half_step, s.values.size(0)-1)], \
        i
  return vecindex2matindex(s.indices, M.size(0)), s.values, None


def select_where_gt_rev(M, val=0, step=None, sort_on_device=torch.device('cpu')):
  '''
  select indices and values where value is greater than val
  '''
  if not step:
    step = max(int(M.numel() * 1e-5), 1)
  half_step = step//2
  m = M.view(-1)
  s = m.to(sort_on_device).sort(descending=False) # sort ascending

  condition_ = lambda v: v <= val
        
  for i in range(0, s.indices.size(0), step):
    if not condition_(s.values[min(i+half_step, s.values.size(0)-1)]):
      return \
        vecindex2matindex(s.indices[min(i+half_step, s.values.size(0)):], M.size(0)), \
        s.values[min(i+half_step, s.values.size(0)-1):], \
        i
  return vecindex2matindex(s.indices[:0], M.size(0)), s.values[:0], None


def set_val_for_edges_with_same_property(M, properties, val=0):
  # for each unique word
  properties_unique = set(properties)
  for propu in properties_unique:
    idxs = torch.tensor([ i for i, prop in enumerate(properties) if prop == propu ], dtype=torch.long)
    M[idxs.repeat_interleave(idxs.size(0)), idxs.repeat(idxs.size(0))] = val
  return M


def pretty_print_matrix(M, rownames=None, colnames=None, width=12, value_format='.3f', colsep = ' ', rowsep = '\n', row_name_format='s', col_name_format='s', out=sys.stdout):
  if rownames is None:
    rownames = [str(i) for i in range(M.shape[0])]
  if colnames is None:
    colnames = [str(i) for i in range(M.shape[1])]

  # trim colnames and rownames
  rownames = [name if len(name) <= width else name[:width-4] + '..' + name[-2:] for name in [f'{name:{row_name_format}}' for name in rownames]]
  colnames = [name if len(name) <= width else name[:width-4] + '..' + name[-2:] for name in [f'{name:{col_name_format}}' for name in colnames]]

  # header
  print(' '*width + colsep + colsep.join([f'{name:^{width}.{width}s}' for name in colnames]), end = rowsep, file=out)
  for ri in range(M.shape[0]):
    print(f'{rownames[ri]:<{width}.{width}s}' + colsep +  colsep.join([f'{sval:^{width}.{width}s}' for sval in [f'{val:{value_format}}' for val in M[ri,:]]]), end=rowsep, file=out)


def pretty_print_matrix_concise(M, rownames=None, colnames=None, width=4, value_format='.2f', colsep = ' ', rowsep = '\n', out=sys.stdout):
  if rownames is None:
    rownames = [str(i) for i in range(M.shape[0])]
  if colnames is None:
    colnames = [str(i) for i in range(M.shape[1])]

  colmarker = '|'
  # header
  for i, colname in enumerate(colnames):
    print(f'{"":>{width-1}.{width-1}s}', end='', file=out)
    print(colname, end=rowsep, file=out)
    # if (i+1) < len(colnames):
    print( (f'{colmarker:>{width}.{width}s}' + colsep) * (i+1), end='', file=out)
  print(end=rowsep, file=out)

  # rows  
  for i, rowname in enumerate(rownames):
    print(colsep.join([f'{sval:>{width}.{width}s}' for sval in [f'{val:{value_format}}' for val in M[i,:]]]), end=colsep, file=out)
    print(' -- ', end='', file=out)
    print(rowname, end=rowsep, file=out)


def skl_dbscan(X, *args, out=['labelvector'], **kwargs):
  d = DBSCAN(*args, **kwargs)
  return __skl_fit_predict__(d, X, out) 


def skl_optics(X, *args, out=['labelvector'], **kwargs):
  o = OPTICS(*args, **kwargs)
  return __skl_fit_predict__(o, X, out)


def skl_spectral(X, *args, out=['labelvector'], **kwargs):
  s = SpectralClustering(*args, affinity='precomputed', **kwargs)
  return __skl_fit_predict__(s, X, out)


def skl_affinity_propagation(X, *args, out=['labelvector'], random_state=None, **kwargs):
  a = AffinityPropagation(damping=.5, max_iter=2000, convergence_iter=10, random_state=random_state, affinity='precomputed')
  return __skl_fit_predict__(a, X, out)


def skl_affinity_propagation_euc(X, *args, out=['labelvector'], random_state=None, **kwargs):
  # compute euclidean distances for points in X (same as passing X and affinity='euclidean' to AffinityPropagation)
  X = -torch.cdist(X,X)**2
  a = AffinityPropagation(damping=.5, random_state=random_state, affinity='precomputed')
  return __skl_fit_predict__(a, X, out)


def __skl_fit_predict__(model, X, out):
  label_vec = model.fit_predict(X)
  label_vec = torch.tensor(label_vec)
  labels = labelvector_as_clusterlist(label_vec)
  res = { 'labels' : labels }
  if 'labelvector' in out:
    res['labelvector'] = label_vec
  return res


def purity_score(y_true, y_pred):
  # compute contingency matrix (also called confusion matrix)
  contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred,sparse=False)
  # return purity
  purity = np.sum(np.amax(contingency_matrix, axis=1)) / np.sum(contingency_matrix)
  inverse_purity = np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix)
  f1 =  2 * ( (purity*inverse_purity) / (purity+inverse_purity) )
  return purity, inverse_purity, f1


def bcubed_scores(y_true, y_pred):
  # create dictionary of items for bcubed-python package
  ldict = { f'item_{i}': set([v]) for i,v in enumerate(y_true) }
  cdict = { f'item_{i}': set([v]) for i,v in enumerate(y_pred) }
  precision = bcubed.precision(cdict, ldict)
  recall = bcubed.recall(cdict, ldict)
  fscore = bcubed.fscore(precision, recall)
  return precision, recall, fscore


def parwise_metric_scores(y_true, y_pred, f_beta = 1.):
    # number of samples
    (n_samples,) = y_true.shape
    # comute the number of all possible pairs
    n_pairs = n_samples*(n_samples-1)/2 
    # compute contingency matrix
    c = metrics.cluster.contingency_matrix(y_true, y_pred, sparse=True).astype(np.int64, copy=False)
    # compute the number of pairs in predicted clustering (total predicted positives)
    TP_plus_FP = sum([math.comb(x,2) for x in np.asarray(c.sum(axis=0)).ravel()])
    # compute the number of pairs in true clustering (total class positives)
    TP_plus_FN = sum([math.comb(x,2) for x in np.asarray(c.sum(axis=1)).ravel()])
    # true positives
    TP = sum([math.comb(x,2) for x in c.data])
    # false positives, false negatives and true negatives
    FP = TP_plus_FP - TP
    FN = TP_plus_FN - TP
    TN = n_pairs - TP - FP - FN
    # precision, recall, accuracy
    prec = (TP / TP_plus_FP) if TP_plus_FP != 0 else 1
    rec = (TP / TP_plus_FN) if TP_plus_FN != 0 else 1
    acc = ((TP + TN) / n_pairs) if n_pairs != 0 else 1
    # f1 / f_beta
    f_beta_squared = math.pow(f_beta, 2)
    f_beta_score = (1 + f_beta_squared) * ((prec * rec) / ((f_beta_squared * prec) + rec)) if prec > 0 or rec > 0 else .0
    # Fowlkes–Mallows index
    fmi = math.sqrt(prec * rec)
    # +++ 
    return prec, rec, acc, f_beta_score, fmi


# more internal evaluation scores? https://en.wikipedia.org/wiki/Cluster_analysis#Internal_evaluation
def evaluate_cluster_labels_internal(distances, labels_pred):
  # mean_silhouette_score = metrics.silhouette_score(X, labels_pred, metric='precomputed', sample_size=None, random_state=None) # sample distance matrix or feature matrix is required, but we don't have that here
  pass


def evaluate_cluster_labels(labels_true, labels_pred, omit_contingency=False, use_concise_pretty_print_matrix=True):
  '''
  Expects label vectors to be a list or a numpy array
  '''
  scores = { }

  classes, class_idx = np.unique(labels_true, return_inverse=True)
  clusters, cluster_idx = np.unique(labels_pred, return_inverse=True)

  scores['nsamples_true'] = len(labels_true)
  scores['nsamples_pred'] = len(labels_pred)
  scores['nclasses'] = len(classes)
  scores['nclusters'] = len(clusters)
  scores['rdiff'] = 1 - (abs(len(classes) - len(clusters)) / max(len(classes), len(clusters))) # make difference value relative and 1 to be best 0 to be worst

  if scores['nsamples_true'] != scores['nsamples_pred'] or scores['nsamples_true'] == 0 or scores['nsamples_pred'] == 0:
    return scores

  ri = metrics.rand_score(labels_true, labels_pred)
  ari = metrics.adjusted_rand_score(labels_true, labels_pred)
  mi = metrics.mutual_info_score(labels_true, labels_pred)  
  nmi = metrics.normalized_mutual_info_score(labels_true, labels_pred)  
  ami = metrics.adjusted_mutual_info_score(labels_true, labels_pred)
  h, c, v = metrics.homogeneity_completeness_v_measure(labels_true, labels_pred)
  fmi = metrics.fowlkes_mallows_score(labels_true, labels_pred)
  pu, ipu, puf1 = purity_score(labels_true, labels_pred)
  b3p, b3r, b3f1 = bcubed_scores(labels_true, labels_pred)
  pair_prec, pair_rec, pair_acc, pair_f1, pair_fmi = parwise_metric_scores(y_true=labels_true, y_pred=labels_pred)
  
  if omit_contingency:
    cmatp = 'omitted'
  else:
    cmat = metrics.cluster.contingency_matrix(labels_true, labels_pred)
    with io.StringIO() as fout:
      if use_concise_pretty_print_matrix:
        pretty_print_matrix_concise(cmat, rownames=classes, colnames=clusters, value_format='d', out=fout)
      else:
        pretty_print_matrix(cmat, rownames=classes, colnames=clusters, value_format='d', out=fout)
      cmatp = '\n' + fout.getvalue()

  scores.update({
    'ri': ri,
    'ari': ari,
    'mi': mi,
    'nmi': nmi,
    'ami': ami,
    'h': h,
    'c': c,
    'v': v,
    'fmi': fmi,
    'pu': pu,
    'ipu': ipu, 
    'puf1': puf1,
    'b^3p': b3p,
    'b^3r': b3r,
    'b^3f1': b3f1,
    'p(pair)': pair_prec, 
    'r(pair)': pair_rec,
    'a(pair)': pair_acc,
    'f1(pair)': pair_f1,
    'fmi(pair)': pair_fmi,
    'contingency': cmatp,
  })
  return scores
  
