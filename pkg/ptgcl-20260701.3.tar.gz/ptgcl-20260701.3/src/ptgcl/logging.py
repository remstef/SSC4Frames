#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import logging

__handler__: list[logging.Handler] = []
__logger__: list[logging.Logger] = []

__default_formatter__:logging.Formatter = logging.Formatter(
    "%(processName)s:%(threadName)s:%(asctime)s:%(name)s:%(levelname)s: %(message)s"
)


def add_handler(handler: logging.Handler) -> logging.Handler:
    __handler__.append(handler)
    return handler


def add_console_handler() -> logging.Handler:
    consolehandler: logging.Handler = logging.StreamHandler()
    consolehandler.setFormatter(__default_formatter__)
    return add_handler(consolehandler)


def setup_logger(name: str) -> logging.Logger:
    logger: logging.Logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    for handler in __handler__:
        logger.addHandler(handler)
    __logger__.append(logger)
    return logger


def set_log_verbosity(
    logger: logging.Logger, verbose: bool = False, quiet: bool = False
) -> None:
    """ """
    if verbose:
        logger.setLevel(logging.DEBUG)
    else:
        if quiet:
            logger.setLevel(logging.ERROR)
        else:
            logger.setLevel(logging.INFO)


add_console_handler()
