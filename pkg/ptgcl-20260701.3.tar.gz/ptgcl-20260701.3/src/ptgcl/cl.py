#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  6 13:30:00 2020

@author: rem
"""

import warnings
import os, sys
import gzip
import numpy as np
import io
import math
import re
from collections.abc import Callable, Sequence
from typing import Any, TextIO, cast

import bcubed
import torch
from scipy.optimize import root_scalar
from sklearn import metrics
from sklearn.cluster import DBSCAN, OPTICS, SpectralClustering, AffinityPropagation

from ptgcl.logging import setup_logger

logger = setup_logger(os.path.basename(__file__))


def read_graph_from_file(
    filename: str,
    regex: str = r"^\s*(?P<src>\S+)\s+(?P<dst>\S+)(\s+(?P<w>\b\d+([\.,]\d+)?\b))?\s*$",
    dtype: torch.dtype = torch.float,
) -> tuple[torch.Tensor, dict[str, int], dict[int, str]]:
    pattern: re.Pattern[str] = re.compile(regex)
    openfun: Callable[..., Any] = open
    if not os.path.exists(filename) and os.path.isfile(filename):
        raise FileNotFoundError(f"file '{filename}' not found.")
    if filename.endswith(".gz"):
        openfun = gzip.open
    nodes: dict[str, int] = {}
    edges: list[tuple[int, int, float]] = []
    with openfun(filename, "rt") as fh:
        for i, line in enumerate(fh, start=1):
            line_: str = line
            try:
                line_ = line.strip()
                if not len(line_):
                    continue
            except Exception as e:
                logger.error(f"Error in line {i}: '{line_}': {e}")
                raise ValueError(f"Error in line {i}: '{line_}'") from e
            try:
                m: re.Match[str] | None = pattern.search(line_)
                if not m:
                    raise ValueError(f"Pattern '{regex}' not found.")
                src: str = m.group("src")
                dst: str = m.group("dst")
                w: str | None = m.group("w")
                if not dst:
                    raise ValueError("No destination found.")
                if not src:
                    raise ValueError("No source found.")
            except Exception as e:
                logger.error(f"Error in line {i}: '{line_}': {e}")
                raise ValueError(f"Error in line {i}: '{line_}'") from e
            nodes[src] = nodes.get(src, len(nodes))
            nodes[dst] = nodes.get(dst, len(nodes))
            edges.append((nodes[src], nodes[dst], float(w) if w else float(1.0)))
    logger.debug(f"nodes: {len(nodes)}; edges: {len(edges)}; from file: '{filename}'")
    A: torch.Tensor = torch.zeros((len(nodes), len(nodes)), dtype=dtype)
    logger.debug(f"G: {A.size()}")
    edgesrcs, edgedsts, edgews = list(zip(*edges))
    A[(edgesrcs, edgedsts)] = torch.tensor(edgews, dtype=dtype)
    ids: dict[int, str] = {v: k for k, v in nodes.items()}
    return A, nodes, ids


def rescale_edge_weights(
    A: torch.Tensor, new_min: float = 1.0, new_max: float = 10.0
) -> torch.Tensor:
    """
    Rescale all nonzero edge weights in A to the interval [new_min, new_max].
    """
    mask: torch.Tensor = A > 0
    if not mask.any():
        return A
    old_min: torch.Tensor = A[mask].min()
    old_max: torch.Tensor = A[mask].max()
    # Avoid division by zero if all values are the same
    if old_max == old_min:
        A[mask] = new_min
    else:
        old_diff: torch.Tensor = old_max - old_min
        new_diff: float = new_max - new_min
        A[mask] = (((A[mask] - old_min) / old_diff) * new_diff) + new_min
    return A


def get_net_as_dict(
    A: torch.Tensor, node_id_to_name: dict[int, str] | None = None
) -> dict[str, Any]:
    if node_id_to_name is None:
        node_id_to_name = {}
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    # check if upper triangular is similar to lower triangular matrix
    graph_is_undirected: bool = torch.allclose(torch.tril(A), torch.triu(A).T)
    max_edge_weight: float = torch.max(A).item()
    min_edge_weight: float = torch.min(A[torch.nonzero(A, as_tuple=True)]).item()
    valrange_edge_weight: float = max_edge_weight - min_edge_weight
    valrange_newedge_weight: float = 3.0 - 1.0
    metainfo: dict[str, Any] = {
        "type": "undirected" if graph_is_undirected else "directed",
        "min_edge_weight": min_edge_weight,
        "max_edge_weight": max_edge_weight,
        "min_edge_weight_scaled": 1,
        "max_edge_weight_scaled": 3 if valrange_edge_weight > 0 else 1,
    }
    for vi in range(A.size(0)):
        vi_name: str = node_id_to_name.get(vi, f"v{vi}")
        nodes.append(
            {
                "id": vi,
                "name": vi_name,
                "label": f"{vi_name}|v{vi}|c{-1}",
                "group": -1,
                "title": f"{vi_name}|v{vi}|c{-1}",
                "size": 10,
            }
        )
        for vj in range(vi, A.size(1)) if graph_is_undirected else range(A.size(1)):
            if A[vi, vj] > 0:
                key: str = f"{vi}->{vj}"
                keyid: int = len(edges)
                edges.append(
                    {
                        "id": keyid,
                        "key": key,
                        "srcid": vi,
                        "dstid": vj,
                        "weight": A[vi, vj].item(),
                        "weight_scaled": (
                            1.0
                            if valrange_edge_weight == 0
                            else (
                                (
                                    (A[vi, vj].item() - min_edge_weight)
                                    / valrange_edge_weight
                                )
                                * valrange_newedge_weight
                            )
                            + 1.0
                        ),
                    }
                )
    return {"nodes": nodes, "edges": edges, "meta": metainfo}


def G_twentynodes(random_seed: int = 0) -> torch.Tensor:
    generator: torch.Generator = torch.Generator()
    generator.manual_seed(random_seed)
    twentynodes: torch.Tensor = torch.rand((20, 20), generator=generator) * 0.5
    twentynodes[:10, :10] += 0.5
    twentynodes[10:, 10:] += 0.5
    return twentynodes


def G_twentynodes_true_labels() -> torch.Tensor:
    labels: torch.Tensor = torch.zeros(20, dtype=torch.uint8)
    labels[:10] = 1
    labels[10:] = 2
    return labels


def G_twentynodes_bin(random_seed: int = 0) -> torch.Tensor:
    twentynodes: torch.Tensor = torch.ones((20, 20), dtype=torch.uint8)
    twentynodes[:10, 10:] = 0
    twentynodes[10:, :10] = 0
    return twentynodes


def G_twentynodes_equidist(n: int = 20) -> torch.Tensor:
    """
    Produce equidistant graph of twenty (n) nodes having the first n/2
    nodes direct connections to the first nodes and the last n/2
    nodes direct connections to the last nodes

    Example:
    [
     [0,1,2,3,...]
     [1,0,2,3,...]
     [1,2,0,3,...]
     ...
     [...,3,0,2,1]
     [...,3,2,0,1]
     [...,3,2,1,0]
    ]
    """
    G: torch.Tensor = torch.zeros((n, n), dtype=torch.uint8)
    G[0, :] = torch.arange(n, dtype=torch.uint8)
    for i in range(1, n):
        if i < n // 2:
            G[i, :] = torch.cat(
                (
                    torch.arange(1, i + 1, dtype=torch.uint8),
                    torch.zeros((1,), dtype=torch.uint8),
                    torch.arange(i + 1, n, dtype=torch.uint8),
                )
            )
        else:
            G[i, :] = torch.flip(G[n - i - 1, :], dims=(0,))
    return G


def G_twentynodes_equidist2(n: int = 20) -> torch.Tensor:
    """
    Produce equidistant graph of twenty (n) nodes such that the k nearest neighbors
    of a node i are left (i-k) and right (i+k) to the node i, and distances to the
    first n/2 nodes to the last n/2 nodes are maximized

    Example:
    [
     [0,1,2,3,...,n,n,n,n]
     [1,0,1,2,...,n,n,n,n]
     [2,1,0,1,...,n,n,n,n]
     ...
     [n,n,n,n,...,1,0,1,2]
     [n,n,n,n,...,2,1,0,1]
     [n,n,n,n,...,3,2,1,0]
    ]
    """
    G: torch.Tensor = torch.zeros((n, n), dtype=torch.uint8)
    # G[:,0] = torch.range(0,n-1)
    for i in range(n):
        if i < n // 2:
            G[i, :] = torch.cat(
                (
                    torch.flip(torch.arange(1, i + 1, dtype=torch.uint8), dims=(0,)),
                    torch.arange(0, n // 2 - i, dtype=torch.uint8),
                    torch.ones(n // 2, dtype=torch.uint8) * n,
                )
            )
        else:
            G[i, :] = torch.flip(G[n - i - 1, :], dims=(0,))
    return G


def G_maxmax() -> torch.Tensor:
    """
    Sample graph from the MaxMax paper
    """
    r: int
    s: int
    t: int
    u: int
    v: int
    w: int
    x: int
    r, s, t, u, v, w, x = (0, 1, 2, 3, 4, 5, 6)
    G: torch.Tensor = torch.zeros((7, 7), dtype=torch.long)
    G[r, s] = 3
    G[r, t] = 2
    G[r, u] = 1
    G[r, v] = 1
    G[r, w] = 2
    G[r, x] = 2
    G[s, t] = 1
    G[s, u] = 2
    G[s, v] = 2
    G[s, w] = 2
    G[t, v] = 1
    G[t, w] = 2
    G[t, x] = 1
    G[u, v] = 1
    G[v, w] = 1
    G[w, x] = 4
    G.add_(G.T.clone())
    return G


def vecindex2matindex(
    vecindex: torch.Tensor, rowlength: int
) -> tuple[torch.Tensor, torch.Tensor]:
    ri: torch.Tensor = vecindex // rowlength
    ci: torch.Tensor = vecindex % rowlength
    return ri, ci


def matindex2vecindex(
    matindex: tuple[torch.Tensor, torch.Tensor], rowlength: int
) -> torch.Tensor:
    ri, ci = matindex
    vi: torch.Tensor = (ri * rowlength) + ci
    return vi


def connectivity(A: torch.Tensor, N: int | None = None) -> float:
    n: int = int(A.size(0)) if N is None else N
    maxconnections: int = n * n
    connections: int = A.nonzero(as_tuple=False).size(0)
    return connections / maxconnections


def interconnectivity(A: torch.Tensor) -> float:
    N: int = A.size(0)
    if N < 2:
        return 1
    maxconnections: int = (N * N) - N  # fully connected w/o self connections
    d: torch.Tensor = A[range(N), range(N)]  # remember diagonal values
    A[range(N), range(N)] = 0  # make sure diagonals are zero
    connections: int = A.nonzero(as_tuple=False).size(0)  # count the number of connections
    interconnectivity: float = connections / maxconnections  # get the ratio
    A[range(N), range(N)] = d  # reset diagonal entries
    return interconnectivity


def interconnectivity_val(A: torch.Tensor, normalize: bool = False) -> float:
    N: int = A.size(0)
    if N < 2:
        return 1
    maxval: int = (
        N * N
    ) - N  # fully connected w/o self connections and every connection value is 1
    d: torch.Tensor = A[range(N), range(N)]  # remember diagonal values
    A[range(N), range(N)] = 0  # make sure diagonals are zero
    connections_val: torch.Tensor = A.sum()  # sum the connection values of all connections
    interconnectivity_val: torch.Tensor = connections_val / maxval  # get the ratio
    if normalize:
        connections: int = A.nonzero(as_tuple=False).size(0)
        interconnectivity: float = connections / maxval  # maxconnections == max_val
        interconnectivity_val /= interconnectivity
    A[range(N), range(N)] = d  # reset diagonal entries
    return interconnectivity_val.item()


def mean_local_clustering_coefficient(
    A: torch.Tensor, sample: int | None = None, random_seed: int = 0
) -> float:
    random_sample: range | torch.Tensor
    if sample:
        generator: torch.Generator = torch.Generator()
        generator.manual_seed(random_seed)
        random_sample = torch.randperm(A.size(0), generator=generator)[
            : min(sample, A.size(0))
        ]  # random.sample(range(A.size(0)), min(sample, A.size(0)))
    else:
        random_sample = range(A.size(0))
    coef: torch.Tensor = torch.tensor(
        [local_clustering_coefficient(A, int(i)) for i in random_sample],
        dtype=torch.float,
    ).mean()
    return coef.item()


def local_clustering_coefficient(A: torch.Tensor, i: int = 0) -> float:
    Ni_: torch.Tensor = A[i, :].nonzero(as_tuple=False)[:, 0]  # neighbors
    Ni: torch.Tensor = Ni_[Ni_ != i]  # neighbors w/o self
    ki: int = Ni.size(0)  # number of neighbors
    if ki <= 1:
        return 0
    # Mi = A[Ni,:][:,Ni] # sub-matrix of neighbor connections
    Mi: torch.Tensor = A[Ni.repeat_interleave(Ni.size(0)), Ni.repeat(Ni.size(0))]
    coef: float = Mi.nonzero(as_tuple=False).size(0) / (
        ki * (ki - 1)
    )  # number of neighbor connections divided by the theoretical number of maximum conncections
    return coef


def mean_local_neighbors(A: torch.Tensor, normalize: bool = False) -> float:
    coef: torch.Tensor = torch.tensor(
        [local_neighbors(A, i, normalize) for i in range(A.size(0))], dtype=torch.float
    ).mean()
    return coef.item()


def local_neighbors(A: torch.Tensor, i: int, normalize: bool = False) -> float | int:
    Ni_: torch.Tensor = A[i, :].nonzero(as_tuple=False)[:, 0]  # neighbors
    Ni: torch.Tensor = Ni_[Ni_ != i]  # neighbors w/o self
    ki: int = Ni.size(0)  # number of neighbors
    if normalize:
        return ki / (A.size(0) - 1)  # normalize by max number of neighbors
    return ki


def shortest_path_distances(
    A: torch.Tensor,
    num_hops: bool = True,
    dists: bool = True,
) -> tuple[torch.Tensor, torch.Tensor]:
    N: int = A.size(0)
    assert A.size(1) == N
    # initialize distances D and number of hops H
    D: torch.Tensor
    H: torch.Tensor
    D, H = torch.tensor([[dists]], dtype=torch.bool), torch.tensor(
        [[num_hops]], dtype=torch.bool
    )
    if dists:
        D = torch.full((N, N), float("inf"), dtype=torch.float, device=A.device)
        D = torch.where(A > 0, A, D)
    if num_hops:
        H = torch.full((N, N), float("inf"), dtype=torch.float16, device=A.device)
        H = torch.where(A > 0, 1, H)

    # floyd-warshal algorithm to compute all distances
    for k in range(N):
        if dists:
            D = torch.minimum(D, D[:, k].unsqueeze(1) + D[k, :].unsqueeze(0))
        if num_hops:
            H = torch.minimum(H, H[:, k].unsqueeze(1) + H[k, :].unsqueeze(0))

    return D, H


def diameter(A: torch.Tensor) -> None:
    # https://www.youtube.com/watch?v=SumKq0Jx1L0
    # epsilon(u) = eccentricity of a vertex u = longest shortest path between vertex u and any other vertex v == maximum distance between u and any other vertex of G
    # radius = rad(G) = minimum eccentricity of a graph = minimum eccentricity between any two vertices u and v
    # diameter = diam(G) = maximum eccentricity of a graph = maximum eccentricity between any two vertices u and v
    #
    # https://www.youtube.com/watch?v=CwMCWQtNhtY
    # diam(G) = diameter is the longest shortest path between any two nodes == maximum distance between any two vertices of G
    #
    #   The eccentricity ϵ ( v ) {\displaystyle \epsilon (v)} \epsilon (v) of a vertex v {\displaystyle v} v is the greatest distance between v {\displaystyle v} v and any other vertex; in symbols that is ϵ ( v ) = max u ∈ V d ( v , u ) {\displaystyle \epsilon (v)=\max _{u\in V}d(v,u)} {\displaystyle \epsilon (v)=\max _{u\in V}d(v,u)}. It can be thought of as how far a node is from the node most distant from it in the graph.
    #   The diameter d {\displaystyle d} d of a graph is the maximum eccentricity of any vertex in the graph. That is, d {\displaystyle d} d is the greatest distance between any pair of vertices or, alternatively, d = max v ∈ V ϵ ( v ) {\displaystyle d=\max _{v\in V}\epsilon (v)} d=\max _{v\in V}\epsilon (v). To find the diameter of a graph, first find the shortest path between each pair of vertices. The greatest length of any of these paths is the diameter of the graph.
    pass


def keep_topk_edges_by_criterium(
    A: torch.Tensor,
    removediagonals: bool = True,
    stepsize: float = 100,
    remove_symmetrically: bool = True,
    criterium: Callable[[torch.Tensor], Any] = lambda M: cast(
        Any, M.nonzero(as_tuple=False) <= M.size(0)
    ),
    add_edges: bool = True,
    sort_on_device: torch.device | str = "cpu",
) -> torch.Tensor:
    N: int = A.size(0)
    assert N == A.size(1)
    if removediagonals:
        A[(range(N), range(N))] = 0
    a: torch.Tensor = A.view(-1)
    if stepsize < 0:
        raise Exception("negative number for stepsize not allowed")
    step: int
    if stepsize < 1:  # interpret as percentage
        maxedges: float = (N * N) if removediagonals else (N * (N - 1))
        maxedges = maxedges / 2 if remove_symmetrically else maxedges
        step = max(2 if remove_symmetrically else 1, int(stepsize * maxedges))
    else:
        step = max(1, int(stepsize))
        if remove_symmetrically:
            step = step * 2
    half_step: int = step // 2
    # nz = a.nonzero(as_tuple=False)[:,0]
    if add_edges:
        # s = a[nz].sort(descending=True)
        s: Any = a.to(sort_on_device).sort(descending=True)
        a.fill_(0)
        for i in range(0, s.indices.size(0) - step, step):
            if s.values[i + half_step] <= 0 or not criterium(A):
                break
            # a[nz[s.indices[i:i+step]]] = s.values[i:i+step]
            a[s.indices[i : i + step]] = s.values[i : i + step].to(a.device)
    else:  # remove
        # s = a[nz].sort(descending=False)
        s = a.to(sort_on_device).sort(descending=False)
        for i in range(0, s.indices.size(0) - step, step):
            if s.values[i + half_step] > 0 or not criterium(A):
                break
            # a[nz[s.indices[i:i+step]]] = 0
            a[s.indices[i : i + step]] = 0
    return A  # all changes in a are reflected in A, no need to change the view


def keep_topk_edges(
    A: torch.Tensor,
    topk: int | float,
    removediagonals: bool = True,
    graph_is_symmetric: bool = True,
) -> torch.Tensor:
    N: int = A.size(0)
    assert N == A.size(1)
    max_edges: float = float(N * N - N if removediagonals else N * N)
    if graph_is_symmetric:
        max_edges /= 2
    topk_i: int = int(max_edges * topk) if topk < 1 else int(topk)
    if topk_i > max_edges:
        topk_i = int(max_edges)
    if removediagonals:
        A[(range(N), range(N))] = 0
    a: torch.Tensor = A.view(-1)
    if graph_is_symmetric:
        topk_i = min(topk_i * 2, N * N)
    t: Any = a.topk(topk_i)
    a.fill_(0)
    a[t.indices] = t.values
    return A  # all changes in a are reflected in A, no need to change the view


def keep_topk_neighbors(
    A: torch.Tensor,
    topk: int | float,
    removediagonals: bool = True,
    dim: int = 1,
    force_symmetry_by_addition: bool = True,
) -> torch.Tensor:
    """
    Parameters
    ----------
    A : adjacency matrix A[i,j] -> edge from (i to j)
    topk : top k
    removediagonals : include diagonals (self-loops) in top k?
    dim : prune by dim (0 = incoming edges, 1 = outgoing edges)
    force_symmetry_by_addition : restore symmetry by adding edges to respective other dimension

    Returns
    -------
    B : pruned adjacency matrix

    """
    N: int = A.size(0)
    assert N == A.size(1)
    max_edges: int = N - 1 if removediagonals else N
    topk_i: int = int(max_edges * topk) if topk < 1 else int(topk)
    if topk_i > max_edges:
        topk_i = max_edges
    if removediagonals:
        A[(range(N), range(N))] = 0
    t: Any = A.topk(dim=dim, k=topk_i, largest=True, sorted=True)
    A.fill_(0)
    # update A
    # t.indices: shape (N, topk), t.values: shape (N, topk)
    rows: torch.Tensor = torch.arange(N).unsqueeze(1).expand(-1, topk_i)  # shape (N, topk)
    if dim == 0:
        for k in range(topk_i):
            A[t.indices, rows] = t.values
            if force_symmetry_by_addition:
                A[rows, t.indices] = t.values
    elif dim == 1:
        A[rows, t.indices] = t.values
        if force_symmetry_by_addition:
            A[t.indices, rows] = t.values
    else:
        raise Exception("dim > 1 not defined.")
    return A


def get_dtype_max(dtype: torch.dtype) -> float:
    if dtype.is_floating_point:
        return torch.finfo(dtype).max
    # else
    return torch.iinfo(dtype).max


def __natural_break_by_diff__(values: torch.Tensor) -> torch.Tensor:
    """
    Find a natural break point in a sequence of values (only the first break point).
    The values have to be sorted.
    This method comes with many names.
      * find a rupture
      * find a knee/elbow point
      * find natural breaks
    This method finds a break by finding the arg max in the differences of the previous element.
    The result is an index at location k, The index at location found is the break, the value at the index is included.
    Example:
      In a sequence [1,2,3,5,10,20], the returned index k is 5, the break is between index k and k-1,
      i.e. the value at k is excluded.
    """
    diffs: torch.Tensor = torch.diff(values, dim=1)
    break_indices: torch.Tensor = torch.argmax(diffs, dim=1) + 1
    # fix zero indices
    break_indices = torch.where(break_indices == 0, diffs.size(1), break_indices)
    return break_indices


def __umap_find_sigma_i_single_scipy__(
    distances: np.ndarray,
    rho_i: float,
    k: int,
    max_iter: int = 100,
    sigma_min: float = 1e-5,
    sigma_max: float = 1e5,
    atol: float = 1e-8,
    rtol: float = 1e-5,
) -> tuple[float, Any]:
    """
    Solves for sigma_i given distances d_{i,j} and number of neighbors k.

    Parameters:
        distances (array-like): d_{i,j} for j=1 to k
        k (int): Number of neighbors
        sigma_min, sigma_max (float): Bounds for root finding

    Returns:
        sigma_i (float): The value of sigma_i that satisfies the equation
    """
    d_ij: np.ndarray = distances - rho_i
    log_k: float = np.log2(k)

    def objective(sigma: float) -> float:
        return float(np.sum(np.exp(-d_ij / sigma)) - log_k)

    result: Any = root_scalar(
        objective,
        method="bisect",
        bracket=[sigma_min, sigma_max],
        xtol=atol,
        rtol=rtol,
        maxiter=max_iter,
    )

    if result.converged:
        return result.root, result
    else:
        raise RuntimeError("Failed to converge to a solution for sigma_i.")


def __umap_find_sigma_i_single__(
    distances: torch.Tensor,
    rho_i: float,
    k: int,
    bandwidth: float = 1.0,
    atol: float = 1e-5,
    rtol: float = 1e-3,
    max_iter: int = 100,
    sigma_min: float = 1e-5,
    sigma_max: float = 1e5,
) -> tuple[float, tuple[torch.Tensor, int]]:
    """
    DEPRECATED, only for testing purposes, use batched version '__umap_find_sigma_i__' instead!

    Solves for sigma_i using binary search.

    Parameters:
      distances (torch.Tensor): shape (k,)
      rho_i (float): rho_i
      k (int): number of neighbors
      bandwidth (float):
      tol (float): convergence tolerance
      max_iter (int): maximum number of binary search iterations

    Returns:
      sigma_i (float): the value of sigma_i
    """
    warnings.warn(
        "DEPRECATED, only for testing purposes, use batched version __umap_find_sigma_i__ instead!",
        DeprecationWarning,
    )
    log_k: torch.Tensor = torch.log2(torch.tensor(float(k))) * torch.tensor(bandwidth)
    # Ensure tensor is float32 or float64
    distances = distances.to(dtype=torch.float32)
    # precompute d_ij
    d_ij: torch.Tensor = distances - rho_i
    #
    low: torch.Tensor = torch.tensor(sigma_min)
    high: torch.Tensor = torch.tensor(sigma_max)
    mid: torch.Tensor = torch.tensor(1.0)
    weights: torch.Tensor = d_ij
    zero: torch.Tensor = torch.zeros((1,))
    #
    iter: int = 0
    ln2: torch.Tensor = torch.log(torch.tensor(2))
    for iter in range(max_iter):
        # mid = (low + high) / 2.0
        mid = torch.exp(torch.log(low + high) - ln2)
        weights = torch.exp(-d_ij / mid)
        # weights = torch.exp(torch.exp(torch.log(-d_ij) - torch.log(mid)))
        s: torch.Tensor = torch.sum(weights)
        diff: torch.Tensor = s - log_k
        if torch.allclose(diff, zero, atol=atol, rtol=rtol):  # torch.abs(diff) < tol:
            break
        if diff > 0:
            high = mid
        else:
            low = mid
    # Return approximate solution if tolerance not met
    return mid.item(), (weights, iter)


def __umap_find_sigma_i__(
    distances: torch.Tensor,
    rho_i: torch.Tensor,
    k: int,
    bandwidth: float = 1.0,
    atol: float = 1e-5,
    rtol: float = 1e-3,
    max_iter: int = 100,
    sigma_min: float = 1e-5,
    sigma_max: float = 1e5,
    dtype: torch.dtype = torch.float32,
    device: torch.device | str | None = None,
    add_rand_noise: bool = False,
    add_rand_noise_if_necessary: bool = True,
    max_rand_noise_amount: float = 1e-4,
    rand_generator: torch.Generator | None = None,
) -> tuple[torch.Tensor, tuple[torch.Tensor, int]]:
    """
    Solves for sigma_i for a batch of distance vectors using binary search.

    Parameters:
        distances (torch.Tensor): shape (batch_size, k), distances d_{i,j} for each i
        rho_is (torch.Tensor): shape (batch_size,), rho_i for each i
        tol (float): convergence tolerance
        max_iter (int): max iterations
        sigma_min, sigma_max (float): bounds for binary search

    Returns:
        sigma: torch.Tensor of shape (batch_size,) containing sigma_i for each row
    """

    batch_size, k_ = distances.size()
    log_k: torch.Tensor = torch.log2(
        torch.tensor(float(k), dtype=dtype, device=device)
    ) * torch.tensor(bandwidth, dtype=dtype, device=device)
    d_ij: torch.Tensor = distances - rho_i.unsqueeze(1).expand_as(distances)
    d_ij = torch.where(d_ij >= 0, d_ij, 0.0)
    if add_rand_noise:
        d_ij[:, 1:] += torch.rand(
            (batch_size, k_ - 1), generator=rand_generator
        ) * torch.tensor(
            max_rand_noise_amount, dtype=dtype, device=device
        )  # add some random noise to avoid ties
    weights: torch.Tensor = d_ij
    zeros: torch.Tensor = torch.zeros((batch_size, 1), dtype=dtype, device=device)

    # Initialize bounds
    low: torch.Tensor = torch.full((batch_size,), sigma_min, dtype=dtype, device=device)
    high: torch.Tensor = torch.full((batch_size,), sigma_max, dtype=dtype, device=device)
    mid: torch.Tensor = torch.ones((batch_size,), dtype=dtype, device=device)
    ln2: torch.Tensor = torch.log(torch.tensor(2, dtype=dtype, device=device))

    iter: int = 0
    for iter in range(max_iter):
        # mid = (low + high) / 2.0
        mid = torch.exp(torch.log(low + high) - ln2)
        mid_expanded = mid.unsqueeze(1).expand_as(d_ij)  # (batch_size, k)
        weights = torch.exp(-d_ij / mid_expanded)  # (batch_size, k)
        sum_weights: torch.Tensor = torch.sum(weights, dim=1)  # (batch_size,)
        # Check for convergence
        diff = sum_weights - log_k
        if torch.allclose(diff, zeros, atol=atol, rtol=rtol):
            break
        # Binary update
        high = torch.where(diff > 0, mid, high)
        low = torch.where(diff <= 0, mid, low)
    # END for
    if iter == max_iter - 1:
        msg: str = (
            f"Binary search ran for maximum iterations ({iter+1})."
            f" Sigma_i may not be exact (each sum of weights should: {log_k.item():.3f}, actual: [{', '.join([f"{s:.3f}" for s in sum_weights.tolist()])}])."
            " Re-running search with additive random noise."
            if not add_rand_noise and add_rand_noise_if_necessary
            else ""
        )
        logger.warning(msg)
        warnings.warn(msg, UserWarning)
        if not add_rand_noise and add_rand_noise_if_necessary:
            return __umap_find_sigma_i__(
                distances=distances,
                rho_i=rho_i,
                k=k,
                bandwidth=bandwidth,
                atol=atol,
                rtol=rtol,
                max_iter=max_iter,
                sigma_min=sigma_min,
                sigma_max=sigma_max,
                dtype=dtype,
                device=device,
                add_rand_noise=True,
                add_rand_noise_if_necessary=False,
                max_rand_noise_amount=max_rand_noise_amount,
                rand_generator=rand_generator,
            )
    return mid, (weights, iter)


def umap_style_graph(
    A: torch.Tensor,
    topk: int | float,
    apply_optimal_k_heuristic: str | None = None,
    quick_estimate_sigma_as_radius: bool = False,
    symmetrize: str = "none",
    add_rand_noise: bool = False,
    rand_generator: torch.Generator | None = None,
) -> torch.Tensor:
    r"""
  https://arxiv.org/abs/1802.03426 ("UMAP: Uniform Manifold Approximation and Projection for Dimension Reduction")
  https://umap-learn.readthedocs.io/en/latest/how_umap_works.html
  https://www.jakobhansen.org/2018/05/04/UMAP/
  https://arxiv.org/pdf/2108.05525 ("Clustering with UMAP: Why and How Connectivity Matters", other connectitiy strategies)
  
  ATTENTION: edge weights are interpreted as (unbounded) distance values!!
  
  umap style topology preserving knn graph

  .. math::
    \sum_{j=1}^{k} \mathrm{exp} \left( - \frac{ \mathrm{max}(0, d(x_i,x_j)-\rho_i) }{ \sigma_i } \right) &= \mathrm{log_2}(k) \\
    %
    %
    \sum_{j=1}^{k} \mathrm{exp} \left( - \frac{ w'_{i,j} }{ \sigma_i } \right) &= \mathrm{log_2}(k) \\
    %
    %
    \sum_{j=1}^{k} w_{i,j} &= \mathrm{log_2}(k) \\

  # https://github.com/lmcinnes/umap/issues/164: w_i(x_i, x_j) = exp(-(d(x_i, x_j) - r_i) / sigma_i),
  # r_i is the distance to the closest neighbor and sigma_i is the diameter of the neighborhood
  # min of that formula and 1 
  # there is some finessing in how to compute suitable sigma_i values in the actual code, but neighborhood radius is good enough
    
  Parameters
  ----------
  A : adjacency matrix A[i,j] -> edge weight from (i to j) (note, weight is a distance)
  topk : top k neighbors, can be a percentage value where 1 means no pruning (all nodes are potential neighbors) and 0 means full pruning (no nodes are neighbors)
  apply_optimal_k_heuristic = None, 'weights', 'values'
  symmetrize: 'union' P(A ∪ B) = P(A) + P(B) - P(A ∩ B),
              'intersection' P(A ∩ B)
              'min', 'max',
              'none' / None / default -> no symmetrization strategy
  Returns
  -------
  B : UMAP style graph with topolgy preserving local connectivity edges

  """
    N: int = A.size(0)
    assert N == A.size(1)
    max_edges: int = N - 1
    topk_i: int = int(max_edges * topk) if topk < 1 else int(topk)
    if topk_i > max_edges:
        topk_i = max_edges
    # copy graph... A_ will be the new graph
    A_: torch.Tensor = A.to(dtype=torch.float)
    # catch edge cases
    if max_edges == 0:  # graph consists of only one node
        A_[0, 0] = 0
        return A_
    if max_edges == 1:  # graph consists of only two nodes.
        A_[0, 0] = A_[1, 1] = 0
        A_[0, 1] = 1 if A_[0, 1] > 0 else 0
        A_[1, 0] = 1 if A_[1, 0] > 0 else 0
        return A_
    # remove diagonals, i.e. self-loops TODO: is that the responsibility of the client?
    max_: float = get_dtype_max(A_.dtype)
    A_[(range(N), range(N))] = max_
    t: Any = A_.topk(dim=1, k=topk_i, largest=False, sorted=True)
    # compute new weights
    rho_i: torch.Tensor = t.values[:, 0]
    if quick_estimate_sigma_as_radius:
        sigma_i: torch.Tensor = t.values[:, -1]
        d_ij: torch.Tensor = t.values - rho_i.unsqueeze(1).expand_as(t.values)
        d_ij = torch.where(d_ij >= 0, d_ij, 0.0)
        if add_rand_noise:
            d_ij[:, 1:] += (
                torch.rand((N, topk_i - 1), generator=rand_generator) * 1e-4
            )  # add some random noise to avoid ties
        sigma_i_expanded: torch.Tensor = sigma_i.unsqueeze(1).expand_as(d_ij)
        w_ij: torch.Tensor = torch.exp(-d_ij / sigma_i_expanded)
    else:
        # properly estimate sigma_i by solving w_i(x_i, x_j) = exp(-(d(x_i, x_j) - r_i) / sigma_i)
        # where sigma_i is set, such that sum(exp(-(d(x_i, x_j) - r_i) / sigma_i)) = log2(k) is satisfied
        sigma_i, (w_ij, num_iters) = __umap_find_sigma_i__(
            distances=t.values, rho_i=rho_i, k=topk_i, device=A_.device
        )
    # update A_
    if apply_optimal_k_heuristic is not None:
        # find a natural break in the top k values (another option might be to find a natural break in the resulting weights w_ij, but that's up to the client)
        break_indices: torch.Tensor = __natural_break_by_diff__(
            w_ij if apply_optimal_k_heuristic == "weights" else t.values
        )
        # compute the reset indices (row_indices, col_indices), example ([0,0,0,1,3,3],[3,4,5,5,4,5]) where the max index is 5
        reset_indices: tuple[tuple[int, int], ...] = tuple(
            zip(
                *(
                    tupl
                    for i, break_index in enumerate(break_indices)
                    for tupl in zip(
                        [i] * (topk_i - break_index), range(break_index, topk_i)
                    )
                )
            )
        )
        w_ij[reset_indices] = 0
    A_.fill_(0.0)  # reset A_
    # t.indices: shape (N, topk), t.values: shape (N, topk)
    rows: torch.Tensor = torch.arange(N).unsqueeze(1).expand(-1, topk_i)  # shape (N, topk)
    A_[rows, t.indices] = w_ij
    # reset diagonal, just in case i=j was in the topk
    A_[(range(N), range(N))] = 0
    # symmetrize:
    A_ = {
        "union": A_  # P(A ∪ B) = P(A) + P(B) - P(A ∩ B), where A and B are assumed to be independent such that P(A ∩ B) = P(A) * P(B). Note, this assumption is a simplification and is certainly not true.
        + A_.T
        - A_ * A_.T,
        "intersection": A_  # P(A ∩ B) assuming that A and B are independent events
        * A_.T,
        "min": torch.where(A_ < A_.T, A_, A_.T),
        "max": torch.where(A_ > A_.T, A_, A_.T),
        "none": A_,  # default
    }.get(symmetrize, A_)

    return A_


def filter_clusters_by_size(
    clusters: dict[Any, list[Any]], minsize: int = 2
) -> dict[Any, list[Any]]:
    return {k: v for k, v in clusters.items() if len(v) >= minsize}


def get_cluster_sizes(clusters: dict[Any, list[Any]]) -> dict[Any, int]:
    return {k: len(v) for k, v in clusters.items()}


def get_cluster_size_distribution(clusters: dict[Any, list[Any]]) -> dict[int, int]:
    s: torch.Tensor = torch.tensor(list(get_cluster_sizes(clusters).values()))
    c: tuple[torch.Tensor, torch.Tensor] = s.unique(return_counts=True)
    d: dict[int, int] = {
        int(c[0][i].item()): int(c[1][i].item()) for i in range(c[0].size(0))
    }
    return d


def named_clusters(
    clusters: dict[Any, list[int]],
    names: Sequence[str],
    names_for_keys: bool = False,
) -> dict[Any, list[str]]:
    if names_for_keys:
        return {names[k]: named_labels(v, names) for k, v in clusters.items()}
    return {k: named_labels(v, names) for k, v in clusters.items()}


def named_labels(labels: Sequence[int], names: Sequence[str]) -> list[str]:
    return [names[i] for i in labels]


def labelvector_as_clusterlist(labels: torch.Tensor) -> dict[int, list[int]]:
    return {
        i.item(): [j[0].item() for j in (labels == i).nonzero(as_tuple=False)]
        for i in labels.unique()
    }


def set_newval_where(
    M: torch.Tensor,
    condition: Callable[[torch.Tensor], torch.Tensor] = lambda v: v < 0.5,
    newval: float = 0,
    step: int | None = None,
    sort_on_device: torch.device | str = "cpu",
    appendnewval: bool = True,
) -> torch.Tensor:
    """
    set newval where condition for value is true

    Parameters
    ----------
    M : TYPE
      DESCRIPTION.
    condition : TYPE, optional
      DESCRIPTION. The default is lambda v: v < .5.
    newval : TYPE, optional
      DESCRIPTION. The default is 0.
    step : TYPE, optional
      DESCRIPTION. The default is None. Increase the step size to increase performance but get approximate results. Set to None get a good estimate on stepsize.
    sort_on_device : TYPE, optional
      DESCRIPTION. The default is torch.device('cpu').
    appendnewval : TYPE, optional
      DESCRIPTION. The default is True. Set to True if you expect most values to fail the condition and to False if most values hit the condition.

    Returns
    -------
    M : TYPE
      DESCRIPTION.

    """
    if not step:
        step = max(int(M.numel() * 1e-5), 1)
    half_step: int = max(step // 2, 1)
    m: torch.Tensor = M.view(-1)
    s: Any = m.to(sort_on_device).sort(descending=False)  # sort ascending

    if condition(s.values[0]):
        values: torch.Tensor = s.values
        indices: torch.Tensor = s.indices
    else:
        values = s.values.flip(0)
        indices = s.indices.flip(0)

    if appendnewval:
        for i in range(0, indices.size(0), step):
            if not condition(values[min(i + half_step, values.size(0) - 1)]):
                break
            m[indices[i : i + step]] = newval
    else:
        reversed_values: torch.Tensor = values.flip(0)
        reversed_indices: torch.Tensor = indices.flip(0)
        m[:] = newval
        for i in range(0, reversed_indices.size(0), step):
            if condition(
                reversed_values[min(i + half_step, reversed_values.size(0) - 1)]
            ):
                break
            m[reversed_indices[i : i + step]] = reversed_values[i : i + step].to(
                m.device
            )
    return M


def select_where_gt(
    M: torch.Tensor,
    val: float = 0,
    step: int | None = None,
    sort_on_device: torch.device | str = "cpu",
) -> tuple[tuple[torch.Tensor, torch.Tensor], torch.Tensor, int | None]:
    """
    select indices and values where value is greater than val
    """
    if not step:
        step = max(int(M.numel() * 1e-5), 1)
    half_step: int = step // 2
    m: torch.Tensor = M.view(-1)
    s: Any = m.to(sort_on_device).sort(descending=True)  # sort descending

    condition_: Callable[[torch.Tensor], torch.Tensor] = lambda v: v > val

    for i in range(0, s.indices.size(0), step):
        if not condition_(s.values[min(i + half_step, s.values.size(0) - 1)]):
            return (
                vecindex2matindex(
                    s.indices[: min(i + half_step, s.values.size(0))], M.size(0)
                ),
                s.values[: min(i + half_step, s.values.size(0) - 1)],
                i,
            )
    return vecindex2matindex(s.indices, M.size(0)), s.values, None


def select_where_gt_rev(
    M: torch.Tensor,
    val: float = 0,
    step: int | None = None,
    sort_on_device: torch.device | str = "cpu",
) -> tuple[tuple[torch.Tensor, torch.Tensor], torch.Tensor, int | None]:
    """
    select indices and values where value is greater than val
    """
    if not step:
        step = max(int(M.numel() * 1e-5), 1)
    half_step: int = step // 2
    m: torch.Tensor = M.view(-1)
    s: Any = m.to(sort_on_device).sort(descending=False)  # sort ascending

    condition_: Callable[[torch.Tensor], torch.Tensor] = lambda v: v <= val

    for i in range(0, s.indices.size(0), step):
        if not condition_(s.values[min(i + half_step, s.values.size(0) - 1)]):
            return (
                vecindex2matindex(
                    s.indices[min(i + half_step, s.values.size(0)) :], M.size(0)
                ),
                s.values[min(i + half_step, s.values.size(0) - 1) :],
                i,
            )
    return vecindex2matindex(s.indices[:0], M.size(0)), s.values[:0], None


def set_val_for_edges_with_same_property(
    M: torch.Tensor, properties: Sequence[Any], val: float = 0
) -> torch.Tensor:
    # for each unique word
    properties_unique: set[Any] = set(properties)
    for propu in properties_unique:
        idxs: torch.Tensor = torch.tensor(
            [i for i, prop in enumerate(properties) if prop == propu], dtype=torch.long
        )
        M[idxs.repeat_interleave(idxs.size(0)), idxs.repeat(idxs.size(0))] = val
    return M


def pretty_print_matrix(
    M: np.ndarray,
    rownames: Sequence[str] | None = None,
    colnames: Sequence[str] | None = None,
    width: int = 12,
    value_format: str = ".3f",
    colsep: str = " ",
    rowsep: str = "\n",
    row_name_format: str = "s",
    col_name_format: str = "s",
    out: TextIO = sys.stdout,
) -> None:
    if rownames is None:
        rownames = [str(i) for i in range(M.shape[0])]
    if colnames is None:
        colnames = [str(i) for i in range(M.shape[1])]

    # trim colnames and rownames
    rownames_list: list[str] = [
        name if len(name) <= width else name[: width - 4] + ".." + name[-2:]
        for name in [f"{name:{row_name_format}}" for name in rownames]
    ]
    colnames_list: list[str] = [
        name if len(name) <= width else name[: width - 4] + ".." + name[-2:]
        for name in [f"{name:{col_name_format}}" for name in colnames]
    ]

    # header
    print(
        " " * width
        + colsep
        + colsep.join([f"{name:^{width}.{width}s}" for name in colnames_list]),
        end=rowsep,
        file=out,
    )
    for ri in range(M.shape[0]):
        print(
            f"{rownames_list[ri]:<{width}.{width}s}"
            + colsep
            + colsep.join(
                [
                    f"{sval:^{width}.{width}s}"
                    for sval in [f"{val:{value_format}}" for val in M[ri, :]]
                ]
            ),
            end=rowsep,
            file=out,
        )


def pretty_print_matrix_concise(
    M: np.ndarray,
    rownames: Sequence[str] | None = None,
    colnames: Sequence[str] | None = None,
    width: int = 4,
    value_format: str = ".2f",
    colsep: str = " ",
    rowsep: str = "\n",
    out: TextIO = sys.stdout,
) -> None:
    if rownames is None:
        rownames = [str(i) for i in range(M.shape[0])]
    if colnames is None:
        colnames = [str(i) for i in range(M.shape[1])]

    colmarker: str = "|"
    # header
    for i, colname in enumerate(colnames):
        print(f'{"":>{width-1}.{width-1}s}', end="", file=out)
        print(colname, end=rowsep, file=out)
        # if (i+1) < len(colnames):
        print((f"{colmarker:>{width}.{width}s}" + colsep) * (i + 1), end="", file=out)
    print(end=rowsep, file=out)

    # rows
    for i, rowname in enumerate(rownames):
        print(
            colsep.join(
                [
                    f"{sval:>{width}.{width}s}"
                    for sval in [f"{val:{value_format}}" for val in M[i, :]]
                ]
            ),
            end=colsep,
            file=out,
        )
        print(" -- ", end="", file=out)
        print(rowname, end=rowsep, file=out)


def skl_dbscan(
    X: np.ndarray, *args: Any, out: list[str] | None = None, **kwargs: Any
) -> dict[str, Any]:
    if out is None:
        out = ["labelvector"]
    d: DBSCAN = DBSCAN(*args, **kwargs)
    return __skl_fit_predict__(d, X, out)


def skl_optics(
    X: np.ndarray, *args: Any, out: list[str] | None = None, **kwargs: Any
) -> dict[str, Any]:
    if out is None:
        out = ["labelvector"]
    o: OPTICS = OPTICS(*args, **kwargs)
    return __skl_fit_predict__(o, X, out)


def skl_spectral(
    X: np.ndarray, *args: Any, out: list[str] | None = None, **kwargs: Any
) -> dict[str, Any]:
    if out is None:
        out = ["labelvector"]
    s: SpectralClustering = SpectralClustering(*args, affinity="precomputed", **kwargs)
    return __skl_fit_predict__(s, X, out)


def skl_affinity_propagation(
    X: np.ndarray,
    *args: Any,
    out: list[str] | None = None,
    random_state: int | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    if out is None:
        out = ["labelvector"]
    a: AffinityPropagation = AffinityPropagation(
        damping=0.5,
        max_iter=2000,
        convergence_iter=10,
        random_state=random_state,
        affinity="precomputed",
    )
    return __skl_fit_predict__(a, X, out)


def skl_affinity_propagation_euc(
    X: torch.Tensor,
    *args: Any,
    out: list[str] | None = None,
    random_state: int | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    if out is None:
        out = ["labelvector"]
    # compute euclidean distances for points in X (same as passing X and affinity='euclidean' to AffinityPropagation)
    X_distances: torch.Tensor = -torch.cdist(X, X) ** 2
    a: AffinityPropagation = AffinityPropagation(
        damping=0.5, random_state=random_state, affinity="precomputed"
    )
    return __skl_fit_predict__(a, X_distances, out)


def __skl_fit_predict__(
    model: Any, X: np.ndarray | torch.Tensor, out: list[str]
) -> dict[str, Any]:
    label_vec: torch.Tensor = torch.tensor(model.fit_predict(X))
    labels: dict[int, list[int]] = labelvector_as_clusterlist(label_vec)
    res: dict[str, Any] = {"labels": labels}
    if "labelvector" in out:
        res["labelvector"] = label_vec
    return res


def purity_score(
    y_true: Sequence[Any], y_pred: Sequence[Any]
) -> tuple[float, float, float]:
    # compute contingency matrix (also called confusion matrix)
    contingency_matrix: Any = metrics.cluster.contingency_matrix(
        y_true, y_pred, sparse=False
    )
    # return purity
    purity: float = float(np.sum(np.amax(contingency_matrix, axis=1)) / np.sum(contingency_matrix))
    inverse_purity: float = float(
        np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix)
    )
    f1: float = 2 * ((purity * inverse_purity) / (purity + inverse_purity))
    return purity, inverse_purity, f1


def bcubed_scores(
    y_true: Sequence[Any], y_pred: Sequence[Any]
) -> tuple[float, float, float]:
    # create dictionary of items for bcubed-python package
    ldict: dict[str, set[Any]] = {f"item_{i}": set([v]) for i, v in enumerate(y_true)}
    cdict: dict[str, set[Any]] = {f"item_{i}": set([v]) for i, v in enumerate(y_pred)}
    precision: float = float(bcubed.precision(cdict, ldict))
    recall: float = float(bcubed.recall(cdict, ldict))
    fscore: float = bcubed.fscore(precision, recall)
    return precision, recall, fscore


def parwise_metric_scores(
    y_true: Sequence[Any] | np.ndarray,
    y_pred: Sequence[Any] | np.ndarray,
    f_beta: float = 1.0,
) -> tuple[float, float, float, float, float]:
    y_true_arr: np.ndarray = np.asarray(y_true)
    y_pred_arr: np.ndarray = np.asarray(y_pred)
    # number of samples
    (n_samples,) = y_true_arr.shape
    # comute the number of all possible pairs
    n_pairs: float = n_samples * (n_samples - 1) / 2
    # compute contingency matrix
    c: Any = metrics.cluster.contingency_matrix(y_true_arr, y_pred_arr, sparse=True).astype(
        np.int64, copy=False
    )
    # compute the number of pairs in predicted clustering (total predicted positives)
    TP_plus_FP: int = sum([math.comb(x, 2) for x in np.asarray(c.sum(axis=0)).ravel()])
    # compute the number of pairs in true clustering (total class positives)
    TP_plus_FN: int = sum([math.comb(x, 2) for x in np.asarray(c.sum(axis=1)).ravel()])
    # true positives
    TP: int = sum([math.comb(x, 2) for x in c.data])
    # false positives, false negatives and true negatives
    FP: int = TP_plus_FP - TP
    FN: int = TP_plus_FN - TP
    TN: float = n_pairs - TP - FP - FN
    # precision, recall, accuracy
    prec: float = (TP / TP_plus_FP) if TP_plus_FP != 0 else 1
    rec: float = (TP / TP_plus_FN) if TP_plus_FN != 0 else 1
    acc: float = ((TP + TN) / n_pairs) if n_pairs != 0 else 1
    # f1 / f_beta
    f_beta_squared: float = math.pow(f_beta, 2)
    f_beta_score: float = (
        (1 + f_beta_squared) * ((prec * rec) / ((f_beta_squared * prec) + rec))
        if prec > 0 or rec > 0
        else 0.0
    )
    # Fowlkes–Mallows index
    fmi: float = math.sqrt(prec * rec)
    # +++
    return prec, rec, acc, f_beta_score, fmi


# more internal evaluation scores? https://en.wikipedia.org/wiki/Cluster_analysis#Internal_evaluation
def evaluate_cluster_labels_internal(
    distances: torch.Tensor, labels_pred: Sequence[Any]
) -> None:
    # mean_silhouette_score = metrics.silhouette_score(X, labels_pred, metric='precomputed', sample_size=None, random_state=None) # sample distance matrix or feature matrix is required, but we don't have that here
    pass


def evaluate_cluster_labels(
    labels_true: Sequence[Any],
    labels_pred: Sequence[Any],
    omit_contingency: bool = False,
    use_concise_pretty_print_matrix: bool = True,
) -> dict[str, Any]:
    """
    Expects label vectors to be a list or a numpy array
    """
    scores: dict[str, Any] = {}

    classes: np.ndarray
    class_idx: np.ndarray
    clusters: np.ndarray
    cluster_idx: np.ndarray
    classes, class_idx = np.unique(labels_true, return_inverse=True)
    clusters, cluster_idx = np.unique(labels_pred, return_inverse=True)

    scores["nsamples_true"] = len(labels_true)
    scores["nsamples_pred"] = len(labels_pred)
    scores["nclasses"] = len(classes)
    scores["nclusters"] = len(clusters)
    scores["rdiff"] = 1 - (
        abs(len(classes) - len(clusters)) / max(len(classes), len(clusters))
    )  # make difference value relative and 1 to be best 0 to be worst

    if (
        scores["nsamples_true"] != scores["nsamples_pred"]
        or scores["nsamples_true"] == 0
        or scores["nsamples_pred"] == 0
    ):
        return scores

    ri: float = float(metrics.rand_score(labels_true, labels_pred))
    ari: float = float(metrics.adjusted_rand_score(labels_true, labels_pred))
    mi: float = float(metrics.mutual_info_score(labels_true, labels_pred))
    nmi: float = float(metrics.normalized_mutual_info_score(labels_true, labels_pred))
    ami: float = float(metrics.adjusted_mutual_info_score(labels_true, labels_pred))
    h: float
    c: float
    v: float
    h, c, v = metrics.homogeneity_completeness_v_measure(labels_true, labels_pred) # pyright: ignore[reportAssignmentType]
    fmi: float = metrics.fowlkes_mallows_score(labels_true, labels_pred)
    pu: float
    ipu: float
    puf1: float
    pu, ipu, puf1 = purity_score(labels_true, labels_pred)
    b3p: float
    b3r: float
    b3f1: float
    b3p, b3r, b3f1 = bcubed_scores(labels_true, labels_pred)
    pair_prec: float
    pair_rec: float
    pair_acc: float
    pair_f1: float
    pair_fmi: float
    pair_prec, pair_rec, pair_acc, pair_f1, pair_fmi = parwise_metric_scores(
        y_true=labels_true, y_pred=labels_pred
    )

    if omit_contingency:
        cmatp: str = "omitted"
    else:
        cmat: Any = metrics.cluster.contingency_matrix(labels_true, labels_pred)
        with io.StringIO() as fout:
            if use_concise_pretty_print_matrix:
                pretty_print_matrix_concise(
                    cmat,
                    rownames=[str(c) for c in classes],
                    colnames=[str(c) for c in clusters],
                    value_format="d",
                    out=fout,
                )
            else:
                pretty_print_matrix(
                    cmat,
                    rownames=[str(c) for c in classes],
                    colnames=[str(c) for c in clusters],
                    value_format="d",
                    out=fout,
                )
            cmatp = "\n" + fout.getvalue()

    scores.update(
        {
            "ri": ri,
            "ari": ari,
            "mi": mi,
            "nmi": nmi,
            "ami": ami,
            "h": h,
            "c": c,
            "v": v,
            "fmi": fmi,
            "pu": pu,
            "ipu": ipu,
            "puf1": puf1,
            "b^3p": b3p,
            "b^3r": b3r,
            "b^3f1": b3f1,
            "p(pair)": pair_prec,
            "r(pair)": pair_rec,
            "a(pair)": pair_acc,
            "f1(pair)": pair_f1,
            "fmi(pair)": pair_fmi,
            "contingency": cmatp,
        }
    )
    return scores
