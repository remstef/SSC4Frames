#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: @remstef
"""

from typing import Any, Callable

from ptgcl import utils


class CLI(object):
    """ """

    def __init__(self) -> None:
        # check if libraries for server are install, for now just assume they are
        server: Callable[..., Any]
        try:
            from ptgcl.app import serve

            server = serve.main
        except Exception:
            server = lambda *args, **kwargs: (
                "Server app is unavailable install ptgcl[.app] if you want server support!"
            )
        self.server = server

    def version(self) -> str:
        return utils.version()
