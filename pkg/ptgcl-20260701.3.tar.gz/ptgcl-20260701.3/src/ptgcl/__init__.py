# init package, provide modules within namespace
from ptgcl import cl, tg
from ptgcl.cw import cw as run_cw
from ptgcl.maxmax import maxmax as run_maxmax
from ptgcl.mcl import mcl as run_mcl

__all__ = ["cl", "tg", "run_cw", "run_mcl", "run_maxmax"]
