#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Created on Tue Dec 15 20:03:54 2020

https://link.springer.com/chapter/10.1007%2F978-3-642-37247-6_30

procedure MaxMax(G = (V, E))
  construct a directed graph G′ = (V,E′) where:
  (v,u)∈ E′ iff (u,v)∈ E and v is one of the maximal vertices for u
  mark all vertices of G′ initially as root
  for each vertex v of G′ do
    if v is marked root then
      mark any descendant u of v (u ̸= v) as ¬root
    end if
  end for
end procedure

@author: rem
"""

from typing import Any

import torch

from ptgcl import cl


def maxmax_test() -> dict[str, Any]:
    return maxmax(cl.G_maxmax())


def __direct_descendants__(M: torch.Tensor, i: int) -> torch.Tensor:
    return M[i, :].nonzero(as_tuple=False)[:, 0]


def __all_descendants__(M: torch.Tensor, i: int) -> torch.Tensor:
    visited: torch.Tensor = torch.zeros(M.size(0), dtype=torch.bool).to(M.device)
    return __traverse__(M, i, i, visited).nonzero(as_tuple=True)[0]


def __traverse__(
    M: torch.Tensor, i_start: int, i_current: int, visited: torch.Tensor
) -> torch.Tensor:
    for j_current in __direct_descendants__(M, i_current).tolist():
        if j_current != i_start and not visited[j_current]:
            visited[j_current] = True
            __traverse__(M, i_start, j_current, visited)
    return visited


# complete
def __transform_sort__(M: torch.Tensor) -> torch.Tensor:
    N: int = M.size(0)
    # convert to directed graph
    # get most valuable edge and use it as the only! incoming edge, remove diagonals (self-loops)
    M[(range(N), range(N))] = 0
    s: torch.return_types.sort = M.sort(dim=1, descending=True)
    # set the top entries
    M.fill_(0)
    M[s.indices[:, 0], range(N)] = 1
    # in case of ties, i.e. multiple top edges also set the values of those
    for i in range(1, N):
        more: torch.Tensor = s.values[:, 0] == s.values[:, i]
        if not more.any():
            break
        M[s.indices[:, i][more], more.nonzero(as_tuple=False)[:, 0]] = 1
        del more
    del s
    return M


# approx
def __transform_top__(M: torch.Tensor, k: int = 100) -> torch.Tensor:
    N: int = M.size(0)
    k = min(k, N)
    # convert to directed graph
    # get most valuable edge and use it as the only! incoming edge, remove diagonals (self-loops)
    M[(range(N), range(N))] = 0
    t: torch.return_types.topk = M.topk(dim=1, k=k)
    # set the top entries
    M.fill_(0)
    M[t.indices[:, 0], range(N)] = 1
    # in case of ties, i.e. multiple top edges, set the values of those too
    for i in range(1, k):
        more: torch.Tensor = t.values[:, 0] == t.values[:, i]
        if not more.any():
            break
        M[t.indices[:, i][more], more.nonzero(as_tuple=False)[:, 0]] = 1
        del more
    del t
    return M


def maxmax(
    A: torch.Tensor,
    out: list[str] | None = None,
    random_seed: int = 0,
) -> dict[str, Any]:
    if out is None:
        out = ["rootnodes"]

    rand_generator: torch.Generator = torch.Generator()
    rand_generator.manual_seed(random_seed)
    # number of nodes
    N: int = A.size(0)
    # stage 1:
    __transform_top__(A)
    # stage 2:
    isroot: torch.Tensor = torch.ones(N, dtype=torch.bool).to(A.device)

    perm: list[int] = torch.randperm(N, generator=rand_generator).tolist()
    for v in perm:  # random_generator.sample(range(N), N):
        if isroot[v]:
            desc: torch.Tensor = __all_descendants__(A, v)
            isroot[desc] = False
    # stage 3: interpret clusters by traversing each root node
    labels: dict[int, list[int]] = {}
    for i in isroot.nonzero(as_tuple=False)[:, 0].tolist():
        labels[i] = [i] + __all_descendants__(A, i).tolist()
    res: dict[str, Any] = {"labels": labels}
    if "rootnodes" in out:
        res["rootnodes"] = isroot
    else:
        del isroot
    return res
