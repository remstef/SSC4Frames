#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: @remstef

"""

import os
import subprocess
from importlib import metadata


def version(fallback_packagename: str = "ptgcl") -> str:
    git_revision_short_hash: str = ""
    pkg_version: str = ""
    try:
        git_revision_short_hash = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            stderr=subprocess.DEVNULL,
        ).decode('ascii').strip()
    except:
        pass
    name: str = __package__.split(".")[0] if __package__ is not None else fallback_packagename
    version_str: str = metadata.version(name)
    pkg_version = f"{name}.v{version_str}"
    if len(git_revision_short_hash):
        pkg_version = f"{pkg_version}@{git_revision_short_hash}"
    return pkg_version
