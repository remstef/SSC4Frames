from ptgcl.cli import CLI
import fire

def main() -> None:
    fire.Fire(CLI, name="ptgcl")

if __name__ == "__main__":
    main()
