#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: remstef
"""

from typing import Any

import logging
import networkx as nx
import numpy as np
import torch
import typing
import os

from ptgcl import cl
from ptgcl.logging import setup_logger, set_log_verbosity

logger: logging.Logger = setup_logger(os.path.basename(__file__))


def prepare_graph_from_matrix(A: torch.Tensor | np.ndarray) -> nx.Graph:
    A_np: np.ndarray = A.numpy() if isinstance(A, torch.Tensor) else A
    return nx.from_numpy_array(A_np)


def cw_netx(
    A: torch.Tensor,
    seed: int = 4711,
    minweight: float = 1e-3,
    binarize: bool = True,
    max_iter: int = 20,
    out: list[str] | None = None,
) -> dict[str, Any]:
    if out is None:
        out = ["graph"]
    from chinese_whispers import chinese_whispers, aggregate_clusters

    # number of nodes
    N: int = A.shape[0]

    # prune by min weight
    A[A < minweight] = 0

    # make sure the graph contains only ones and zeros
    if binarize:
        A[A > 0] = 1
        A[A < 0] = 0

    # remove self-loops
    A[(range(N), range(N))] = 0

    # convert matrix to networkx graph
    G: nx.Graph = prepare_graph_from_matrix(A.cpu().numpy())

    # run chinese whispers, return labelled graph
    H: Any = chinese_whispers(G, seed=4711, iterations=max_iter)
    # get labels as lists
    labels: dict[int, Any] = aggregate_clusters(H)
    res: dict[str, Any] = {"labels": labels}
    if "graph" in out:
        res["graph"] = H
    else:
        del H
    return res


def __neighbors_in__(M: torch.Tensor, i: int) -> torch.Tensor:
    return M[:, i].nonzero(as_tuple=False)[:, 0]


def __out_degrees__(M: torch.Tensor, node_ids: torch.Tensor) -> torch.Tensor:
    return (M[node_ids, :] > 0).sum(dim=1, dtype=torch.float)


def __out_degree_mass__(M: torch.Tensor, node_ids: torch.Tensor) -> torch.Tensor:
    return M[node_ids, :].sum(dim=1, dtype=torch.float)


def __in_degrees__(M: torch.Tensor, node_ids: torch.Tensor) -> torch.Tensor:
    return (M[:, node_ids] > 0).sum(dim=0, dtype=torch.float)


def __in_degree_mass__(M: torch.Tensor, node_ids: torch.Tensor) -> torch.Tensor:
    return M[:, node_ids].sum(dim=0, dtype=torch.float)


def __w_top_in__(M: torch.Tensor, i: int, node_ids: torch.Tensor) -> torch.Tensor:
    """Weight is the incoming edge weight from every node_id to i. NOTE: weight of incoming and outgoing edges should be the same."""
    return M[node_ids, i]


def __w_lin_in__(M: torch.Tensor, i: int, node_ids: torch.Tensor) -> torch.Tensor:
    """Weight is the incoming edge weight from every node_id to i divided by node's out degree. NOTE: incoming and outgoing edges should be the same."""
    out_degrees: torch.Tensor = __out_degrees__(M, node_ids)
    return M[node_ids, i] / out_degrees


def __w_lin_mass_in__(M: torch.Tensor, i: int, node_ids: torch.Tensor) -> torch.Tensor:
    """Weight is the incoming edge weight from every node_id to i divided by node's out degree mass. NOTE: incoming and outgoing edges should be the same."""
    out_degree_mass: torch.Tensor = __out_degree_mass__(M, node_ids)
    return M[node_ids, i] / out_degree_mass


def __w_log_in__(M: torch.Tensor, i: int, node_ids: torch.Tensor) -> torch.Tensor:
    """Weight is the edge weight divided by log_2 of the node's out degree. NOTE: incoming and outgoing edges should be the same."""
    out_degrees: torch.Tensor = __out_degrees__(M, node_ids)
    return M[node_ids, i] / (out_degrees + 1).log2()


def __w_log_mass_in__(M: torch.Tensor, i: int, node_ids: torch.Tensor) -> torch.Tensor:
    """Weight is the edge weight divided by log_2 of the node's out degree mass. NOTE: incoming and outgoing edges should be the same."""
    out_degree_mass: torch.Tensor = __out_degree_mass__(M, node_ids)
    return M[node_ids, i] / (out_degree_mass + 1).log2()


def single_random_choice_from_vector(
    options: torch.Tensor, rand_generator: torch.Generator
) -> torch.Tensor:
    return options[torch.randint(len(options), (1,), generator=rand_generator)]


def __select_label_by_max_label_sum__(
    vi: int,
    vi_neighbors: torch.Tensor,
    vi_neighbor_weights: torch.Tensor,
    vi_neighbor_labels: torch.Tensor,
    global_label_counts: torch.Tensor | None,
    rand_generator: torch.Generator,
    *args: Any,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
    """select label from each neighbor, sum weights, and select maximum (random for ties; default Chinese Whispers behavior)"""
    # compute the label weights
    unique_neighbor_labels: torch.Tensor
    rev_index: torch.Tensor
    label_counts: torch.Tensor
    unique_neighbor_labels, rev_index, label_counts = vi_neighbor_labels.unique(
        return_inverse=True, return_counts=True
    )
    # prepare a local neighbor-to-label weight matrix
    W: torch.Tensor = torch.zeros(vi_neighbors.size(0), unique_neighbor_labels.size(0)).to(
        vi_neighbors.device
    )
    W[range(vi_neighbors.size(0)), rev_index] = vi_neighbor_weights
    vi_neighbor_label_weights: torch.Tensor = W.sum(dim=0)
    # get the maximum count labels
    max_label_weight: torch.Tensor = vi_neighbor_label_weights.max()
    max_label_weight_label_options: torch.Tensor = (
        vi_neighbor_label_weights == max_label_weight
    ).nonzero(as_tuple=False)[:, 0]
    # get a random label of the max options, give priority to nodes with a fixed label
    vi_label_new: torch.Tensor = unique_neighbor_labels[
        single_random_choice_from_vector(max_label_weight_label_options, rand_generator)
    ]
    return (
        vi_label_new,
        unique_neighbor_labels[max_label_weight_label_options],
        (unique_neighbor_labels, vi_neighbor_label_weights),
    )


def __select_label_by_sampled_label_sum__(
    vi: int,
    vi_neighbors: torch.Tensor,
    vi_neighbor_weights: torch.Tensor,
    vi_neighbor_labels: torch.Tensor,
    global_label_counts: torch.Tensor | None,
    rand_generator: torch.Generator,
    *args: Any,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
    """select label from each neighbor, sum weights, treat new label sum weights as probability distribution and sample a class label"""
    # compute the label weights
    unique_neighbor_labels: torch.Tensor
    rev_index: torch.Tensor
    label_counts: torch.Tensor
    unique_neighbor_labels, rev_index, label_counts = vi_neighbor_labels.unique(
        return_inverse=True, return_counts=True
    )
    # prepare a local neighbor-to-label weight matrix
    W: torch.Tensor = torch.zeros(vi_neighbors.size(0), unique_neighbor_labels.size(0)).to(
        vi_neighbors.device
    )
    W[range(vi_neighbors.size(0)), rev_index] = vi_neighbor_weights
    vi_neighbor_label_weights: torch.Tensor = W.sum(dim=0)
    # sample random label by using the label weights as probability distribution
    vi_label_sample_i: torch.Tensor = torch.multinomial(vi_neighbor_label_weights, 1)[0]
    vi_label_new: torch.Tensor = unique_neighbor_labels[vi_label_sample_i]
    return (
        vi_label_new,
        torch.empty(0).int(),
        (unique_neighbor_labels, vi_neighbor_label_weights),
    )


def __select_label_by_max_neighbor__(
    vi: int,
    vi_neighbors: torch.Tensor,
    vi_neighbor_weights: torch.Tensor,
    vi_neighbor_labels: torch.Tensor,
    global_label_counts: torch.Tensor | None,
    rand_generator: torch.Generator,
    *args: Any,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
    """select the class of the highest weighted neighbor (random for ties)"""
    max_neighbor_weight: torch.Tensor = vi_neighbor_weights.max()
    max_neighbor_weight_neighbor_options: torch.Tensor = (
        vi_neighbor_weights == max_neighbor_weight
    ).nonzero(as_tuple=False)[:, 0]
    # get a random label of the max options
    vi_label_new: torch.Tensor = vi_neighbor_labels[
        single_random_choice_from_vector(
            max_neighbor_weight_neighbor_options, rand_generator
        )
    ]
    return (
        vi_label_new,
        vi_neighbor_labels[max_neighbor_weight_neighbor_options],
        (vi_neighbor_labels, vi_neighbor_weights),
    )


def __select_label_by_sampled_neighbor__(
    vi: int,
    vi_neighbors: torch.Tensor,
    vi_neighbor_weights: torch.Tensor,
    vi_neighbor_labels: torch.Tensor,
    global_label_counts: torch.Tensor | None,
    rand_generator: torch.Generator,
    *args: Any,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
    """treat neighbor weights as probability distribution, sample a neighbor and select the class the sampled neighbor"""
    # sample a random neighbor by using the weights as probabilities
    vi_neighbor_sample_i: torch.Tensor = torch.multinomial(
        vi_neighbor_weights, 1, generator=rand_generator
    )[0]
    vi_label_new: torch.Tensor = vi_neighbor_labels[vi_neighbor_sample_i]
    return vi_label_new, torch.empty(0).int(), (vi_neighbor_labels, vi_neighbor_weights)


def __select_label_by_max_label_dist__(
    vi: int,
    vi_neighbors: torch.Tensor,
    vi_neighbor_weights: torch.Tensor,
    vi_neighbor_labels: torch.Tensor,
    global_label_counts: torch.Tensor | None,
    rand_generator: torch.Generator,
    *args: Any,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
    """ATTENTION, this strategy still needs to be tested more thoroughly"""
    """ same as __select_label_by_max_label_sum__ but multiply label weights (probability) with global vi label assignment (probability) """
    # compute the label weights
    unique_neighbor_labels: torch.Tensor
    rev_index: torch.Tensor
    label_counts: torch.Tensor
    unique_neighbor_labels, rev_index, label_counts = vi_neighbor_labels.unique(
        return_inverse=True, return_counts=True
    )
    # prepare a local neighbor-to-label weight matrix
    W: torch.Tensor = torch.zeros(vi_neighbors.size(0), unique_neighbor_labels.size(0)).to(
        vi_neighbors.device
    )
    W[range(vi_neighbors.size(0)), rev_index] = vi_neighbor_weights
    vi_neighbor_label_weights: torch.Tensor = W.sum(dim=0)
    # probs
    assert global_label_counts is not None
    vi_label_counts: torch.Tensor = global_label_counts[vi, unique_neighbor_labels].to(
        vi_neighbor_label_weights.device
    )
    vi_neighbor_label_probs: torch.Tensor = (
        vi_neighbor_label_weights * vi_label_counts
    )  # no need to normalize vi_neighbor_label_counts
    # get the maximum count labels
    max_label_prob: torch.Tensor = vi_neighbor_label_probs.max()
    max_label_prob_label_options: torch.Tensor = (vi_neighbor_label_probs == max_label_prob).nonzero(
        as_tuple=False
    )[:, 0]
    # get a random label of the max options
    vi_label_new: torch.Tensor = unique_neighbor_labels[
        single_random_choice_from_vector(max_label_prob_label_options, rand_generator)
    ]
    return (
        vi_label_new,
        torch.empty(0).int(),
        (unique_neighbor_labels, vi_neighbor_label_weights),
    )


def __select_label_by_sampled_label_dist__(
    vi: int,
    vi_neighbors: torch.Tensor,
    vi_neighbor_weights: torch.Tensor,
    vi_neighbor_labels: torch.Tensor,
    global_label_counts: torch.Tensor | None,
    rand_generator: torch.Generator,
    *args: Any,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
    """ATTENTION, this strategy still needs to be tested more thoroughly"""
    """ same as __select_label_by_sampled_label_sum__ but multiply label weights (probability) with global vi label assignment (probability) """
    # compute the label weights
    unique_neighbor_labels: torch.Tensor
    rev_index: torch.Tensor
    label_counts: torch.Tensor
    unique_neighbor_labels, rev_index, label_counts = vi_neighbor_labels.unique(
        return_inverse=True, return_counts=True
    )
    # prepare a local neighbor-to-label weight matrix
    W: torch.Tensor = torch.zeros(vi_neighbors.size(0), unique_neighbor_labels.size(0)).to(
        vi_neighbors.device
    )
    W[range(vi_neighbors.size(0)), rev_index] = vi_neighbor_weights
    vi_neighbor_label_weights: torch.Tensor = W.sum(dim=0)
    # probabilities
    assert global_label_counts is not None
    vi_label_counts: torch.Tensor = global_label_counts[vi, unique_neighbor_labels].to(
        vi_neighbor_label_weights.device
    )
    vi_neighbor_label_probs: torch.Tensor = (
        vi_neighbor_label_weights * vi_label_counts
    )  # no need to normalize vi_neighbor_label_counts
    # sample random label by using the label weights as probability distribution
    vi_label_sample_i: torch.Tensor = torch.multinomial(
        vi_neighbor_label_probs, 1, generator=rand_generator
    )[0]
    vi_label_new: torch.Tensor = unique_neighbor_labels[vi_label_sample_i]
    return (
        vi_label_new,
        torch.empty(0).int(),
        (unique_neighbor_labels, vi_neighbor_label_weights),
    )


__weighting_schemes__: dict[str, typing.Callable[..., typing.Any]] = {
    "top": __w_top_in__,
    "lin": __w_lin_in__,
    "log": __w_log_in__,
    "linmass": __w_log_mass_in__,
    "logmass": __w_log_mass_in__,
}

__label_by_schemes__: dict[str, typing.Callable[..., typing.Any]] = {
    # default CW behavior
    "max_label": __select_label_by_max_label_sum__,
    # variants that work
    "sample_label": __select_label_by_sampled_label_sum__,
    "max_neighbor": __select_label_by_max_neighbor__,
    "sample_neighbor": __select_label_by_sampled_neighbor__,
    # EXPERIMENTAL
    "max_label_dist": __select_label_by_max_label_dist__,
    "sample_label_dist": __select_label_by_sampled_label_dist__,
}


def __prune_graph__(
    A: torch.Tensor, optimize_space: bool = False, minweight: float | str = 0.0
) -> None:
    logger.debug(
        f"Pruning by {minweight} and with space optimization {optimize_space}."
    )
    mv: float
    i0: tuple[torch.Tensor, torch.Tensor]
    v0: torch.Tensor
    _idx: int | None
    if isinstance(minweight, str):
        if minweight == "mean":
            mv = A.mean().item()
            logger.debug(f"mean {mv}.")
            if optimize_space:
                A = cl.set_newval_where(
                    A,
                    condition=lambda v: v < mv,
                    newval=0,
                    step=None,
                    appendnewval=False,
                )  # A[A < mv] = 0
            else:
                A[A < mv] = 0
        elif minweight == "mean0":
            if optimize_space:
                i0, v0, _idx = cl.select_where_gt_rev(
                    A, val=0, step=None
                )  # (A > 0).nonzero()
                mv = v0.mean().item()
                A = cl.set_newval_where(
                    A,
                    condition=lambda v: v < mv,
                    newval=0,
                    step=None,
                    appendnewval=False,
                )  # A[A < mw] = 0
            else:
                i0_mean0: tuple[torch.Tensor, ...] = (A > 0).nonzero(as_tuple=True)
                v0 = A[i0_mean0]
                mv = v0.mean().item()
                logger.debug(f"mean0 {mv}.")
                A[A < mv] = 0
        elif minweight == "median":
            mv = A.median().item()
            logger.debug(f"median {mv}.")
            if optimize_space:
                A = cl.set_newval_where(
                    A,
                    condition=lambda v: v < mv,
                    newval=0,
                    step=None,
                    appendnewval=False,
                )  # A[A < mw] = 0
            else:
                A[A < mv] = 0
        elif minweight == "median0":
            if optimize_space:
                i0, v0, _idx = cl.select_where_gt_rev(
                    A, val=0, step=None
                )  # (A > 0).nonzero()
                _, mvi = v0.median(
                    0
                )  # v0 is sorted ascending, so we can reuse the index of the median value
                A.view(-1)[
                    cl.matindex2vecindex(i0, A.shape[0])[:mvi]
                ] = 0  # A[A < mw] = 0
            else:
                i0_median0: tuple[torch.Tensor, ...] = (A > 0).nonzero(as_tuple=True)
                v0 = A[i0_median0]
                mv = v0.median().item()
                logger.debug(f"median0 {mv}.")
                A[A < mv] = 0
        else:
            raise ValueError(f"""Illegal minweight specifier '{minweight}'.""")
    else:
        if optimize_space:
            A = cl.set_newval_where(
                A,
                condition=lambda v: v < minweight,
                newval=0,
                step=None,
                appendnewval=False,
            )  # A[A < minweight] = 0
        else:
            A[A < minweight] = 0


def __binarize_graph__(A: torch.Tensor, optimize_space: bool = False) -> None:
    logger.debug(f"Binarizing with space optimization {optimize_space}.")
    if optimize_space:
        A = cl.set_newval_where(
            A, condition=lambda v: v > 0, newval=1, step=None, appendnewval=True
        )  # A[A>0] = 1
        A = cl.set_newval_where(
            A, condition=lambda v: v < 0, newval=0, step=None, appendnewval=True
        )  # A[A<0] = 0
    else:
        A[A > 0] = 1
        A[A < 0] = 0


def __init_node_labels__(
    N: int,
    fixed_labels: list[str | None] | None = None,
    fixed_labelsmap: dict[Any, int] | None = None,
) -> torch.Tensor:
    node_labels: torch.Tensor = torch.arange(N)
    if fixed_labels is not None and len(fixed_labels) and fixed_labelsmap is not None:
        for i in range(N):
            if fixed_labels[i] is not None:
                node_labels[i] = fixed_labelsmap[fixed_labels[i]]
    return node_labels


def __preprocess_graph__(
    A: torch.Tensor,
    remove_self_loops: bool = False,
    minweight: float | str = 0.0,
    binarize: bool = False,
    optimize_space: bool = False,
    **kwargs: Any,
) -> torch.Tensor:
    """
    ATTENTION: This method changes the underlying adjacency matrix A.
    If you need the original values you have to make a deep copy of A before calling this function!!!
    """
    N: int = A.shape[0]
    # remove self-loops
    logger.debug(f"Removing self-loops.")
    if remove_self_loops:
        A[(range(N), range(N))] = 0

    # prune by min weight
    __prune_graph__(A=A, optimize_space=optimize_space, minweight=minweight)

    # make sure the graph contains only ones and zeros
    if binarize:
        __binarize_graph__(A=A, optimize_space=False)
    return A


def _cw_no_preprocessing_(
    A: torch.Tensor,
    max_iter: int = 100,
    label_by: str = "max_label",
    weighting: str = "top",
    fixed_labels: list[str | None] | None = None,
    out: list[str] | None = None,
    label_counts_device: torch.device | str = "cpu",
    verbose: bool = False,
    quiet: bool = False,
    random_seed: int = 0,
) -> dict[str, Any]:
    if out is None:
        out = [
            "A",
            "labelvector",
            "previouslabelvector",
            "history",
            "labelcounts",
            "fixed_labelsmap",
        ]
    assert out is not None
    set_log_verbosity(logger=logger, verbose=verbose, quiet=quiet)
    rand_generator: torch.Generator = torch.Generator()
    rand_generator.manual_seed(random_seed)
    # number of nodes
    N: int = A.shape[0]
    logger.debug(f"Number of nodes {N}.")
    #

    # handle given fixed labels
    assert fixed_labels is None or (
        len(fixed_labels) == N
    ), f"Type of labels must be None or a list of length N."
    fixed_labels = [] if fixed_labels is None else fixed_labels
    nodes_with_fixed_label: list[int] = [i for i, l in enumerate(fixed_labels) if l is not None]
    fixed_labelsmap: dict[Any, int] = {
        l: N + i for i, l in enumerate(set([l for l in fixed_labels if l is not None]))
    }
    logger.debug(
        f"Using {len(nodes_with_fixed_label)} nodes with fixed label and a total of {len(fixed_labelsmap)} different class labels."
    )

    # init node labels: each node gets its own label, unless its in the set of known labels
    node_labels: torch.Tensor = __init_node_labels__(
        N=N, fixed_labels=fixed_labels, fixed_labelsmap=fixed_labelsmap
    ).to(A.device)

    # prepare some helper variables for stats
    track_label_counts: bool = "dist" in label_by or "labelcounts" in out
    label_counts: torch.Tensor | None = None
    logger.debug(f"Keep track of label counts: {track_label_counts}")
    if track_label_counts:
        label_counts_tensor: torch.Tensor = torch.zeros(
            (N, N + len(fixed_labelsmap)), dtype=torch.int16
        ).to(
            label_counts_device
        )  # (#nodes x #labels) matrix
        label_counts_tensor[
            range(N), node_labels
        ] += 1  # set to one according to initialization
        label_counts = label_counts_tensor

    #
    keep_history: bool = "history" in out
    history: list[torch.Tensor] | None = [] if keep_history else None
    logger.debug(f"Keep history: {keep_history}")

    #
    logger.debug(f"Weighting: {weighting}")
    weight_func: typing.Callable[..., typing.Any] = __weighting_schemes__[weighting]

    #
    logger.debug(f"Label by: {label_by}")
    label_by_func: typing.Callable[..., typing.Any] = __label_by_schemes__[label_by]

    # pre-label nodes that have a unique direct neighbor with a fixed label (only if fixed labels are set)
    if len(fixed_labels):
        logger.debug("pre-labelling nodes with fixed labels")
        # for each node that doesn't have a fixed label, check if there is neighbor with a fixed label
        for vi in range(N):
            if fixed_labels[vi] is not None:
                continue
            vi_fixed_neighbors: torch.Tensor = (
                A[:, vi].bool() & (node_labels >= N)
            ).nonzero(as_tuple=False)[:, 0]  # incoming neighbors with a fixed label (node label < 0)
            if (
                vi_fixed_neighbors.size(0) < 1
            ):  # vi has no neighbors with a fixed label, so it won't change its label in this pre-labelling step
                continue
            # get the labels of the neighbors
            vi_fixed_neighbor_labels: torch.Tensor = node_labels[vi_fixed_neighbors]
            # get the weights of the neighbors based on the provided weighting function
            vi_fixed_neighbor_weights: torch.Tensor = weight_func(
                M=A, i=vi, node_ids=vi_fixed_neighbors
            )
            # compute a new label based on the label-by scheme
            vi_label_new, vi_label_ties, (labels_, scores_) = label_by_func(
                vi,
                vi_fixed_neighbors,
                vi_fixed_neighbor_weights,
                vi_fixed_neighbor_labels,
                label_counts,
                rand_generator,
            )
            # TODO: question, do not update the label if there are ties and let the the next rounds decide which label to assign??? -> test this
            # if len(vi_label_ties > 1):
            #   continue
            # update the label
            node_labels[vi] = vi_label_new
        # increase label count for nodes
        if label_counts is not None:
            label_counts[
                range(N), node_labels
            ] += 1  # increment by one according to the new labels

    # keep track of previously assigned node labels in order to compute convergence
    previous_node_labels: torch.Tensor = node_labels.clone().detach()

    # start the label propagation process
    it: int = 0
    for it in range(1, max_iter + 1):
        logger.debug(f"Starting iteration: {it}")
        # for each node in random order
        for vi in torch.randperm(N, generator=rand_generator).tolist():
            # update node label only if its not fixed
            if len(fixed_labels) and fixed_labels[vi] is not None:
                continue
            # safe the currently assigned class label
            previous_node_labels[vi] = node_labels[vi]
            # get the incoming neighbors
            vi_neighbors: torch.Tensor = __neighbors_in__(A, vi)
            if (
                vi_neighbors.size(0) < 1
            ):  # vi has no neighbors, so it won't change its label
                continue
            # get the labels of the neighbors
            vi_neighbor_labels: torch.Tensor = node_labels[vi_neighbors]
            # get the weights of the neighbors
            vi_neighbor_weights: torch.Tensor = weight_func(M=A, i=vi, node_ids=vi_neighbors)
            # compute the new propagated label
            vi_label_new, vi_label_new_ties, (labels_, scores_) = label_by_func(
                vi,
                vi_neighbors,
                vi_neighbor_weights,
                vi_neighbor_labels,
                label_counts,
                rand_generator,
            )
            # set the label
            node_labels[vi] = vi_label_new
        # increase label count for nodes
        if label_counts is not None:
            label_counts[
                range(N), node_labels
            ] += 1  # increment by one according to the new labels
        # keep track of the changes
        if keep_history and history is not None:
            history.append(node_labels.clone().detach().cpu())
        # check for changes
        n_changes: torch.Tensor = N - (node_labels == previous_node_labels).sum()
        logger.debug(f"{n_changes} node(s) changed their label.")
        if n_changes == 0:  # no changes: (node_labels == previous_node_labels).all()
            break

    # prepare output dictionary
    labels: dict[int, list[int]] = cl.labelvector_as_clusterlist(node_labels)
    res: dict[str, Any] = {"labels": labels}
    if "labelvector" in out:
        res["labelvector"] = node_labels
    if "previouslabelvector" in out:
        res["previouslabelvector"] = previous_node_labels
    if "A" in out:
        res["A"] = A
    else:
        del A
    if keep_history:
        res["history"] = history
    if "labelcounts" in out and label_counts is not None:
        res["labelcounts"] = label_counts
    if "fixed_labelsmap" in out:
        res["fixed_labelsmap"] = fixed_labelsmap
    logger.info(
        f"CW: found {node_labels.unique().size(0)} clusters, took {it} iterations."
    )
    return res


def cw(
    A: torch.Tensor,
    minweight: float | str = 1e-3,
    binarize: bool = True,
    max_iter: int = 100,
    label_by: str = "max_label",
    weighting: str = "top",
    fixed_labels: list[str | None] | None = None,
    out: list[str] | None = None,
    optimize_space: bool = False,
    label_counts_device: torch.device | str = "cpu",
    verbose: bool = False,
    quiet: bool = False,
    random_seed: int = 0,
) -> dict[str, Any]:
    if out is None:
        out = [
            "A",
            "labelvector",
            "previouslabelvector",
            "history",
            "labelcounts",
            "fixed_labelsmap",
        ]
    # preprocess
    __preprocess_graph__(
        A,
        remove_self_loops=True,
        minweight=minweight,
        binarize=binarize,
        optimize_space=optimize_space,
    )
    return _cw_no_preprocessing_(
        A,
        max_iter=max_iter,
        label_by=label_by,
        weighting=weighting,
        fixed_labels=fixed_labels,
        out=out,
        label_counts_device=label_counts_device,
        verbose=verbose,
        quiet=quiet,
        random_seed=random_seed,
    )
