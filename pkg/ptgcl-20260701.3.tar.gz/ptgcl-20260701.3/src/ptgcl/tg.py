#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: @remstef

"""

from typing import Any

import logging
import torch
import typing

from ptgcl import cw
from ptgcl.logging import setup_logger, set_log_verbosity


logger: logging.Logger = setup_logger(__name__)


class TG(object):
    """Telephone Game"""

    def __init__(
        self,
        maxiter: int = 1000,
        theta: int = 10,
        weighting: str = "top",
        random_seed: int = 0,
        verbose: bool = False,
        quiet: bool = False,
        **kwargs: Any,
    ) -> None:
        self.maxiter_: int = maxiter
        self.theta_: int = theta
        self.weighting_: str = weighting
        self.verbose_: bool = verbose
        self.quiet_: bool = quiet
        self.random_seed_: int = random_seed
        self.logger: logging.Logger = setup_logger(f"{self.__class__.__name__}({id(self)})")
        #
        set_log_verbosity(logger=self.logger, verbose=self.verbose_, quiet=self.quiet_)
        self.logger.debug(f"Weighting: {self.weighting_}")
        self.__weighting_as_func__: typing.Callable[..., typing.Any] = (
            cw.__weighting_schemes__[self.weighting_]
        )
        self.random_generator = torch.Generator()
        self.random_generator.manual_seed(self.random_seed_)

        # those objects will be needed during fitting
        self.labels_: torch.Tensor = torch.empty(0, dtype=torch.int)
        self.N_: int = -1
        self.A_: torch.Tensor = torch.empty(
            0, 0, dtype=torch.int
        )  # keep an internal reference to the adjacency matrix
        self.label_distribution_: torch.Tensor = torch.empty(0, 0, dtype=torch.int)
        self.active_: torch.Tensor = torch.empty(
            0, dtype=torch.int
        )  # track a node's activity status
        self.previous_labels_: torch.Tensor = torch.empty(
            0, dtype=torch.int
        )  # keep track of previously assigned node label; init with -1; quick access to last history item
        self.histscore_node_class_: torch.Tensor = torch.empty(
            0, 0, dtype=torch.int
        )  # (#nodes x #labels) matrix # save aggregated history counts for oscilating nodes and labels
        self.changes_: tuple[int, int, tuple[int, float], tuple[int, float]] = (
            -1,
            -1,
            (-1, -1),
            (-1, -1),
        )  # keep track of structered label assignments for a particular iteration (iteration, vi, (vi_current_class, vi_current_class_score), (vi_new_class, vi_new_class_score))
        self.logs_: list[str] = []  # keep track of unstructered log events
        self.iter_ = 0
        self.halt_: bool = False
        self.nexthalt_: int | str = 1

    def __pre_loop_break_condition__(self) -> bool:
        return False

    def __post_loop_break_condition__(self) -> bool:
        return False

    def fit(
        self, A: torch.Tensor, *args: Any, resumetraining: bool = False, **kwargs: Any
    ) -> typing.Self:
        """Compute clusters from a data or similarity matrix and predict labels.

        Parameters
        ----------
        A : {tensor-like} of shape (n_samples, n_samples)
            Training instances to in form of an adjacency matrix.

        Returns
        -------
        self
        """
        self.on_begin_fit("begin_fit")
        if self.A_.numel() and not resumetraining:
            raise UserWarning(
                "Data has already been fitted with TG. Please provide `resumetraining=True` if you want ot continue training."
            )

        if not resumetraining:
            self.logger.debug(f"Start training...")
            self.A_ = A
            self.N_ = self.A_.shape[0]
            self.logger.debug(f"Number of nodes {self.N_}.")
            # init node labels: each node gets its own label, unless its in the set of known labels
            self.labels_ = torch.arange(self.N_, dtype=torch.int).to(A.device)
            # keep track of previously assigned node label; init with -1; quick access to last history item
            self.previous_labels_ = torch.arange(self.N_).to(A.device)
            # label distribution (#nodes x #labels) matrix, save aggregated node to label assignment counts (history)
            self.label_distribution_ = torch.eye(self.N_, dtype=torch.int)
            # (#nodes x #labels) matrix # save aggregated history counts for each node and label, history counts are only increased if history condition fires
            self.histscore_node_class_ = torch.zeros(
                (self.N_, self.N_), dtype=torch.int
            )
        else:
            self.logger.debug(f"Resume training...")
        #
        self.active_ = torch.ones(self.N_, dtype=torch.bool).to(
            A.device
        )  # save a node's activity status
        self.on_initialization_finished(
            "initialization_finished", node_labels=self.labels_.tolist()
        )

        # start the label propagation process
        while self.active_.any() and self.iter_ < self.maxiter_:
            if self.__pre_loop_break_condition__():
                break
            self.iter_ += 1
            self.logger.debug(
                f"Starting iteration: {self.iter_}. Active nodes: {self.active_.sum()}"
            )
            self.on_begin_iteration("begin_iteration", iter=self.iter_)

            active_node_ids: torch.Tensor = self.active_.nonzero(as_tuple=False)[:, 0]
            active_at_iteration_begin: list[int] = active_node_ids[
                torch.randperm(active_node_ids.size(0), generator=self.random_generator)
            ].tolist()
            # for each node in random order, consider only nodes that have been active at the beginning of the iteration
            for vi in active_at_iteration_begin:
                if self.__pre_loop_break_condition__():
                    break
                if not self.active_[vi]:  # skip node if not active
                    continue
                # receive update for vi
                self.__update_vi__(vi)

            # check for changes
            n_changes: torch.Tensor = self.N_ - (self.labels_ == self.previous_labels_).sum()
            self.logger.debug(
                f"{n_changes} node(s) changed their label. {self.active_.sum()} node(s) active."
            )
            self.label_distribution_[
                range(self.N_), self.labels_
            ] += 1  # increase counter for label distribution
            self.on_end_iteration("end_iteration", iter=self.iter_)
            if self.__post_loop_break_condition__():
                break

        info_message: str = f"TG: found {self.labels_.unique().size(0)} clusters, took {self.iter_} iterations."
        self.logger.info(info_message)
        debug_message: str = f"Clusters: {self.labelcounts().tolist()}"
        self.logger.debug(debug_message)
        self.on_end_fit("end_fit", info=info_message, extrainfo=debug_message)
        self.logger.debug(f"Finished training.")
        return self

    def fit_predict(self, A: torch.Tensor, *args: Any, **kwargs: Any) -> list[int]:
        """Compute clusters from a data or similarity matrix and predict labels.

        Parameters
        ----------
        A : {tensor-like} of shape (n_samples, n_samples)
            Training instances to in form of an adjacency matrix.

        Returns
        -------
        labels : {tensor-like} list of class labels (n_samples,)
            Cluster labels. Noisy samples are given the label -1.
        """
        self.fit(A, *args, **kwargs)
        return self.labels_.tolist()

    def labelcounts(self) -> torch.Tensor:
        """
        Returns
        -------
        labels : {tensor-like} list of unique class labels (n_classes,)
            Cluster labels.
        labelcounts : {tensor-like} list of class labels assignments (n_classes,)
        """
        label_dist: torch.Tensor = torch.zeros_like(self.labels_)
        labelids: torch.Tensor
        labelcounts: torch.Tensor
        labelids, labelcounts = self.labels_.unique(
            return_inverse=False, return_counts=True
        )
        label_dist[labelids] += labelcounts
        return label_dist

    # define helper function
    def __update_vi__(self, vi: int) -> int:
        """Perform the TG update for vi"""
        self.on_begin_update_vi("begin_update_vi", iter=self.iter_, vi=vi)
        # get the incoming neighbors
        vi_neighbors: torch.Tensor = cw.__neighbors_in__(self.A_, vi)
        # get some shortcuts: current class
        vi_cur_class: int = int(self.labels_[vi].item())  # .detach().clone()
        if (
            vi_neighbors.size(0) < 1
        ):  # vi has no neighbors, so it won't change its label
            # we still need to deactivate this node and set the previous label to the current one
            self.active_[vi] = False
            self.previous_labels_[vi] = vi_cur_class
            # call some callbacks
            self.on_deactivate_vi(
                "deactivate_vi",
                iter=self.iter_,
                vi=vi,
                vi_class=vi_cur_class,
                reason="Node has no neighbors.",
            )
            self.on_end_update_vi(
                "end_update_vi",
                iter=self.iter_,
                vi=vi,
                vi_class=vi_cur_class,
                vi_changed_class=False,
                vi_change_reason="Node has no neighbors.",
                vi_neighbors=vi_neighbors.tolist(),
            )
            return vi_cur_class

        # get some more shortcuts:
        # get the weights of the neighbors
        vi_neighbor_weights: torch.Tensor = self.__weighting_as_func__(
            M=self.A_, i=vi, node_ids=vi_neighbors
        )
        # get the labels of the neighbors
        vi_neighbor_labels: torch.Tensor = self.labels_[vi_neighbors]

        (
            vi_neighbor_unique_class_labels,
            vi_neighbor_unique_class_label_scores,
            vi_neighbor_unique_class_label_counts,
            vi_neighbor_to_unique_class_label_index,
        ) = self.__get_class_scores__(
            vi_neighbors, vi_neighbor_weights, vi_neighbor_labels
        )

        # prevclass == curclass
        vi_cur_class_index: torch.Tensor = (vi_neighbor_unique_class_labels == vi_cur_class).nonzero(
            as_tuple=False
        )
        vi_cur_class_score: torch.Tensor = torch.tensor(-float("Inf"))
        vi_cur_class_in_neighborhood: bool = vi_cur_class_index.size(0) > 0
        if vi_cur_class_in_neighborhood:  # previous class was found in the neighborhood
            vi_cur_class_index = vi_cur_class_index.squeeze()
            if vi_neighbor_unique_class_labels.size(0) <= 1:
                # current class is the only class in the neighborhood, vi won't update its label and will be set to inactive
                self.active_[vi] = False
                self.previous_labels_[vi] = vi_cur_class
                self.on_deactivate_vi(
                    "deactivate_vi",
                    iter=self.iter_,
                    vi=vi,
                    vi_class=vi_cur_class,
                    reason="Node has only current class in neighborhood.",
                )
                self.on_end_update_vi(
                    "end_update_vi",
                    iter=self.iter_,
                    vi=vi,
                    vi_class=vi_cur_class,
                    vi_changed_class=False,
                    vi_change_reason="Node has only current class in neighborhood.",
                    vi_neighbors=vi_neighbors.tolist(),
                )
                return vi_cur_class
            vi_cur_class_score = (
                vi_neighbor_unique_class_label_scores[vi_cur_class_index]
                .detach()
                .clone()
            )
            vi_neighbor_unique_class_label_scores[vi_cur_class_index] = -float(
                "Inf"
            )  # set value to the lowest possible

        # get the maximum score labels and resolve ties
        vi_new_class_index: torch.Tensor
        vi_new_class_score: torch.Tensor
        vi_new_class_index, vi_new_class_score = (
            self.__get_random_choice_index_of_top_scores__(
                vi_neighbor_unique_class_label_scores
            )
        )
        vi_new_class: int = int(
            vi_neighbor_unique_class_labels[vi_new_class_index].item()
        )  # .detach().clone() # new class cannot be current class
        assert (
            vi_new_class != vi_cur_class
        ), f"{vi_new_class}, {vi_new_class_score}, {vi_neighbor_unique_class_labels}, {vi_neighbor_unique_class_label_scores}"

        vi_changed_class: bool = False
        vi_change_reason: str = ""
        self.previous_labels_[vi] = (
            vi_cur_class  # already set the previous label to the current class regardless of what happens next
        )
        if vi_new_class_score > vi_cur_class_score:
            self.previous_labels_[vi] = vi_cur_class
            self.labels_[vi] = vi_new_class
            vi_changed_class = True
            vi_change_reason = f"New class score is larger than current class score: v{vi}.score(c{vi_new_class})={vi_new_class_score} > v{vi}.score(c{vi_cur_class})={vi_cur_class_score} (class in neigh:{vi_cur_class_in_neighborhood})"
            # push changes and additional information to the callback function
            self.on_change_vi_label(
                "change_vi_label_default",
                iter=self.iter_,
                vi=vi,
                vi_new_class=vi_new_class,
                vi_old_class=vi_cur_class,
                vi_new_class_score=vi_new_class_score.item(),
                vi_old_class_score=vi_cur_class_score,
                vi_neighbor_unique_class_labels=vi_neighbor_unique_class_labels.tolist(),
                vi_neighbor_unique_class_label_scores=vi_neighbor_unique_class_label_scores.tolist(),
                vi_neighbors=vi_neighbors.tolist(),
                vi_neighbor_weights=vi_neighbor_weights.tolist(),
                vi_neighbor_labels=vi_neighbor_labels.tolist(),
            )
        elif vi_new_class_score < vi_cur_class_score:
            # do not update vi, current class label has higher score
            vi_changed_class = False
            vi_change_reason = f"New class score is smaller than current class score: v{vi}.score(c{vi_new_class})={vi_new_class_score} < v{vi}.score(c{vi_cur_class})={vi_cur_class_score}"
        else:  # in case of ties consider the history of the labels for the current node
            history_condition1: bool = bool(
                (
                    self.histscore_node_class_[vi, vi_cur_class]
                    < self.histscore_node_class_[vi, vi_new_class]
                ).item()
            )
            history_condition2: bool = bool(
                (self.histscore_node_class_[vi, vi_cur_class] < self.theta_).item()
            )
            if history_condition1 or history_condition2:
                self.previous_labels_[vi] = vi_cur_class
                self.labels_[vi] = vi_new_class
                self.on_change_vi_label(
                    "change_vi_label_history",
                    iter=self.iter_,
                    vi=vi,
                    vi_new_class=vi_new_class,
                    vi_old_class=vi_cur_class,
                    vi_new_class_score=vi_new_class_score.item(),
                    vi_old_class_score=vi_cur_class_score.item(),
                    vi_neighbor_unique_class_labels=vi_neighbor_unique_class_labels.tolist(),
                    vi_neighbor_unique_class_label_scores=vi_neighbor_unique_class_label_scores.tolist(),
                    vi_neighbors=vi_neighbors.tolist(),
                    vi_neighbor_weights=vi_neighbor_weights.tolist(),
                    vi_neighbor_labels=vi_neighbor_labels.tolist(),
                    vi_new_class_histscore=self.histscore_node_class_[
                        vi, vi_new_class
                    ].item(),
                    vi_old_class_histscore=self.histscore_node_class_[
                        vi, vi_cur_class
                    ].item(),
                )
                self.histscore_node_class_[vi, vi_new_class] += 1
                vi_changed_class = True
                vi_change_reason = f"New class is determined by history condition "
                if history_condition1:
                    vi_change_reason += f"1: v{vi}.hist(c{vi_cur_class})={self.histscore_node_class_[vi, vi_cur_class]} < v{vi}.hist(c{vi_new_class})={self.histscore_node_class_[vi, vi_new_class]}."
                elif history_condition2:
                    vi_change_reason += f"2: v{vi}.hist(c{vi_cur_class})={self.histscore_node_class_[vi, vi_cur_class]} < theta={self.theta_}."

        # update activity status
        if vi_changed_class:
            self.active_[vi] = True
            self.active_[vi_neighbors] = (
                True  # TODO: activate outgoing neighbors!!!! currently its the incoming neighbors
            )
            self.on_activate_vi(
                "activate_vi",
                iter=self.iter_,
                vi=vi,
                vi_neighbors=vi_neighbors,
                vi_neighbor_labels=vi_neighbor_labels,
                vi_neighbor_unique_class_labels=vi_neighbor_unique_class_labels,
                vi_neighbor_unique_class_label_scores=vi_neighbor_unique_class_label_scores,
            )
        else:
            self.active_[vi] = False
            self.on_deactivate_vi(
                "deactivate_vi",
                iter=self.iter_,
                vi=vi,
                reason="Node did not change class because its the highest scored class in neighborhood.",
            )
        self.on_end_update_vi(
            "end_update_vi",
            iter=self.iter_,
            vi=vi,
            vi_class=vi_new_class if vi_changed_class else vi_cur_class,
            vi_changed_class=vi_changed_class,
            vi_change_reason=vi_change_reason,
            vi_neighbors=vi_neighbors.tolist(),
        )

        return int(self.labels_[vi].item())
        # # reset
        # vi_neighbor_unique_class_label_scores[vi_cur_class_index] = vi_cur_class_score # reset value of current class' score in the score list before returning
        # return (vi_new_class, vi_new_class_score), (vi_neighbors, vi_neighbor_weights, vi_neighbor_labels), (vi_neighbor_unique_class_labels, vi_neighbor_unique_class_label_scores)

    def __get_class_scores__(
        self,
        vi_neighbors: torch.Tensor,
        vi_neighbor_weights: torch.Tensor,
        vi_neighbor_labels: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        # compute the label scores by aggregating weights
        (
            vi_neighbor_unique_class_labels,
            vi_neighbor_to_unique_class_label_index,
            vi_neighbor_unique_class_label_counts,
        ) = vi_neighbor_labels.unique(return_inverse=True, return_counts=True)
        # prepare a local neighbor-to-label weight matrix
        W: torch.Tensor = torch.zeros(
            vi_neighbors.size(0), vi_neighbor_unique_class_labels.size(0)
        ).to(
            vi_neighbors.device
        )  # create matrix
        W[range(W.size(0)), vi_neighbor_to_unique_class_label_index] = (
            vi_neighbor_weights  # set values
        )
        vi_neighbor_unique_class_label_scores: torch.Tensor = W.sum(
            dim=0
        )  # aggregate class label scores over neighor weights
        return (
            vi_neighbor_unique_class_labels,
            vi_neighbor_unique_class_label_scores,
            vi_neighbor_unique_class_label_counts,
            vi_neighbor_to_unique_class_label_index,
        )

    def __get_random_choice_index_of_top_scores__(
        self,
        scores: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # get the maximum value
        top_score: torch.Tensor = scores.max()
        # check the other options with the top score
        top_score_options: torch.Tensor = (scores == top_score).nonzero(as_tuple=False)[:, 0]
        # get a single random label of the max options
        random_top_score_index: torch.Tensor = top_score_options[
            torch.randint(len(top_score_options), (1,), generator=self.random_generator)
        ]  # random.choice(top_score_options)
        return random_top_score_index, top_score

    # define callback functions
    def on_begin_fit(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_end_fit(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_initialization_finished(
        self, emittermsg: str, *args, **kwargs
    ) -> typing.Any:
        pass

    def on_begin_iteration(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_end_iteration(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_begin_update_vi(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_end_update_vi(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_change_vi_label(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_deactivate_vi(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass

    def on_activate_vi(self, emittermsg: str, *args, **kwargs) -> typing.Any:
        pass
