from .serve import main
import fire

fire.Fire(main, name="serve")
