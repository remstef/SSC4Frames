#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: rem

"""

import os, sys, time
import typing
import threading
import asyncio
import copy
import logging
from typing import Any

import torch
from .. import cl, tg, cw

torch.set_printoptions(profile="full")

# set up logging
import logging

logger: logging.Logger = logging.getLogger(__name__.split(".")[-1])
logger.setLevel(logging.INFO)
consolehandler = logging.StreamHandler()
consolehandler.setLevel(logging.DEBUG)
consolehandler.setFormatter(
    logging.Formatter("T%(thread)d %(asctime)s:%(name)s:%(levelname)s: %(message)s")
)
logger.addHandler(consolehandler)


class TGObserver(object):
    """Observe status of TG implementations"""

    available_networks: dict[str, Any] = {}

    @classmethod
    def get_available_networks(cls) -> typing.KeysView[str]:
        return cls.available_networks.keys()

    @classmethod
    def add_to_available_networks(cls, filename: str, full_filename: str) -> None:
        cls.available_networks[filename] = full_filename
        return

    @classmethod
    def remove_from_available_networks(cls, filename: str) -> None:
        del cls.available_networks[filename]
        return

    @classmethod
    def load_net(
        cls, filename: str
    ) -> tuple[torch.Tensor, dict[str, int], dict[int, str], dict[str, Any]]:
        if not filename in cls.available_networks or isinstance(
            cls.available_networks[filename], str
        ):
            full_filename: str = cls.available_networks[filename]
            try:
                A: torch.Tensor
                nodeName2Id: dict[str, int]
                nodeId2Name: dict[int, str]
                A, nodeName2Id, nodeId2Name = cl.read_graph_from_file(
                    filename=full_filename
                )
            except Exception as e:
                logger.error(f"Error reading file {full_filename}: {e}")
                raise ValueError(f"'Error reading file '{full_filename}'.") from e
            try:
                net: dict[str, Any] = cl.get_net_as_dict(A, nodeId2Name)
            except Exception as e:
                logger.error(
                    f"Error creating network representation from file {full_filename}: {e}"
                )
                raise ValueError(
                    f"'Error creating network representation from file '{full_filename}'."
                ) from e
            cls.available_networks[filename] = (A, nodeName2Id, nodeId2Name, net)
        return typing.cast(
            tuple[torch.Tensor, dict[str, int], dict[int, str], dict[str, Any]],
            copy.deepcopy(cls.available_networks[filename]),
        )

    def __init__(self, resize_nodes: bool = False) -> None:
        self.listeners_: set[typing.Any] = set()
        self.require_update_: set[typing.Any] = set()
        self.vi_update_list_: list[int] = []
        self.resize_nodes_: bool = resize_nodes
        return

    def attach(self, listener: typing.Any) -> None:
        return self.listeners_.add(listener)

    def detach(self, listener: typing.Any) -> None:
        return self.listeners_.remove(listener)

    def log_message(self, message: Any) -> None:
        message_str: str = str(message)
        logger.info(message_str)
        l: Any
        for l in self.listeners_:
            l.notify(cmd="serverlog", data={"message": message_str})
            time.sleep(0.001)
        return

    def load_net_and_clusterer(self, filename: str, **kwargs: Any) -> None:
        """ """
        # TODO: make graph prepocessing options available, such as pruning and directed to undirected graph conversion, etc.
        try:
            self.A_, self.nodeName2Id_, self.nodeId2Name_, self.net_ = (
                TGObserver.load_net(filename=filename)
            )
        except Exception as e:
            self.log_message(f"Error loading network {filename}: {e}")
            raise ValueError(f"Error loading network {filename}.") from e
        self._name = filename
        # init clustering algorithm

        if "remove_self_loops" in kwargs or "binarize" in kwargs:
            self.A_ = cw.__preprocess_graph__(self.A_, **kwargs)
            self.net_ = cl.get_net_as_dict(self.A_, self.nodeId2Name_)

        self.clusterer_ = tg.TG(verbose=True, quiet=False, **kwargs)
        self.clusterer_.halt_ = False
        self.clusterer_.nexthalt_ = 1

        # define callback functions
        def check_getupdate() -> None:
            if len(self.require_update_):
                data: dict[str, Any] = {
                    "name": self._name,
                    "net": self.net_,
                    "iteration": self.clusterer_.iter_,
                    "labels": (
                        self.clusterer_.labels_.tolist()
                        if self.clusterer_.labels_ is not None
                        else []
                    ),
                    "active": (
                        self.clusterer_.active_.tolist()
                        if self.clusterer_.active_ is not None
                        else []
                    ),
                }
                l: Any
                while len(self.require_update_):  # push to the clients
                    self.require_update_.pop().notify(cmd="getstate", data=data)
                    time.sleep(0.001)

        def pause_computation_and_wait(
            emittermsg: str, iter: int = 0, *args: Any, **kwargs: Any
        ) -> None:
            if self.clusterer_.nexthalt_ == "break":
                return
            if self.clusterer_.nexthalt_ == "iter":
                # stop on iteration end
                self.clusterer_.halt_ = emittermsg in [
                    "end_iteration",
                    "initialization_finished",
                ]
            elif self.clusterer_.nexthalt_ == "end":
                # don't stop, just write logs and update the vis network nodes on emittermsg 'end_iteration'
                pass
            elif self.clusterer_.nexthalt_ == 1:
                # stop b/c next step
                self.clusterer_.halt_ = True
            else:
                return

            if emittermsg == "end_iteration":
                n_changes: float = (
                    self.clusterer_.N_
                    - (self.clusterer_.labels_ == self.clusterer_.previous_labels_)
                    .sum()
                    .item()
                )
                n_active: float = self.clusterer_.active_.sum().item()
                self.log_message(
                    f"{emittermsg} | iter: {iter} | #changes: {n_changes} | #active: {n_active} | {args} | {kwargs}"
                )
            else:
                self.log_message(f"{emittermsg} | iter: {iter} | {args} | {kwargs}")
            # push updates to the listeners once an iteration has finished
            if iter > 0 and emittermsg == "end_iteration":
                for l in self.listeners_:
                    l.notify(
                        cmd="updatenodes",
                        data={
                            "iteration": self.clusterer_.iter_,
                            "vi": self.vi_update_list_,
                            "nodes": self.net_["nodes"],
                        },
                    )
                    time.sleep(0.001)
                self.vi_update_list_.clear()
            # lock
            while self.clusterer_.halt_ and (
                self.clusterer_.nexthalt_ == "iter" or self.clusterer_.nexthalt_ == 1
            ):
                check_getupdate()
                time.sleep(0.15)
            return

        def init_network_on_initialization(
            emittermsg: str, node_labels: list[int] | torch.Tensor, *args: Any, **kwargs: Any
        ) -> None:
            # update net representation
            vi: int
            ci: Any
            for vi, ci in enumerate(node_labels):
                self.net_["nodes"][vi]["active"] = (
                    "active" if self.clusterer_.active_[vi].item() else "inactive"
                )
                self.net_["nodes"][vi]["group"] = ci
                self.net_["nodes"][vi][
                    "label"
                ] = f"""{self.net_['nodes'][vi]['name']}|v{vi}|c{self.net_['nodes'][vi]['group']}|{self.net_['nodes'][vi]['active']}"""
                self.net_["nodes"][vi]["title"] += (
                    "\n"
                    + f"""  (i{self.clusterer_.iter_})|-> c{self.net_['nodes'][vi]['group']}"""
                )
                self.net_["nodes"][vi]["size"] = self.net_["nodes"][vi].get("size", 10)
            # push update to the listeners
            l: Any
            for l in self.listeners_:
                l.notify(
                    cmd="initlabels",
                    data={
                        "iteration": self.clusterer_.iter_,
                        "nodes": self.net_["nodes"],
                    },
                )
                time.sleep(0.001)
            return

        def update_network(
            emittermsg: str,
            vi: int,
            vi_class: int,
            vi_changed_class: bool,
            vi_change_reason: str,
            vi_neighbors: typing.Any,
            **kwargs: Any,
        ) -> None:
            vi_previous_class: Any = self.net_["nodes"][vi]["group"]
            self.log_message(
                f"""Update: {emittermsg} | v{vi}: c{vi_previous_class} => c{vi_class} ({'changed' if vi_changed_class else 'nochange'}) | {vi_change_reason}"""
            )
            if vi_changed_class:
                self.net_["nodes"][vi]["group"] = vi_class
                self.net_["nodes"][vi]["title"] += (
                    "\n"
                    + f"""  (i{self.clusterer_.iter_})|-> c{self.net_['nodes'][vi]['group']}"""
                )
                if self.resize_nodes_:
                    self.net_["nodes"][vi]["size"] += 10
            vj: int
            for vj in range(self.clusterer_.active_.size(0)):
                self.net_["nodes"][vj]["active"] = (
                    "active" if self.clusterer_.active_[vj].item() else "inactive"
                )
                self.net_["nodes"][vj][
                    "label"
                ] = f"""{self.net_['nodes'][vj]['name']}|v{vj}|c{self.net_['nodes'][vj]['group']}|{self.net_['nodes'][vj]['active']}"""
            # send update to the listeners if it is necessary here, otherwise at iteration end
            if self.clusterer_.nexthalt_ == 1:
                l: Any
                for l in self.listeners_:
                    l.notify(
                        cmd="updatenodes",
                        data={
                            "iteration": self.clusterer_.iter_,
                            "vi": vi,
                            "nodes": self.net_["nodes"],
                        },
                    )
                    time.sleep(0.001)
            else:
                self.vi_update_list_.append(vi)
            return

        def just_listen_and_notify(
            emittermsg: str, *args: Any, **kwargs: Any
        ) -> None:
            self.log_message(f"Info: {emittermsg} | {args} | {kwargs}")

        def init_and_pause(*args: Any, **kwargs: Any) -> None:
            init_network_on_initialization(*args, **kwargs)
            pause_computation_and_wait(*args, **kwargs)

        def update_and_pause(*args: Any, **kwargs: Any) -> None:
            update_network(*args, **kwargs)
            pause_computation_and_wait(*args, **kwargs)

        # set callbacks
        self.clusterer_.on_begin_fit = pause_computation_and_wait  # type: ignore[method-assign]
        self.clusterer_.on_initialization_finished = init_and_pause  # type: ignore[method-assign]
        self.clusterer_.on_end_iteration = pause_computation_and_wait  # type: ignore[method-assign]
        self.clusterer_.on_end_update_vi = update_and_pause  # type: ignore[method-assign]
        self.clusterer_.on_begin_update_vi = pause_computation_and_wait  # type: ignore[method-assign]
        self.clusterer_.on_change_vi_label = pause_computation_and_wait  # type: ignore[method-assign]
        self.clusterer_.on_end_fit = just_listen_and_notify  # type: ignore[method-assign]
        self.clusterer_.__pre_loop_break_condition__ = lambda: self.clusterer_.nexthalt_ == "break"  # type: ignore[method-assign]
        self.clusterer_.__post_loop_break_condition__ = lambda: self.clusterer_.nexthalt_ == "break"  # type: ignore[method-assign]

        self.start_thread()
        return

    def run(self) -> None:
        self.__runner_thread__.start()

    def continue_execution(self, step: int | str = 1, **kwargs: Any) -> None:
        self.clusterer_.halt_ = False
        self.clusterer_.nexthalt_ = step
        return

    def start_thread(self) -> None:
        # run clustering process in a thread
        def run_clustering(
            A: torch.Tensor,
            clusterer: tg.TG,
            asyncioeventloop: asyncio.AbstractEventLoop,
        ) -> tg.TG:
            asyncio.set_event_loop(asyncioeventloop)
            clusterer.fit(A)
            return clusterer

        self.__runner_thread__ = threading.Thread(
            target=run_clustering,
            args=(self.A_, self.clusterer_, asyncio.get_event_loop()),
            daemon=True,
        )

    def restart(self, **kwargs: Any) -> None:
        self.stop_and_join_thread()
        # reset clusterer's internal variables
        self.clusterer_.halt_ = False
        self.clusterer_.nexthalt_ = 1
        self.clusterer_.iter_ = 0
        self.clusterer_.A_ = torch.empty(0, 0, dtype=torch.int)
        # reset aligned visualization nodes
        vi: int
        node: dict[str, Any]
        for vi, node in enumerate(self.net_["nodes"]):
            node["active"] = "inactive"
            node["group"] = -1
            node["label"] = (
                f"""{node['name']}|v{vi}|c{node['group']}|{node['active']}"""
            )
            node["title"] = node["label"]
            node["size"] = 10
        self.start_thread()
        self.run()
        l: Any
        for l in self.listeners_:
            self.get_current_state(l)
        return

    def get_current_state(self, listener: typing.Any) -> None:
        self.require_update_.add(
            listener
        )  # will be seen by check_getupdate() callback and removed after sending update to listeners
        if not self.__runner_thread__.is_alive():
            data: dict[str, Any] = {
                "name": self._name,
                "net": self.net_,
                "iteration": self.clusterer_.iter_,
                "labels": (
                    self.clusterer_.labels_.tolist()
                    if self.clusterer_.labels_ is not None
                    else []
                ),
                "active": (
                    self.clusterer_.active_.tolist()
                    if self.clusterer_.active_ is not None
                    else []
                ),
            }
            while len(self.require_update_):  # push to the clients
                self.require_update_.pop().notify(cmd="getstate", data=data)
        return

    # TODO
    def get_label_distribution(self, listener: typing.Any) -> None:
        # 'assigmentdistribution': self.clusterer_.label_distribution_.sum(dim=0).tolist(),
        # 'labeldistribution': self.clusterer_.labelcounts().tolist(),
        # self.clusterer_.label_distribution_
        return

    def get_info(
        self, listener: typing.Any, node_vi: int, node_vi_edges: list[int]
    ) -> None:

        def gather_info(vi: int, edges: list[int]) -> dict[str, Any]:
            # compare the server side generated neighbors vs client side generated neighbors and make sure they are the same
            vi_neighbors_in_client: set[int] = {
                self.net_["edges"][e]["srcid"]
                for e in edges
                if self.net_["edges"][e]["dstid"] == vi
            }
            if self.net_["meta"]["type"] == "undirected":
                vi_neighbors_in_client |= {
                    self.net_["edges"][e]["dstid"]
                    for e in edges
                    if self.net_["edges"][e]["srcid"] == vi
                }
            vi_neighbors: torch.Tensor = cw.__neighbors_in__(self.A_, vi)
            vi_neighbors_in_server: set[int] = set(vi_neighbors.tolist())
            assert len(vi_neighbors_in_client) == len(vi_neighbors_in_server) and len(
                vi_neighbors_in_client & vi_neighbors_in_server
            ) == len(
                vi_neighbors_in_client
            ), f"Neighbors (client and server) should be same, but are [server]:{vi_neighbors_in_server}; [client]:{vi_neighbors_in_client}"

            vi_neighbor_weights: torch.Tensor = self.clusterer_.__weighting_as_func__(
                M=self.A_, i=vi, node_ids=vi_neighbors
            )
            vi_neighbor_labels: torch.Tensor = self.clusterer_.labels_[vi_neighbors]
            (
                vi_neighbor_unique_class_labels,
                vi_neighbor_unique_class_label_scores,
                vi_neighbor_unique_class_label_counts,
                vi_neighbor_to_unique_class_label_index,
            ) = self.clusterer_.__get_class_scores__(
                vi_neighbors, vi_neighbor_weights, vi_neighbor_labels
            )

            neighbors_dict: dict[str, dict[str, Any]] = {
                f"v{vj}": {
                    "nodeid": vj,
                    "edgeweight": self.A_[vj, vi].item(),
                    "weight": vi_neighbor_weights[j].item(),
                    "classid": self.clusterer_.labels_[vj].item(),
                    "class": f"c{self.clusterer_.labels_[vj].item()}",
                }
                for j, vj in enumerate(vi_neighbors_in_server)
            }

            classes_dict: dict[int, dict[str, Any]] = {
                int(cj.item()): {  # vi_neighbor_unique_class_labels[j].item()
                    "score": vi_neighbor_unique_class_label_scores[j].item(),
                    "name": self.nodeId2Name_[int(cj.item())],
                    "histscore": self.clusterer_.histscore_node_class_[vi, cj].item(),
                    "neighborcount": vi_neighbor_unique_class_label_counts[j].item(),
                }
                for j, cj in enumerate(vi_neighbor_unique_class_labels)
            }

            # collect all possible information necessary to perform a label update
            datadict: dict[str, Any] = {
                "vi": f"v{vi}",
                "nodeid": vi,
                "name": self.nodeId2Name_[vi],
                "active": (
                    self.clusterer_.active_[vi].item()
                    if self.clusterer_.active_ is not None
                    else "not_yet_initialized"
                ),
                "classid": self.clusterer_.labels_[vi].item(),
                "class": f"c{self.clusterer_.labels_[vi].item()}",
                "previousclass": f"c{self.clusterer_.previous_labels_[vi].item()}",
                "historyscoresvi": self.clusterer_.histscore_node_class_[vi].tolist(),
                "labeldistributionvi": self.clusterer_.label_distribution_[vi].tolist(),
                "neighbors": neighbors_dict,
                "classes": classes_dict,
                "general": {
                    "name": self._name,
                    "weighting": self.clusterer_.weighting_,
                    "theta": self.clusterer_.theta_,
                    "assigmentdistribution": self.clusterer_.label_distribution_.sum(
                        dim=0
                    ).tolist(),
                    "labeldistribution": self.clusterer_.labelcounts().tolist(),
                },
            }
            return datadict

        datadict: dict[str, Any] = gather_info(node_vi, node_vi_edges)
        listener.notify(cmd="nodeinfo", data=datadict)
        return

    def stop_and_join_thread(self) -> None:
        self.clusterer_.halt_ = False
        self.clusterer_.nexthalt_ = "break"
        self.__runner_thread__.join()
        return
