#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 20:24:45 2020

@author: rem

"""

from typing import Any, Callable
import torch
from ptgcl import cl


def interpret_approx(M: torch.Tensor) -> torch.Tensor:
    # interpret cluster results
    labels = M.argmax(dim=0)
    return labels


def interpret(M: torch.Tensor) -> torch.Tensor:
    # interpret cluster results
    # attractors = (M.sum(dim=1) > 0).nonzero()
    # check for identity of column vectors
    attracted: list[str] = [
        ":".join([str(j.item()) for j in M[:, i].nonzero(as_tuple=False)])
        for i in range(M.size(1))
    ]
    attractedids: dict[str, int] = {}
    for a in attracted:
        if not a in attractedids:
            attractedids[a] = len(attractedids)
    labels = torch.tensor([attractedids[a] for a in attracted])
    return labels


def mpow(M: torch.Tensor, exponent: int = 2) -> torch.Tensor:
    if exponent < 2:
        return M
    if exponent == 2:
        return M.matmul(M)
    return M.matmul(mpow(M, exponent - 1))


def mcl(
    A: torch.Tensor,
    e: int = 2,
    r: int = 2,
    ithresh: float = 1e-5,
    max_iter: int = 100,
    eps: float = 1e-12,
    allowsingletons: bool = False,
    binarize: bool = False,
    out: list[str] | None = None,
    interpretfun: Callable[[torch.Tensor], torch.Tensor] = interpret,
    use_simple_convergence_criterium: bool = False,
    optimize_space: bool = False,
) -> dict[str, Any]:
    if out is None:
        out = ["A", "labelvector"]

    convergence: Callable[[torch.Tensor, torch.Tensor], torch.Tensor | bool] = (
        (lambda A, newA: (A.pow(2).sum().sqrt() - newA.pow(2).sum().sqrt()).item() < eps)
        if use_simple_convergence_criterium
        else 
        (lambda A, newA: ((A - newA).pow(2)).sum().sqrt().item() < eps)
    )

    # number of nodes
    N: int = A.size(0)

    # make sure the graph contains only ones and zeros
    if binarize:
        if optimize_space:
            A = cl.set_newval_where(
                A, condition=lambda v: v > 0, newval=1, step=None, appendnewval=True
            )  # A[A>0] = 1
            A = cl.set_newval_where(
                A, condition=lambda v: v < 0, newval=0, step=None, appendnewval=True
            )  # A[A<0] = 0
        else:
            A[A > 0] = 1
            A[A < 0] = 0

    # make sure self-loops are included
    A[(range(N), range(N))] = 1

    # normalize by column
    margins: torch.Tensor = A.sum(dim=0)
    A.div_(margins.expand(A.size()))  # faster inplace
    # A = A / margins.expand(A.size()) # slower

    # prune by threshold
    if optimize_space:
        A = cl.set_newval_where(
            A, condition=lambda v: v < ithresh, newval=0, step=None, appendnewval=False
        )  # A[A < ithresh] = 0
    else:
        A[A < ithresh] = 0
    # renormalize by column after pruning
    margins = A.sum(dim=0)
    A.div_(margins.expand(A.size()))  # faster inplace

    for it in range(max_iter):
        # expand
        newA: torch.Tensor = mpow(A, e)
        # inflate
        newA.pow_(r)
        # normalize by column
        margins = newA.sum(dim=0)
        newA.div_(margins.expand(newA.size()))  # faster inplace
        # prune by threshold (keep the diagonals)
        if optimize_space:
            newA = cl.set_newval_where(
                newA,
                condition=lambda v: v < ithresh,
                newval=0,
                step=None,
                appendnewval=False,
            )  # newA[newA < ithresh] = 0
        else:
            newA[newA < ithresh] = 0
        # renormalize by column after pruning
        margins = newA.sum(dim=0)
        newA.div_(margins.expand(newA.size()))  # faster inplace
        # test for convergence or emergency stop due to nans
        if newA.sum().isnan() or convergence(A, newA):
            A = newA
            break
        A = newA

    # interpret results
    label_vec: torch.Tensor = interpretfun(A)
    print(f"MCL: found {label_vec.unique().size(0)} clusters, took {it} iterations.")
    labels: dict[int, list[int]] = cl.labelvector_as_clusterlist(label_vec)
    res: dict[str, Any] = {"labels": labels}
    if "A" in out:
        res["A"] = A
    else:
        del A
    if "labelvector" in out:
        res["labelvector"] = label_vec
    else:
        del label_vec
    del margins
    return res
