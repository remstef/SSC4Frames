## PyTorch-Graph-Cluster-Library

This package provides graph clustering algorithms in pytorch, enabling GPU support.

https://packaging.python.org
https://setuptools.pypa.io/en/latest/userguide/development_mode.html


---
### Manage environment for development
(https://docs.astral.sh/uv/)[uv] is used for managing packages and environments

---
### Build and deploy server app

docker buildx build -t remstef/pytorchgraphclusterlib:latest --platform linux/arm64,linux/amd64 --push .

https://packaging.python.org/en/latest/guides/

Use PyPA’s build

    uv run -m build

### Notes

Create and sync requirements.txt

    uv pip compile pyproject.toml > requirements.txt
    uv pip sync -r requirements.txt

Direct install from source:
    
    python3 -m pip install --no-deps --force-reinstall .[dev,app]

Install from private github repository (certificate and access required):

    python3 -m pip install -U git+ssh://git@github.com/remstef/pytorch-graph-cluster-lib.git@main
    
Install from public github repository:
    
    python3 -m pip install git+https://github.com/remstef/pytorch-graph-cluster-lib.git@main

Prepare deployment on [pypi.org](http://pypi.org) or [test.pypi.org](http://test.pypi.org):
   * Create an API token on the website.
   * You can use Twine to upload the distribution packages; install Twine:

    python3 -m pip install --upgrade twine

Deploy package with Twine to upload all of the archives under `./dist`:
   * You will be prompted for a username and password. 
   * For the username, use _\_\_token\_\__. For the password, use the API token value, including the pypi-prefix.
        
    python3 -m twine upload --repository testpypi dist/*

Install from pypi:

    python3 -m pip install --no-deps --force-reinstall ptgcl
    
Or from test.pypi:
    
    python3 -m pip install --no-deps --force-reinstall --index-url https://test.pypi.org/simple ptgcl


run app with:

    uv run -m ptgcl --help
    python -m ptgcl --help


### Cloud Deployment
Services are running in:
* Azure Container Instances (offline): https://ptgcl-tg-demo.gentlepebble-18b1d684.germanywestcentral.azurecontainerapps.io
* Google Cloud Kubernetes (offline): http://34.116.225.214/
* Google Cloud Run: https://ptgcl-tg-demoapp-798830512535.europe-west3.run.app/
