#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import pprint
from typing import Any

from  ptgcl import cl, cw

# run some tests


def test_cw(*args: Any, **kwargs: Any) -> None:
    if not "random_seed" in kwargs:
        kwargs["random_seed"] = 42
    if not "verbose" in kwargs:
        kwargs["verbose"] = True
    if not "quiet" in kwargs:
        kwargs["quiet"] = False
    if not "minweight" in kwargs:
        kwargs["minweight"] = 0.5
    A = cl.G_twentynodes(random_seed=kwargs["random_seed"])
    clustered = cw.cw(A, *args, **kwargs)
    show_test_results(clustered)
    assert len(clustered["labels"].keys()) == 2
    return


def test_cw_ssc(*args: Any, **kwargs: Any) -> None:
    if not "random_seed" in kwargs:
        kwargs["random_seed"] = 1
    if not "verbose" in kwargs:
        kwargs["verbose"] = True
    if not "quiet" in kwargs:
        kwargs["quiet"] = False
    if not "minweight" in kwargs:
        kwargs["minweight"] = 0.5
    if not "binarize" in kwargs:
        kwargs["binarize"] = True
    A = cl.G_twentynodes()
    if not "fixed_labels" in kwargs:
        fixed_labels = [None] * A.shape[0]
        fixed_labels[0] = "class1"
        fixed_labels[-1] = "class2"
        fixed_labels[2] = "class3"
        kwargs["fixed_labels"] = fixed_labels
        clustered = cw.cw(A, *args, **kwargs)
        show_test_results(clustered)
        assert len(clustered["labels"].keys()) == 3
    return


# def test_cw_sparse():
#   A = ptgcl.cl.G_twentynodes(random_seed=42).to_sparse_coo()
#   clustered = ptgcl.cw.cw(A,)
#   show_test_results(clustered)
#   assert len(clustered['labels'].keys()) == 2
#   return


def show_test_results(r: dict[str, Any]) -> None:
    print(pprint.pformat(r))


# c = cw_test(label_by='max_label')
# r = cw(cl.G_twentynodes(), binarize=False, minweight='median0', label_by='max_label', weighting='log')