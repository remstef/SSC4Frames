#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: remstef
"""

import pprint
from typing import Any
from torch.types import Tensor

from  ptgcl import cl, mcl

# run some tests

def show_test_results(r: dict[str, Any]) -> None:
    print(pprint.pformat(r))


def test(*args: Any, **kwargs: Any) -> None:
    A:Tensor = cl.G_twentynodes()
    res:dict[str, Any] = mcl.mcl(A)
    show_test_results(res)
    return 
